"use client";

import {
  conversionProfiles,
  detectFormat,
  formatById,
  preferredProfileFor,
  publicProfilesFor,
  type ConversionProfile,
} from "../../lib/capability-registry";
import {
  browserRequirementSatisfied,
  detectBrowserCapabilities,
  type BrowserCapabilities,
} from "../../lib/browser-capabilities";
import {
  inspectMediaSource,
  type MediaSourceInspection,
  type SourceStreamInspection,
} from "../../lib/media-source-inspection";
import {
  inspectStructuredSource,
  type StructuredSourceInspection,
} from "../../lib/structured-source-inspection";
import {
  inspectImageSource,
  type ImageSourceInspection,
} from "../../lib/image-source-inspection";
import {
  inspectPackageSource,
  type PackageSourceInspection,
} from "../../lib/package-source-inspection";
import {
  planMediaConversion,
  selectAutomaticMediaProfile,
  type MediaPlanAction,
} from "../../lib/media-conversion-plan";
import type {
  ConversionMetrics,
  TestFault,
  WorkerRequest,
  WorkerResponse,
} from "../../lib/conversion-protocol";
import {
  DEFAULT_AUDIO_CONVERSION_OPTIONS,
  DEFAULT_VIDEO_CONVERSION_OPTIONS,
  AUDIO_QUALITIES,
  MP3_BIT_RATES_BPS,
  VIDEO_BIT_RATES_BPS,
  VIDEO_FRAME_RATES_FPS,
  VIDEO_MAX_WIDTHS,
  audioCodecForProfile,
  audioCompressionForCodec,
  normalizeAudioConversionOptionsForCodec,
  audioSampleRatesForCodec,
  supportsAudioEncodingOptions,
  supportsVideoEncodingOptions,
  type AudioConversionOptions,
  type VideoConversionOptions,
} from "../../lib/media-conversion-options";
import {
  MAX_BATCH_FILES,
  MAX_RETAINED_WARNINGS,
  MAX_WORKER_RESPONSE_TEXT_CHARS,
} from "../../lib/resource-limits";
import {
  type DragEvent,
  type ChangeEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

type JobState = "idle" | "running" | "complete" | "cancelled" | "error";

interface PerformanceWithMemory extends Performance {
  memory?: {
    usedJSHeapSize: number;
    totalJSHeapSize: number;
    jsHeapSizeLimit: number;
  };
}

interface TestBridge {
  getState: () => {
    jobState: JobState;
    phase: string;
    metrics: ConversionMetrics | null;
    error: string | null;
    warnings: string[];
    automaticRouteNotice: string | null;
    selectedProfileId: string | null;
    audioOptions: AudioConversionOptions;
    videoOptions: VideoConversionOptions;
    opfsName: string | null;
    opfsNames: string[];
    batchOutputNames: string[];
    batchCompleted: number;
    batchTotal: number;
    startupCleanupComplete: boolean;
    workerStatus: "starting" | "ready" | "error";
    capabilities: BrowserCapabilities | null;
  };
}

type TestBridgeState = ReturnType<TestBridge["getState"]>;

interface ActiveBatch {
  files: File[];
  profile: ConversionProfile;
  outputNames: string[];
  destinationHandle: FileSystemFileHandle | null;
  destinationDirectoryHandle: FileSystemDirectoryHandle | null;
  testMode: boolean;
  testDirectoryMode: boolean;
  testFault?: TestFault;
  audioOptions?: AudioConversionOptions;
  videoOptions?: VideoConversionOptions;
  runId: string;
  index: number;
  opfsNames: string[];
}

declare global {
  interface Window {
    __WITHIN_TEST__?: TestBridge;
  }
}

const EMPTY_METRICS: ConversionMetrics = {
  inputBytes: 0,
  outputBytes: 0,
  queuedBytes: 0,
  peakQueuedBytes: 0,
  pendingOperations: 0,
  peakPendingOperations: 0,
  maxReadChunkBytes: 0,
  maxWriteChunkBytes: 0,
  elapsedMs: 0,
  wasmMemoryBytes: 0,
  peakWasmMemoryBytes: 0,
  sharedArrayBufferBytes: 0,
  activeWorkerCount: 1,
};

const TEST_FAULTS = new Set<TestFault>([
  "write",
  "quota",
  "permission",
  "worker-crash",
]);

async function removeAppOwnedOpfsEntry(name: string | null): Promise<boolean> {
  if (
    !name?.startsWith("within-test-") &&
    !name?.startsWith("within-stage-")
  ) {
    return true;
  }
  const root = await navigator.storage.getDirectory();
  for (let attempt = 0; attempt < 25; attempt += 1) {
    try {
      await root.removeEntry(name);
      return true;
    } catch (error) {
      if (error instanceof DOMException && error.name === "NotFoundError") {
        return true;
      }
      if (attempt === 24) return false;
      await new Promise<void>((resolve) => window.setTimeout(resolve, 200));
    }
  }
  return false;
}

async function removeIncompleteDirectoryOutput(
  batch: ActiveBatch | null,
): Promise<string | null> {
  const directory = batch?.destinationDirectoryHandle;
  const name = batch?.outputNames[batch.index];
  if (!directory || !name) return null;
  try {
    await directory.removeEntry(name);
    return null;
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    return `The incomplete output ${name} could not be deleted: ${detail}`.slice(
      0,
      MAX_WORKER_RESPONSE_TEXT_CHARS,
    );
  }
}

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes)) return "Unavailable";
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let value = Math.max(0, bytes);
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value >= 10 || unit === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[unit]}`;
}

function formatDuration(milliseconds: number): string {
  const seconds = Math.max(0, Math.round(milliseconds / 1000));
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  return `${minutes}m ${seconds % 60}s`;
}

function formatMediaDuration(seconds: number): string {
  const wholeMinutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds - wholeMinutes * 60;
  return `${wholeMinutes}:${remainingSeconds.toFixed(2).padStart(5, "0")}`;
}

function formatBitrate(bitsPerSecond: number): string {
  return `${Math.round(bitsPerSecond / 1_000).toLocaleString("en-US")} kb/s`;
}

function describeSourceStream(stream: SourceStreamInspection): string {
  const facts = [stream.codec];
  if (stream.width && stream.height) facts.push(`${stream.width}×${stream.height}`);
  if (stream.frameRate) facts.push(`${stream.frameRate.toFixed(2)} fps`);
  if (stream.sampleRateHz) {
    facts.push(`${stream.sampleRateHz.toLocaleString("en-US")} Hz`);
  }
  if (stream.channelLayout) facts.push(stream.channelLayout);
  if (stream.bitsPerSample) facts.push(`${stream.bitsPerSample}-bit`);
  if (stream.bitrateBps) facts.push(formatBitrate(stream.bitrateBps));
  if (stream.durationSeconds) facts.push(formatMediaDuration(stream.durationSeconds));
  return facts.join(" · ");
}

function mediaPlanActionLabel(action: MediaPlanAction): string {
  if (action === "copy") return "Copy";
  if (action === "re-encode") return "Re-encode";
  if (action === "reject") return "Reject";
  return "Exclude";
}

function outputName(file: File, profile: ConversionProfile): string {
  if (profile.id === "gzip-compress") return `${file.name}.gz`;
  if (profile.id === "bzip2-compress") return `${file.name}.bz2`;
  if (profile.id === "xz-compress") return `${file.name}.xz`;
  if (profile.id === "gzip-decompress") {
    return file.name.replace(/\.(?:gz|gzip)$/i, "") || "decompressed-file";
  }
  if (profile.id === "bzip2-decompress") {
    return file.name.replace(/\.(?:bz2|bzip2)$/i, "") || "decompressed-file";
  }
  if (profile.id === "xz-decompress") {
    return file.name.replace(/\.xz$/i, "") || "decompressed-file";
  }
  if (profile.id === "tar-gz-to-tar") {
    return (
      file.name.replace(/(?:\.tar\.gz|\.tgz)$/i, ".tar") ||
      "decompressed-archive.tar"
    );
  }
  if (profile.id === "tar-bz2-to-tar") {
    return (
      file.name.replace(/(?:\.tar\.bz2|\.tbz2|\.tbz)$/i, ".tar") ||
      "decompressed-archive.tar"
    );
  }
  if (profile.id === "tar-xz-to-tar") {
    return (
      file.name.replace(/(?:\.tar\.xz|\.txz)$/i, ".tar") ||
      "decompressed-archive.tar"
    );
  }
  const extension = formatById(profile.output)?.extensions[0] ?? "out";
  const inputExtensions = formatById(profile.input)?.extensions ?? [];
  const matchingInputExtension = [...inputExtensions]
    .sort((left, right) => right.length - left.length)
    .find((candidate) =>
      file.name.toLowerCase().endsWith(`.${candidate.toLowerCase()}`),
    );
  const stem = matchingInputExtension
    ? file.name.slice(0, -(matchingInputExtension.length + 1))
    : file.name.replace(/\.[^.]+$/, "");
  return `${stem || "converted-file"}.${extension}`;
}

function numberedOutputName(name: string, number: number): string {
  const dot = name.lastIndexOf(".");
  return dot > 0
    ? `${name.slice(0, dot)}-${number}${name.slice(dot)}`
    : `${name}-${number}`;
}

function batchOutputNames(
  files: readonly File[],
  profile: ConversionProfile,
): string[] {
  const used = new Set<string>();
  return files.map((file) => {
    const initial = outputName(file, profile);
    let candidate = initial;
    let suffix = 2;
    while (used.has(candidate.toLowerCase())) {
      candidate = numberedOutputName(initial, suffix);
      suffix += 1;
    }
    used.add(candidate.toLowerCase());
    return candidate;
  });
}

async function unusedFileHandle(
  directory: FileSystemDirectoryHandle,
  initialName: string,
): Promise<{ handle: FileSystemFileHandle; name: string }> {
  let candidate = initialName;
  let suffix = 2;
  for (;;) {
    try {
      await directory.getFileHandle(candidate);
      candidate = numberedOutputName(initialName, suffix);
      suffix += 1;
    } catch (error) {
      if (!(error instanceof DOMException) || error.name !== "NotFoundError") {
        throw error;
      }
      return {
        handle: await directory.getFileHandle(candidate, { create: true }),
        name: candidate,
      };
    }
  }
}

function outputPickerTypes(profile: ConversionProfile): FilePickerAcceptType[] {
  const format = formatById(profile.output);
  if (!format) return [];
  const extensions = format.extensions.map((extension) => `.${extension}`);
  const mime = format.mimeTypes[0] ?? "application/octet-stream";
  return [
    {
      description: format.label,
      accept: { [mime]: extensions.length ? extensions : [".bin"] },
    },
  ];
}

async function destinationMatchesSource(
  handle: FileSystemFileHandle,
  source: File,
): Promise<boolean> {
  const existing = await handle.getFile();
  return (
    existing.name === source.name &&
    existing.size === source.size &&
    existing.lastModified === source.lastModified
  );
}

function useConverterAppModel() {
  const [file, setFile] = useState<File | null>(null);
  const [batchFiles, setBatchFiles] = useState<File[]>([]);
  const [inputFormat, setInputFormat] = useState("binary");
  const [profileId, setProfileId] = useState<string | null>(null);
  const [audioOptions, setAudioOptions] = useState<AudioConversionOptions>({
    ...DEFAULT_AUDIO_CONVERSION_OPTIONS,
  });
  const [videoOptions, setVideoOptions] = useState<VideoConversionOptions>({
    ...DEFAULT_VIDEO_CONVERSION_OPTIONS,
  });
  const [sourceMediaInspection, setSourceMediaInspection] =
    useState<MediaSourceInspection | null>(null);
  const [sourceStructuredInspection, setSourceStructuredInspection] =
    useState<StructuredSourceInspection | null>(null);
  const [sourceImageInspection, setSourceImageInspection] =
    useState<ImageSourceInspection | null>(null);
  const [sourcePackageInspection, setSourcePackageInspection] =
    useState<PackageSourceInspection | null>(null);
  const [sourceInspectionStatus, setSourceInspectionStatus] = useState<
    "idle" | "inspecting" | "complete" | "unsupported" | "error"
  >("idle");
  const [sourceInspectionError, setSourceInspectionError] = useState<
    string | null
  >(null);
  const [destinationHandle, setDestinationHandle] =
    useState<FileSystemFileHandle | null>(null);
  const [destinationDirectoryHandle, setDestinationDirectoryHandle] =
    useState<FileSystemDirectoryHandle | null>(null);
  const [jobState, setJobState] = useState<JobState>("idle");
  const [phase, setPhase] = useState("Ready");
  const [metrics, setMetrics] = useState<ConversionMetrics | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [automaticRouteNotice, setAutomaticRouteNotice] = useState<string | null>(
    null,
  );
  const [error, setError] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const [capabilities, setCapabilities] =
    useState<BrowserCapabilities | null>(null);
  const [jsHeap, setJsHeap] = useState<number | null>(null);
  const [peakJsHeap, setPeakJsHeap] = useState<number | null>(null);
  const [opfsName, setOpfsName] = useState<string | null>(null);
  const [opfsNames, setOpfsNames] = useState<string[]>([]);
  const [completedBatchOutputNames, setCompletedBatchOutputNames] = useState<
    string[]
  >([]);
  const [batchCompleted, setBatchCompleted] = useState(0);
  const [storageUsage, setStorageUsage] = useState<number | null>(null);
  const [storageQuota, setStorageQuota] = useState<number | null>(null);
  const [cleanupMessage, setCleanupMessage] = useState(
    "No app-owned temporary files detected.",
  );
  const [startupCleanupComplete, setStartupCleanupComplete] = useState(false);
  const [workerReady, setWorkerReady] = useState(false);
  const [workerFailed, setWorkerFailed] = useState(false);
  const workerRef = useRef<Worker | null>(null);
  const jobIdRef = useRef<string | null>(null);
  const cancellationSignalRef = useRef<Int32Array<SharedArrayBuffer> | null>(null);
  const activeOpfsNameRef = useRef<string | null>(null);
  const activeBatchRef = useRef<ActiveBatch | null>(null);
  const beginBatchItemRef = useRef<
    ((worker: Worker, batch: ActiveBatch, index: number) => Promise<void>) | null
  >(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const testBridgeStateRef = useRef<TestBridgeState | null>(null);
  const testMode =
    typeof window !== "undefined" &&
    (window.location.hostname === "127.0.0.1" ||
      window.location.hostname === "localhost" ||
      window.location.hostname === "[::1]") &&
    new URLSearchParams(window.location.search).get("test") === "1";
  const requestedTestFault =
    typeof window === "undefined"
      ? null
      : new URLSearchParams(window.location.search).get("fault");
  const testFault =
    testMode && TEST_FAULTS.has(requestedTestFault as TestFault)
      ? (requestedTestFault as TestFault)
      : undefined;
  const testDirectoryMode =
    testMode &&
    new URLSearchParams(window.location.search).get("directory") === "1";
  const testCleanupMode =
    testMode &&
    new URLSearchParams(window.location.search).get("cleanup") === "1";
  const profiles = useMemo(
    () => publicProfilesFor(inputFormat, testMode),
    [inputFormat, testMode],
  );
  const selectedProfile = useMemo(
    () => profiles.find((profile) => profile.id === profileId) ?? null,
    [profileId, profiles],
  );
  const audioEncodingOptionsEnabled = supportsAudioEncodingOptions(selectedProfile);
  const selectedAudioCodec = audioCodecForProfile(selectedProfile);
  const selectableAudioProfiles = useMemo(
    () => profiles.filter((profile) => supportsAudioEncodingOptions(profile)),
    [profiles],
  );
  const videoEncodingOptionsEnabled =
    supportsVideoEncodingOptions(selectedProfile);
  const mediaConversionPlan = useMemo(
    () =>
      selectedProfile && sourceMediaInspection
        ? planMediaConversion(
            selectedProfile,
            sourceMediaInspection,
            audioEncodingOptionsEnabled ? audioOptions : undefined,
            videoEncodingOptionsEnabled ? videoOptions : undefined,
          )
        : null,
    [
      audioOptions,
      audioEncodingOptionsEnabled,
      selectedProfile,
      sourceMediaInspection,
      videoEncodingOptionsEnabled,
      videoOptions,
    ],
  );

  useEffect(() => {
    let cancelled = false;
    const inspectionAbortController = new AbortController();
    if (!file) return;
    void (async () => {
      await Promise.resolve();
      if (cancelled) return;
      setSourceMediaInspection(null);
      setSourceStructuredInspection(null);
      setSourceImageInspection(null);
      setSourcePackageInspection(null);
      setSourceInspectionStatus("inspecting");
      setSourceInspectionError(null);
      try {
        const [
          inspection,
          structuredInspection,
          imageInspection,
          packageInspection,
        ] = await Promise.all([
          inspectMediaSource(file, inputFormat),
          inspectStructuredSource(file, inputFormat),
          inspectImageSource(file, inputFormat, inspectionAbortController.signal),
          inspectPackageSource(file, inputFormat),
        ]);
        if (cancelled) return;
        setSourceMediaInspection(inspection);
        setSourceStructuredInspection(structuredInspection);
        setSourceImageInspection(imageInspection);
        setSourcePackageInspection(packageInspection);
        setSourceInspectionStatus(
          inspection || structuredInspection || imageInspection || packageInspection
            ? "complete"
            : "unsupported",
        );
        if (inspection && batchFiles.length === 1) {
          const candidates = profiles;
          const initialProfile = preferredProfileFor(inputFormat, candidates);
          if (initialProfile) {
            const automatic = selectAutomaticMediaProfile(
              initialProfile,
              candidates,
              inspection,
            );
            if (automatic.changed) {
              setProfileId(automatic.profile.id);
              setAutomaticRouteNotice(automatic.reason);
            }
          }
        }
      } catch (inspectionError: unknown) {
        if (cancelled) return;
        setSourceInspectionStatus("error");
        setSourceInspectionError(
          inspectionError instanceof Error
            ? inspectionError.message
            : "The bounded source inspection failed.",
        );
      }
    })();
    return () => {
      cancelled = true;
      inspectionAbortController.abort();
    };
  }, [batchFiles.length, file, inputFormat, profiles]);

  useEffect(() => {
    let disposed = false;
    void detectBrowserCapabilities().then((detected) => {
      if (!disposed) setCapabilities(detected);
    });
    return () => {
      disposed = true;
    };
  }, []);

  useEffect(() => {
    let disposed = false;
    let replacementTimer = 0;

    const beginBatchItem = async (
      worker: Worker,
      batch: ActiveBatch,
      index: number,
    ) => {
      const nextFile = batch.files[index];
      if (!nextFile) throw new Error("The next batch file is unavailable.");
      batch.index = index;
      setFile(nextFile);
      setBatchCompleted(index);
      setJobState("running");
      setPhase(
        batch.files.length > 1
          ? `Opening destination ${index + 1} of ${batch.files.length}`
          : "Opening destination",
      );
      setMetrics({ ...EMPTY_METRICS });
      setError(null);
      setPeakJsHeap(null);
      setOpfsName(null);

      const jobId = crypto.randomUUID();
      jobIdRef.current = jobId;
      const cancellationBuffer =
        batch.profile.engine.startsWith("ffmpeg-") &&
        typeof SharedArrayBuffer === "function"
          ? new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT)
          : undefined;
      cancellationSignalRef.current = cancellationBuffer
        ? new Int32Array(cancellationBuffer)
        : null;
      let destination:
        | { mode: "handle"; handle: FileSystemFileHandle }
        | {
            mode: "staged-handle";
            handle: FileSystemFileHandle;
            stagingName: string;
          }
        | { mode: "opfs-test"; name: string };
      const destinationForHandle = (
        handle: FileSystemFileHandle,
      ): typeof destination => {
        if (
          batch.profile.id !== "mp4-to-avi" &&
          batch.profile.id !== "mov-to-avi" &&
          batch.profile.id !== "3gp-to-avi" &&
          batch.profile.id !== "mkv-to-avi" &&
          batch.profile.id !== "mpeg-ts-to-avi" &&
          batch.profile.id !== "mkv-to-mp4" &&
          batch.profile.id !== "avi-to-3gp" &&
          batch.profile.id !== "avi-to-mpeg-ts" &&
          batch.profile.id !== "m2v-to-ogv"
        ) {
          activeOpfsNameRef.current = null;
          return { mode: "handle", handle };
        }
        const stagingName = `within-stage-${batch.profile.id}-${jobId}`;
        activeOpfsNameRef.current = stagingName;
        return { mode: "staged-handle", handle, stagingName };
      };
      if (batch.testMode && !batch.testDirectoryMode) {
        destination = {
          mode: "opfs-test",
          name: `within-test-${batch.profile.id}-${batch.runId}-${index + 1}`,
        };
        activeOpfsNameRef.current = destination.name;
      } else if (batch.files.length === 1 && batch.destinationHandle) {
        destination = destinationForHandle(batch.destinationHandle);
      } else if (batch.destinationDirectoryHandle) {
        const available = await unusedFileHandle(
          batch.destinationDirectoryHandle,
          batch.outputNames[index],
        );
        batch.outputNames[index] = available.name;
        destination = destinationForHandle(available.handle);
      } else {
        throw new Error("Choose a destination folder for this batch first.");
      }

      const request: WorkerRequest = {
        type: "start",
        jobId,
        profileId: batch.profile.id,
        file: nextFile,
        destination,
        audioOptions: batch.audioOptions,
        videoOptions: batch.videoOptions,
        cancellationBuffer,
        testFault: batch.testFault,
      };
      worker.postMessage(request);
    };
    beginBatchItemRef.current = beginBatchItem;

    const replaceWorker = (
      retired: Worker,
      abandonedOpfsName: string | null = null,
    ) => {
      cancellationSignalRef.current = null;
      retired.terminate();
      if (workerRef.current === retired) workerRef.current = null;
      setWorkerReady(false);
      const restart = () => {
        if (disposed) return;
        replacementTimer = window.setTimeout(() => {
          if (!disposed) installWorker();
        }, 250);
      };
      if (abandonedOpfsName) {
        void removeAppOwnedOpfsEntry(abandonedOpfsName)
          .then((removed) => {
            if (!removed) {
              setWarnings((current) => [
                ...current.slice(1 - MAX_RETAINED_WARNINGS),
                "A temporary conversion file could not be removed automatically. Use Clear temporary files in Storage management.",
              ]);
            }
          })
          .catch(() => {
            setWarnings((current) => [
              ...current.slice(1 - MAX_RETAINED_WARNINGS),
              "Temporary-file cleanup failed. Use Clear temporary files in Storage management.",
            ]);
          })
          .finally(restart);
      } else {
        restart();
      }
    };

    const installWorker = () => {
      const worker = new Worker(
        new URL("../../workers/conversion.worker.ts", import.meta.url),
        { name: "within-conversion" },
      );
      workerRef.current = worker;
      worker.onmessage = async (event: MessageEvent<WorkerResponse>) => {
        const message = event.data;
        if (message.type === "ready") {
          setWorkerReady(true);
          setWorkerFailed(false);
          return;
        }
        if (message.jobId !== jobIdRef.current) return;
        if (message.type === "progress") {
          setPhase(message.phase);
          setMetrics(message.metrics);
        } else if (message.type === "warning") {
          const batch = activeBatchRef.current;
          const warning =
            batch && batch.files.length > 1
              ? `${batch.files[batch.index]?.name ?? `File ${batch.index + 1}`}: ${message.message}`
              : message.message;
          const boundedWarning = warning.slice(0, MAX_WORKER_RESPONSE_TEXT_CHARS);
          setWarnings((current) => [
            ...current.slice(1 - MAX_RETAINED_WARNINGS),
            boundedWarning,
          ]);
        } else if (message.type === "complete") {
          const batch = activeBatchRef.current;
          activeOpfsNameRef.current = null;
          jobIdRef.current = null;
          setMetrics(message.metrics);
          if (batch) {
            if (message.opfsName) batch.opfsNames.push(message.opfsName);
            setOpfsNames([...batch.opfsNames]);
            const nextIndex = batch.index + 1;
            if (nextIndex < batch.files.length) {
              setBatchCompleted(nextIndex);
              setPhase(`Saved ${nextIndex} of ${batch.files.length}`);
              void beginBatchItem(worker, batch, nextIndex).catch((error) => {
                const staleOpfsName = activeOpfsNameRef.current;
                activeBatchRef.current = null;
                activeOpfsNameRef.current = null;
                jobIdRef.current = null;
                setError(error instanceof Error ? error.message : String(error));
                setPhase("Batch stopped safely");
                setJobState("error");
                replaceWorker(worker, staleOpfsName);
              });
              return;
            }
            activeBatchRef.current = null;
            setBatchCompleted(batch.files.length);
            setCompletedBatchOutputNames([...batch.outputNames]);
            setOpfsName(
              batch.files.length === 1 ? (message.opfsName ?? null) : null,
            );
            setPhase(
              batch.files.length === 1
                ? "Saved"
                : `Saved ${batch.files.length} files`,
            );
            setJobState("complete");
            replaceWorker(worker);
          } else {
            setOpfsName(message.opfsName ?? null);
            setPhase("Saved");
            setJobState("complete");
            replaceWorker(worker);
          }
        } else if (message.type === "cancelled") {
          const batch = activeBatchRef.current;
          const staleOpfsName = activeOpfsNameRef.current;
          activeBatchRef.current = null;
          activeOpfsNameRef.current = null;
          jobIdRef.current = null;
          const cleanupWarning = await removeIncompleteDirectoryOutput(batch);
          setMetrics(message.metrics);
          if (cleanupWarning) {
            setWarnings((current) => [
              ...current.slice(1 - MAX_RETAINED_WARNINGS),
              cleanupWarning,
            ]);
          }
          setPhase(
            batch && batch.files.length > 1
              ? `Cancelled after ${batch.index} of ${batch.files.length} files`
              : "Cancelled",
          );
          setJobState("cancelled");
          replaceWorker(worker, staleOpfsName);
        } else {
          const batch = activeBatchRef.current;
          const staleOpfsName = activeOpfsNameRef.current;
          activeBatchRef.current = null;
          activeOpfsNameRef.current = null;
          jobIdRef.current = null;
          const cleanupWarning = await removeIncompleteDirectoryOutput(batch);
          setMetrics(message.metrics);
          setError(message.message);
          if (cleanupWarning) {
            setWarnings((current) => [
              ...current.slice(1 - MAX_RETAINED_WARNINGS),
              cleanupWarning,
            ]);
          }
          setPhase("Stopped safely");
          setJobState("error");
          replaceWorker(worker, staleOpfsName);
        }
      };
      worker.onerror = async (event) => {
        event.preventDefault();
        const failedDuringConversion = jobIdRef.current !== null;
        const batch = activeBatchRef.current;
        const staleOpfsName = activeOpfsNameRef.current;
        activeBatchRef.current = null;
        activeOpfsNameRef.current = null;
        jobIdRef.current = null;
        const cleanupWarning = await removeIncompleteDirectoryOutput(batch);
        setWorkerFailed(true);
        const detail =
          event instanceof ErrorEvent && event.message
            ? event.message
            : "the browser blocked or rejected the worker script";
        setError(
          failedDuringConversion
            ? `Conversion worker failed: ${detail}.`
            : `Conversion worker failed to start: ${detail}.`,
        );
        if (cleanupWarning) {
          setWarnings((current) => [
            ...current.slice(1 - MAX_RETAINED_WARNINGS),
            cleanupWarning,
          ]);
        }
        setPhase("Worker unavailable");
        setJobState("error");
        replaceWorker(worker, staleOpfsName);
      };
      worker.onmessageerror = async () => {
        const batch = activeBatchRef.current;
        const staleOpfsName = activeOpfsNameRef.current;
        activeBatchRef.current = null;
        activeOpfsNameRef.current = null;
        jobIdRef.current = null;
        const cleanupWarning = await removeIncompleteDirectoryOutput(batch);
        setWorkerFailed(true);
        setError("The conversion worker returned an unreadable message.");
        if (cleanupWarning) {
          setWarnings((current) => [
            ...current.slice(1 - MAX_RETAINED_WARNINGS),
            cleanupWarning,
          ]);
        }
        setPhase("Worker unavailable");
        setJobState("error");
        replaceWorker(worker, staleOpfsName);
      };
    };

    installWorker();
    return () => {
      disposed = true;
      beginBatchItemRef.current = null;
      window.clearTimeout(replacementTimer);
      workerRef.current?.terminate();
      workerRef.current = null;
      cancellationSignalRef.current = null;
    };
  }, []);

  const refreshStorageEstimate = useCallback(async () => {
    const estimate = await navigator.storage?.estimate?.();
    setStorageUsage(estimate?.usage ?? null);
    setStorageQuota(estimate?.quota ?? null);
  }, []);

  const clearAppTemporaryStorage = useCallback(async () => {
    if (!navigator.storage?.getDirectory) return 0;
    const root = await navigator.storage.getDirectory();
    let removed = 0;
    for await (const [name] of root.entries()) {
      if (!name.startsWith("within-")) continue;
      await root.removeEntry(name, { recursive: true });
      removed += 1;
    }
    await refreshStorageEstimate();
    return removed;
  }, [refreshStorageEstimate]);

  useEffect(() => {
    if (testMode && !testCleanupMode) {
      const skippedCleanupTimer = window.setTimeout(
        () => setStartupCleanupComplete(true),
        0,
      );
      return () => window.clearTimeout(skippedCleanupTimer);
    }
    if (!testMode) {
      void navigator.serviceWorker?.register("/sw.js").catch(() => {});
    }
    const cleanupTimer = window.setTimeout(() => {
      void clearAppTemporaryStorage()
        .then((removed) => {
          setCleanupMessage(
            removed
              ? `Removed ${removed} stale app-owned temporary ${removed === 1 ? "file" : "files"}.`
              : "No app-owned temporary files detected.",
          );
        })
        .catch(() => {
          setCleanupMessage("Temporary storage is unavailable in this browser.");
        })
        .finally(() => setStartupCleanupComplete(true));
    }, 0);
    return () => window.clearTimeout(cleanupTimer);
  }, [clearAppTemporaryStorage, testCleanupMode, testMode]);

  useEffect(() => {
    if (jobState !== "running") return;
    const sample = () => {
      const memory = (performance as PerformanceWithMemory).memory;
      if (!memory) return;
      setJsHeap(memory.usedJSHeapSize);
      setPeakJsHeap((current) =>
        Math.max(current ?? 0, memory.usedJSHeapSize),
      );
    };
    sample();
    const timer = window.setInterval(sample, 500);
    return () => window.clearInterval(timer);
  }, [jobState]);

  useEffect(() => {
    testBridgeStateRef.current = {
      jobState,
      phase,
      metrics,
      error,
      warnings,
      automaticRouteNotice,
      selectedProfileId: profileId,
      audioOptions,
      videoOptions,
      opfsName,
      opfsNames,
      batchOutputNames: completedBatchOutputNames,
      batchCompleted,
      batchTotal: batchFiles.length,
      startupCleanupComplete,
      workerStatus: workerFailed ? "error" : workerReady ? "ready" : "starting",
      capabilities,
    };
  }, [
    error,
    jobState,
    metrics,
    opfsName,
    opfsNames,
    completedBatchOutputNames,
    phase,
    profileId,
    audioOptions,
    videoOptions,
    batchCompleted,
    batchFiles.length,
    capabilities,
    startupCleanupComplete,
    testMode,
    warnings,
    automaticRouteNotice,
    workerFailed,
    workerReady,
  ]);

  useEffect(() => {
    if (!testMode) return;
    window.__WITHIN_TEST__ = {
      getState: () => {
        const state = testBridgeStateRef.current;
        if (!state) throw new Error("Test bridge state is unavailable.");
        return state;
      },
    };
    return () => {
      delete window.__WITHIN_TEST__;
    };
  }, [testMode]);

  const acceptFiles = useCallback(
    (nextFiles: File[]) => {
      if (jobState === "running") return;
      setAutomaticRouteNotice(null);
      if (nextFiles.length > MAX_BATCH_FILES) {
        setFile(null);
        setBatchFiles([]);
        setInputFormat("binary");
        setProfileId(null);
        setAudioOptions({ ...DEFAULT_AUDIO_CONVERSION_OPTIONS });
        setVideoOptions({ ...DEFAULT_VIDEO_CONVERSION_OPTIONS });
        setSourceMediaInspection(null);
        setSourceStructuredInspection(null);
        setSourceImageInspection(null);
        setSourcePackageInspection(null);
        setSourceInspectionStatus("idle");
        setSourceInspectionError(null);
        setDestinationHandle(null);
        setDestinationDirectoryHandle(null);
        setJobState("idle");
        setPhase("Ready");
        setMetrics(null);
        setWarnings([]);
        setJsHeap(null);
        setPeakJsHeap(null);
        setOpfsName(null);
        setOpfsNames([]);
        setCompletedBatchOutputNames([]);
        setBatchCompleted(0);
        setError(
          `A batch is limited to ${MAX_BATCH_FILES} files so file handles, output names, and result state remain bounded.`,
        );
        if (fileInputRef.current) fileInputRef.current.value = "";
        return;
      }
      const nextFile = nextFiles[0];
      if (!nextFile) return;
      const detected = detectFormat(nextFile);
      const mismatched = nextFiles.find(
        (candidate) => detectFormat(candidate) !== detected,
      );
      if (mismatched) {
        setFile(null);
        setBatchFiles([]);
        setInputFormat("binary");
        setProfileId(null);
        setAudioOptions({ ...DEFAULT_AUDIO_CONVERSION_OPTIONS });
        setVideoOptions({ ...DEFAULT_VIDEO_CONVERSION_OPTIONS });
        setSourceMediaInspection(null);
        setSourceStructuredInspection(null);
        setSourceImageInspection(null);
        setSourcePackageInspection(null);
        setSourceInspectionStatus("idle");
        setSourceInspectionError(null);
        setDestinationHandle(null);
        setDestinationDirectoryHandle(null);
        setJobState("idle");
        setPhase("Ready");
        setMetrics(null);
        setWarnings([]);
        setJsHeap(null);
        setPeakJsHeap(null);
        setOpfsName(null);
        setOpfsNames([]);
        setCompletedBatchOutputNames([]);
        setBatchCompleted(0);
        setError(
          `Batch files must share one detected format. ${mismatched.name} does not match ${nextFile.name}.`,
        );
        if (fileInputRef.current) fileInputRef.current.value = "";
        return;
      }
      const nextProfiles = publicProfilesFor(detected, testMode);
      setFile(nextFile);
      setBatchFiles(nextFiles);
      setInputFormat(detected);
      setProfileId(preferredProfileFor(detected, nextProfiles)?.id ?? null);
      setAudioOptions({ ...DEFAULT_AUDIO_CONVERSION_OPTIONS });
      setVideoOptions({ ...DEFAULT_VIDEO_CONVERSION_OPTIONS });
      setSourceMediaInspection(null);
      setSourceStructuredInspection(null);
      setSourceImageInspection(null);
      setSourcePackageInspection(null);
      setSourceInspectionStatus("inspecting");
      setSourceInspectionError(null);
      setDestinationHandle(null);
      setDestinationDirectoryHandle(null);
      setJobState("idle");
      setPhase("Ready");
      setMetrics(null);
      setWarnings([]);
      setError(null);
      setJsHeap(null);
      setPeakJsHeap(null);
      setOpfsName(null);
      setOpfsNames([]);
      setCompletedBatchOutputNames([]);
      setBatchCompleted(0);
    },
    [jobState, testMode],
  );

  const onFileInput = (event: ChangeEvent<HTMLInputElement>) => {
    const nextFiles = Array.from(event.target.files ?? []);
    if (nextFiles.length) acceptFiles(nextFiles);
  };

  const onDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    const nextFiles = Array.from(event.dataTransfer.files ?? []);
    if (nextFiles.length) acceptFiles(nextFiles);
  };

  const chooseDestination = async () => {
    if (!file || !selectedProfile) return;
    try {
      if (batchFiles.length > 1) {
        if (!window.showDirectoryPicker) return;
        const directory = await window.showDirectoryPicker({
          id: "within-batch-output",
          mode: "readwrite",
        });
        setDestinationDirectoryHandle(directory);
        setDestinationHandle(null);
        setError(null);
        return;
      }
      if (!window.showSaveFilePicker) return;
      const handle = await window.showSaveFilePicker({
        suggestedName: outputName(file, selectedProfile),
        types: outputPickerTypes(selectedProfile),
        excludeAcceptAllOption: false,
      });
      if (await destinationMatchesSource(handle, file)) {
        setDestinationHandle(null);
        setError(
          "Choose a different destination name or folder. The source file cannot also be the output.",
        );
        return;
      }
      setDestinationHandle(handle);
      setDestinationDirectoryHandle(null);
      setError(null);
    } catch (pickerError) {
      if (
        !(pickerError instanceof DOMException) ||
        pickerError.name !== "AbortError"
      ) {
        setError(
          pickerError instanceof Error
            ? pickerError.message
            : "The destination could not be opened.",
        );
      }
    }
  };

  const startConversion = async () => {
    const worker = workerRef.current;
    if (!file || !selectedProfile || !worker || !beginBatchItemRef.current) return;
    const files = batchFiles.length ? batchFiles : [file];

    if (!testMode) {
      if (files.length > 1 && !destinationDirectoryHandle) {
        setError("Choose a destination folder for this batch first.");
        return;
      }
      if (files.length === 1 && !destinationHandle) {
        setError("Choose where the converted file should be saved first.");
        return;
      }
      if (files.length === 1 && destinationHandle) {
        try {
          if (await destinationMatchesSource(destinationHandle, file)) {
            setDestinationHandle(null);
            setError(
              "The destination now matches the source file. Choose a different destination before converting.",
            );
            return;
          }
        } catch (destinationError) {
          setError(
            destinationError instanceof Error
              ? `The destination is no longer accessible: ${destinationError.message}`
              : "The destination is no longer accessible.",
          );
          return;
        }
      }
    }

    const batch: ActiveBatch = {
      files,
      profile: selectedProfile,
      audioOptions: audioEncodingOptionsEnabled
        ? { ...audioOptions }
        : undefined,
      videoOptions: videoEncodingOptionsEnabled
        ? { ...videoOptions }
        : undefined,
      outputNames: batchOutputNames(files, selectedProfile),
      destinationHandle,
      destinationDirectoryHandle: testDirectoryMode
        ? await navigator.storage.getDirectory()
        : destinationDirectoryHandle,
      testMode,
      testDirectoryMode,
      testFault,
      runId: `${Date.now()}-${crypto.randomUUID()}`,
      index: 0,
      opfsNames: [],
    };
    activeBatchRef.current = batch;
    setWarnings([]);
    setOpfsNames([]);
    setCompletedBatchOutputNames([...batch.outputNames]);
    setBatchCompleted(0);
    try {
      await beginBatchItemRef.current(worker, batch, 0);
    } catch (startError) {
      activeBatchRef.current = null;
      activeOpfsNameRef.current = null;
      jobIdRef.current = null;
      cancellationSignalRef.current = null;
      setError(startError instanceof Error ? startError.message : String(startError));
      setPhase("Batch stopped safely");
      setJobState("error");
    }
  };

  const cancelConversion = () => {
    const jobId = jobIdRef.current;
    if (!jobId || !workerRef.current) return;
    const signal = cancellationSignalRef.current;
    if (signal) Atomics.store(signal, 0, 1);
    const request: WorkerRequest = { type: "cancel", jobId };
    workerRef.current.postMessage(request);
    setPhase("Cancelling safely");
  };

  const clearFile = () => {
    if (jobState === "running") return;
    setFile(null);
    setBatchFiles([]);
    setInputFormat("binary");
    setProfileId(null);
    setAudioOptions({ ...DEFAULT_AUDIO_CONVERSION_OPTIONS });
    setVideoOptions({ ...DEFAULT_VIDEO_CONVERSION_OPTIONS });
    setSourceMediaInspection(null);
    setSourceStructuredInspection(null);
    setSourceImageInspection(null);
    setSourcePackageInspection(null);
    setSourceInspectionStatus("idle");
    setSourceInspectionError(null);
    setDestinationHandle(null);
    setDestinationDirectoryHandle(null);
    setMetrics(null);
    setWarnings([]);
    setError(null);
    setPhase("Ready");
    setOpfsName(null);
    setOpfsNames([]);
    setCompletedBatchOutputNames([]);
    setBatchCompleted(0);
    setJobState("idle");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const currentFileProgress = file
    ? Math.min(100, ((metrics?.inputBytes ?? 0) / Math.max(1, file.size)) * 100)
    : 0;
  const progress =
    batchFiles.length > 1
      ? Math.min(
          100,
          ((batchCompleted + currentFileProgress / 100) / batchFiles.length) *
            100,
        )
      : currentFileProgress;
  const totalInputBytes = batchFiles.reduce(
    (total, candidate) => total + candidate.size,
    0,
  );
  const throughput =
    metrics && metrics.elapsedMs > 0
      ? metrics.inputBytes / (metrics.elapsedMs / 1000)
      : 0;
  const estimatedRemainingMs =
    file &&
    metrics &&
    throughput > 0 &&
    metrics.inputBytes < file.size
      ? ((file.size - metrics.inputBytes) / throughput) * 1000
      : jobState === "complete"
        ? 0
        : null;
  const mediaProfile =
    selectedProfile?.engine === "ffmpeg-remux" ||
    selectedProfile?.engine === "ffmpeg-audio" ||
    selectedProfile?.engine === "ffmpeg-video";
  const inputMimeType = formatById(inputFormat)?.mimeTypes[0];
  const missingCapabilities: string[] = [];
  if (capabilities) {
    if (!capabilities.secure) missingCapabilities.push("a secure HTTPS or localhost context");
    if (!capabilities.workers) {
      missingCapabilities.push("the Web Worker API");
    } else if (workerFailed) {
      missingCapabilities.push("a conversion worker that starts successfully");
    }
    for (const requirement of selectedProfile?.browserRequirements ?? []) {
      if (testMode && requirement === "File System Access") continue;
      if (!browserRequirementSatisfied(requirement, capabilities, inputMimeType)) {
        missingCapabilities.push(requirement);
      }
    }
    if (mediaProfile && !capabilities.wasmSimd) {
      missingCapabilities.push("WebAssembly SIMD required by the media core");
    }
    if (!testMode && batchFiles.length > 1 && !capabilities.directoryAccess) {
      missingCapabilities.push("the destination-folder picker API");
    }
    if (testMode && !capabilities.opfs) {
      missingCapabilities.push("functional Origin Private File System test storage");
    }
  }
  const uniqueMissingCapabilities = [...new Set(missingCapabilities)];
  const featureReady = Boolean(capabilities && workerReady && uniqueMissingCapabilities.length === 0);
  const workerStarting = Boolean(capabilities?.workers && !workerReady && !workerFailed);

  const capabilityItems: [string, boolean][] = capabilities
    ? [
        ["Private context", capabilities.secure],
        [
          "Direct-save picker API",
          batchFiles.length > 1
            ? capabilities.directoryAccess
            : capabilities.fileSystemAccess,
        ],
        ["Conversion worker running", capabilities.workers && workerReady],
        ["Wasm core validated", capabilities.wasm],
        ...(mediaProfile
          ? ([["Wasm SIMD validated", capabilities.wasmSimd]] as [string, boolean][])
          : []),
        ["Shared buffers", capabilities.sharedArrayBuffer],
        ...(selectedProfile?.browserRequirements.includes("ImageDecoder")
          ? ([
              [
                `Image decoder: ${inputMimeType ?? "selected input"}`,
                inputMimeType
                  ? capabilities.imageDecoderTypes[inputMimeType] === true
                  : capabilities.imageDecoder,
              ],
            ] as [string, boolean][])
          : []),
        ["Offscreen canvas functional", capabilities.offscreenCanvas],
        ["OPFS opened", capabilities.opfs],
        ["Storage quota measured", capabilities.storageEstimate],
        ["Cross-origin isolated", capabilities.crossOriginIsolated],
        ["Web Crypto digest functional", capabilities.webCrypto],
        [
          "WebCodecs config (optional)",
          capabilities.webCodecsVideo || capabilities.webCodecsAudio,
        ],
      ]
    : [];

  // The compiled registry is immutable; progress must not rebuild its static display.
  const publishedFormatsSection = useMemo(() => (
      <section className="formats-section" id="formats">
        <div className="section-intro">
          <p className="eyebrow">Published from the test registry</p>
          <h2>Only verified routes appear.</h2>
          <p>
            Format buttons are generated from the same machine-readable records
            used by the tests. Media routes remain invisible until their custom
            engine passes output validation and the complete browser memory gate.
          </p>
        </div>
        <div className="matrix">
          {conversionProfiles
            .filter(
              (profile) =>
                profile.public && profile.automatedTestStatus === "passed",
            )
            .map((profile) => (
              <article key={profile.id}>
                <span>{formatById(profile.input)?.label}</span>
                <b aria-hidden="true">→</b>
                <span>{formatById(profile.output)?.label}</span>
                <small>
                  {profile.route} · tested to{" "}
                  {profile.maxTestedBytes == null
                    ? "pending"
                    : formatBytes(profile.maxTestedBytes)}
                </small>
              </article>
            ))}
          {!conversionProfiles.some(
            (profile) =>
              profile.public && profile.automatedTestStatus === "passed",
          ) ? (
            <div className="matrix-empty">
              Verification is running. No untested conversion is being advertised.
            </div>
          ) : null}
        </div>
      </section>
  ), []);

  return { audioEncodingOptionsEnabled, audioOptions, automaticRouteNotice, batchFiles, cancelConversion, capabilities, capabilityItems, chooseDestination, cleanupMessage, clearAppTemporaryStorage, clearFile, destinationDirectoryHandle, destinationHandle, dragging, error, estimatedRemainingMs, featureReady, file, fileInputRef, inputFormat, jobState, jsHeap, mediaConversionPlan, mediaProfile, metrics, onDrop, onFileInput, peakJsHeap, phase, profileId, profiles, progress, publishedFormatsSection, selectableAudioProfiles, selectedAudioCodec, selectedProfile, setAudioOptions, setAutomaticRouteNotice, setBatchCompleted, setCleanupMessage, setCompletedBatchOutputNames, setDestinationDirectoryHandle, setDestinationHandle, setDragging, setError, setJobState, setMetrics, setOpfsName, setOpfsNames, setPhase, setProfileId, setVideoOptions, setWarnings, sourceImageInspection, sourceInspectionError, sourceInspectionStatus, sourceMediaInspection, sourcePackageInspection, sourceStructuredInspection, startConversion, storageQuota, storageUsage, testMode, throughput, totalInputBytes, uniqueMissingCapabilities, videoEncodingOptionsEnabled, videoOptions, warnings, workerStarting };
}

type ConverterAppModel = ReturnType<typeof useConverterAppModel>;

function renderConverterPage(model: ConverterAppModel) {
  const { publishedFormatsSection } = model;
  return (
(
    <main>
      {renderSiteHeader()}

      <section className="hero" id="top">
        {renderHeroIntro()}

        {renderConverterCard(model)}
      </section>

      {renderPrivacyProof(model)}

      {publishedFormatsSection}

      {renderSiteFooter(model)}
    </main>
  )
  );
}

function renderSiteHeader() {
  return (
<header className="site-header">
        <a className="brand" href="#top" aria-label="Within home">
          <span className="brand-mark" aria-hidden="true">
            W
          </span>
          <span>Within</span>
        </a>
        <nav aria-label="Page sections">
          <a href="#converter">Convert</a>
          <a href="#proof">How it stays private</a>
          <a href="#formats">Verified formats</a>
        </nav>
        <div className="privacy-chip">
          <span className="pulse-dot" aria-hidden="true" />
          Local only
        </div>
      </header>
  );
}

function renderHeroIntro() {
  return (
<div className="hero-copy">
          <p className="eyebrow">Private by architecture, not by promise</p>
          <h1>
            Big files.
            <br />
            <em>Small memory.</em>
          </h1>
          <p className="hero-lede">
            Convert directly from your file to the destination you choose.
            Nothing is uploaded, and no full-size copy waits in browser memory.
          </p>
          <div className="hero-notes" aria-label="Core guarantees">
            <span>0 bytes uploaded</span>
            <span>1 write in flight</span>
            <span>Bounded write cap</span>
          </div>
        </div>
  );
}

function renderConverterCard(model: ConverterAppModel) {
  const { automaticRouteNotice, batchFiles, cancelConversion, capabilities, chooseDestination, destinationDirectoryHandle, destinationHandle, error, featureReady, file, jobState, mediaConversionPlan, mediaProfile, profiles, selectedProfile, sourceInspectionStatus, startConversion, testMode, uniqueMissingCapabilities, warnings, workerStarting } = model;
  return (
<section className="converter-card" id="converter" aria-labelledby="convert-title">
          <div className="card-heading">
            <div>
              <p className="step-label">01 / Choose a file</p>
              <h2 id="convert-title">Convert on this device</h2>
            </div>
            <span className={`readiness ${featureReady ? "ready" : "limited"}`}>
              {featureReady ? "Ready" : workerStarting ? "Starting worker" : "Check browser"}
            </span>
          </div>

          {capabilities && selectedProfile && uniqueMissingCapabilities.length ? (
            <div className="conversion-plan-blocker" role="alert" data-testid="capability-blocker">
              <strong>This profile cannot run with the capabilities verified in this browser.</strong>
              <ul>
                {uniqueMissingCapabilities.map((missing) => (
                  <li key={missing}>{missing}</li>
                ))}
              </ul>
            </div>
          ) : null}

          {renderFileDrop(model)}

          {renderSourceInspection(model)}

          {error && !file ? (
            <p className="error" role="alert">
              {error}
            </p>
          ) : null}

          {file && profiles.length === 0 ? (
            <div className="honesty-note" role="status">
              <strong>This format is not publicly enabled yet.</strong>
              <span>
                Its engine remains hidden until real output and memory tests pass.
                Renaming the extension is never offered as a fallback.
              </span>
            </div>
          ) : null}

          {file && profiles.length > 0 ? (
            <>
              {renderOutputControls(model)}

              {renderAudioControls(model)}

              {renderVideoControls(model)}

              {renderMediaPlan(model)}

              {automaticRouteNotice ? (
                <p
                  className="warning"
                  data-testid="automatic-route-notice"
                  role="status"
                >
                  {automaticRouteNotice}
                </p>
              ) : null}

              {!testMode ? (
                <button
                  className="destination-button"
                  type="button"
                  onClick={chooseDestination}
                  disabled={
                    jobState === "running" ||
                    !(batchFiles.length > 1
                      ? capabilities?.directoryAccess
                      : capabilities?.fileSystemAccess)
                  }
                >
                  <span>
                    {batchFiles.length > 1
                      ? destinationDirectoryHandle
                        ? destinationDirectoryHandle.name
                        : "Choose destination folder"
                      : destinationHandle
                        ? destinationHandle.name
                        : "Choose destination file"}
                  </span>
                  <span aria-hidden="true">Browse →</span>
                </button>
              ) : (
                <div className="test-mode-note">
                  Test output uses isolated browser storage
                  {batchFiles.length > 1
                    ? ` for ${batchFiles.length} sequential files.`
                    : "."}
                </div>
              )}

              {selectedProfile ? (
                <div className="profile-evidence">
                  {selectedProfile.automatedTestStatus === "passed" &&
                  selectedProfile.maxTestedBytes != null
                    ? `Correctness and complete-browser memory tested through ${formatBytes(selectedProfile.maxTestedBytes)}.`
                    : "Test-only route: not certified for public use; consult the route limitations and retained test evidence."}
                </div>
              ) : null}

              {selectedProfile &&
              (selectedProfile.metadataLimitations.length ||
                selectedProfile.fidelityLimitations.length) ? (
                <details className="limitations">
                  <summary>What this destination cannot preserve</summary>
                  <ul>
                    {[
                      ...selectedProfile.metadataLimitations,
                      ...selectedProfile.fidelityLimitations,
                    ].map((limitation) => (
                      <li key={limitation}>{limitation}</li>
                    ))}
                  </ul>
                </details>
              ) : null}

              {renderProgressPanel(model)}

              {warnings.map((warning) => (
                <p className="warning" key={warning}>
                  {warning}
                </p>
              ))}
              {error ? (
                <p className="error" role="alert">
                  {error}
                </p>
              ) : null}

              {jobState === "running" ? (
                <button
                  className="convert-button cancel"
                  type="button"
                  onClick={cancelConversion}
                >
                  Cancel safely
                </button>
              ) : (
                <button
                  data-testid="convert-button"
                  className="convert-button"
                  type="button"
                  onClick={startConversion}
                  disabled={
                    !selectedProfile ||
                    (mediaProfile && sourceInspectionStatus === "inspecting") ||
                    Boolean(mediaConversionPlan?.blockingReasons.length) ||
                    (!testMode &&
                      (batchFiles.length > 1
                        ? !destinationDirectoryHandle
                        : !destinationHandle)) ||
                    !featureReady
                  }
                >
                  {jobState === "complete"
                    ? batchFiles.length > 1
                      ? "Convert batch again"
                      : "Convert again"
                    : batchFiles.length > 1
                      ? `Convert ${batchFiles.length} files`
                      : "Start conversion"}
                  <span aria-hidden="true">↗</span>
                </button>
              )}
            </>
          ) : null}
        </section>
  );
}

function renderSourceInspection(model: ConverterAppModel) {
  const { batchFiles, file, inputFormat, sourceImageInspection, sourceInspectionError, sourceInspectionStatus, sourceMediaInspection, sourcePackageInspection, sourceStructuredInspection, totalInputBytes } = model;
  return (
file ? (
            <details className="source-inspection" data-testid="source-inspection">
              <summary>Source inspection</summary>
              <dl>
                <div>
                  <dt>Detected format</dt>
                  <dd>{formatById(inputFormat)?.label ?? "Unknown"}</dd>
                </div>
                <div>
                  <dt>Category</dt>
                  <dd>{formatById(inputFormat)?.category ?? "Unknown"}</dd>
                </div>
                <div>
                  <dt>Browser MIME</dt>
                  <dd>{file.type || "Not provided"}</dd>
                </div>
                <div>
                  <dt>Files</dt>
                  <dd>{batchFiles.length}</dd>
                </div>
                <div>
                  <dt>Exact input bytes</dt>
                  <dd>{totalInputBytes.toLocaleString("en-US")}</dd>
                </div>
                <div>
                  <dt>Last modified</dt>
                  <dd>
                    {batchFiles.length === 1
                      ? new Date(file.lastModified).toLocaleString()
                      : "Varies by file"}
                  </dd>
                </div>
                {sourceMediaInspection ? (
                  <>
                    <div>
                      <dt>Container</dt>
                      <dd>{sourceMediaInspection.container}</dd>
                    </div>
                    <div>
                      <dt>Primary codec</dt>
                      <dd>{sourceMediaInspection.codec}</dd>
                    </div>
                    <div>
                      <dt>Duration</dt>
                      <dd>
                        {sourceMediaInspection.durationSeconds
                          ? formatMediaDuration(
                              sourceMediaInspection.durationSeconds,
                            )
                          : "Unavailable"}
                      </dd>
                    </div>
                    <div>
                      <dt>Primary bitrate</dt>
                      <dd>
                        {sourceMediaInspection.bitrateBps
                          ? formatBitrate(sourceMediaInspection.bitrateBps)
                          : "Unavailable"}
                      </dd>
                    </div>
                    {sourceMediaInspection.mediaType === "audio" ? (
                      <>
                        <div>
                          <dt>Sample rate</dt>
                          <dd>
                            {sourceMediaInspection.sampleRateHz
                              ? `${sourceMediaInspection.sampleRateHz.toLocaleString("en-US")} Hz`
                              : "Unavailable"}
                          </dd>
                        </div>
                        <div>
                          <dt>Channel layout</dt>
                          <dd>{sourceMediaInspection.channelLayout ?? "Unavailable"}</dd>
                        </div>
                        <div>
                          <dt>Bit depth</dt>
                          <dd>
                            {sourceMediaInspection.bitsPerSample
                              ? `${sourceMediaInspection.bitsPerSample}-bit`
                              : "Not declared"}
                          </dd>
                        </div>
                      </>
                    ) : (
                      <>
                        <div>
                          <dt>Resolution</dt>
                          <dd>
                            {sourceMediaInspection.width && sourceMediaInspection.height
                              ? `${sourceMediaInspection.width}×${sourceMediaInspection.height}`
                              : "Unavailable"}
                          </dd>
                        </div>
                        <div>
                          <dt>Frame rate</dt>
                          <dd>
                            {sourceMediaInspection.frameRate
                              ? `${sourceMediaInspection.frameRate.toFixed(2)} fps`
                              : "Unavailable"}
                          </dd>
                        </div>
                      </>
                    )}
                    {sourceMediaInspection.streams ? (
                      <>
                        <div>
                          <dt>Stream count</dt>
                          <dd>{sourceMediaInspection.streams.length}</dd>
                        </div>
                        {sourceMediaInspection.streams.map((stream, index) => (
                          <div key={`${stream.mediaType}-${index}`}>
                            <dt>
                              Stream {index + 1} ({
                                stream.mediaType === "video"
                                  ? "Video"
                                  : stream.mediaType === "audio"
                                    ? "Audio"
                                    : "Subtitle"
                              })
                            </dt>
                            <dd>{describeSourceStream(stream)}</dd>
                          </div>
                        ))}
                      </>
                    ) : null}
                    <div>
                      <dt>Metadata signals</dt>
                      <dd>
                        {sourceMediaInspection.metadataSignals.length
                          ? sourceMediaInspection.metadataSignals.join(", ")
                          : "None found in bounded scan"}
                      </dd>
                    </div>
                    <div>
                      <dt>Inspection read</dt>
                      <dd>
                        {sourceMediaInspection.inspectedBytes.toLocaleString(
                          "en-US",
                        )}{" "}
                        bytes (max{" "}
                        {sourceMediaInspection.maximumInspectionBytes.toLocaleString(
                          "en-US",
                        )})
                      </dd>
                    </div>
                  </>
                ) : null}
                {sourceStructuredInspection ? (
                  <>
                    <div>
                      <dt>Detected structure</dt>
                      <dd>{sourceStructuredInspection.structure}</dd>
                    </div>
                    <div>
                      <dt>Text encoding</dt>
                      <dd>UTF-8</dd>
                    </div>
                    {sourceStructuredInspection.facts.map((fact) => (
                      <div key={fact.label}>
                        <dt>{fact.label}</dt>
                        <dd>{fact.value}</dd>
                      </div>
                    ))}
                    <div>
                      <dt>Inspection read</dt>
                      <dd>
                        {sourceStructuredInspection.inspectedBytes.toLocaleString(
                          "en-US",
                        )}{" "}
                        bytes (max{" "}
                        {sourceStructuredInspection.maximumInspectionBytes.toLocaleString(
                          "en-US",
                        )})
                      </dd>
                    </div>
                  </>
                ) : null}
                {sourceImageInspection ? (
                  <>
                    <div>
                      <dt>Detected structure</dt>
                      <dd>{sourceImageInspection.format} image header</dd>
                    </div>
                    <div>
                      <dt>Dimensions</dt>
                      <dd>
                        {sourceImageInspection.width.toLocaleString("en-US")}×
                        {sourceImageInspection.height.toLocaleString("en-US")}
                      </dd>
                    </div>
                    <div>
                      <dt>Color model</dt>
                      <dd>{sourceImageInspection.colorModel}</dd>
                    </div>
                    <div>
                      <dt>Bit depth</dt>
                      <dd>
                        {sourceImageInspection.bitDepth
                          ? `${sourceImageInspection.bitDepth}-bit`
                          : "Validated during conversion"}
                      </dd>
                    </div>
                    <div>
                      <dt>Animation</dt>
                      <dd>{sourceImageInspection.animation}</dd>
                    </div>
                    <div>
                      <dt>Metadata signals</dt>
                      <dd>
                        {sourceImageInspection.metadataSignals.length
                          ? sourceImageInspection.metadataSignals.join(", ")
                          : "None found in bounded scan"}
                      </dd>
                    </div>
                    <div>
                      <dt>Inspection read</dt>
                      <dd>
                        {sourceImageInspection.inspectedBytes.toLocaleString(
                          "en-US",
                        )}{" "}
                        bytes (max{" "}
                        {sourceImageInspection.maximumInspectionBytes.toLocaleString(
                          "en-US",
                        )})
                      </dd>
                    </div>
                  </>
                ) : null}
                {sourcePackageInspection ? (
                  <>
                    <div>
                      <dt>Detected structure</dt>
                      <dd>{sourcePackageInspection.structure}</dd>
                    </div>
                    {sourcePackageInspection.facts.map((fact) => (
                      <div key={fact.label}>
                        <dt>{fact.label}</dt>
                        <dd>{fact.value}</dd>
                      </div>
                    ))}
                    <div>
                      <dt>Inspection read</dt>
                      <dd>
                        {sourcePackageInspection.inspectedBytes.toLocaleString(
                          "en-US",
                        )}{" "}
                        bytes (max{" "}
                        {sourcePackageInspection.maximumInspectionBytes.toLocaleString(
                          "en-US",
                        )})
                      </dd>
                    </div>
                  </>
                ) : null}
              </dl>
              <div data-testid="media-inspection-status">
                {sourceInspectionStatus === "inspecting" ? (
                  <p>Reading a bounded local header slice…</p>
                ) : sourceInspectionStatus === "error" ? (
                  <p>{sourceInspectionError}</p>
                ) : sourceMediaInspection ? (
                  <>
                    {sourceMediaInspection.notes.map((note) => (
                      <p key={note}>{note}</p>
                    ))}
                    <p>
                      These stream facts came from bounded local header reads for
                      {` ${file.name}`}; no media payload was uploaded or decoded.
                    </p>
                  </>
                ) : sourceStructuredInspection ? (
                  <>
                    {sourceStructuredInspection.notes.map((note) => (
                      <p key={note}>{note}</p>
                    ))}
                    <p>
                      These structural facts came from a bounded local UTF-8
                      read; source text was not displayed, retained, or uploaded.
                    </p>
                  </>
                ) : sourceImageInspection ? (
                  <>
                    {sourceImageInspection.notes.map((note) => (
                      <p key={note}>{note}</p>
                    ))}
                    <p>
                      These image facts came from a bounded local header read;
                      pixel data was not decoded, displayed, retained, or uploaded.
                    </p>
                  </>
                ) : sourcePackageInspection ? (
                  <>
                    {sourcePackageInspection.notes.map((note) => (
                      <p key={note}>{note}</p>
                    ))}
                    <p>
                      These package facts came from bounded local archive-metadata
                      reads; embedded filenames and file contents were not
                      displayed, retained, or uploaded.
                    </p>
                  </>
                ) : (
                  <p>
                    Detailed pre-conversion parsing is not yet implemented for this
                    format. The destination limitations below, when present,
                    describe planned exclusions. The selected worker validates
                    the file locally during conversion and reports unsupported
                    or unsafe input as an error.
                  </p>
                )}
              </div>
            </details>
          ) : null
  );
}

function renderOutputControls(model: ConverterAppModel) {
  const { batchFiles, jobState, profileId, profiles, selectedProfile, setAudioOptions, setAutomaticRouteNotice, setBatchCompleted, setCompletedBatchOutputNames, setDestinationDirectoryHandle, setDestinationHandle, setError, setJobState, setMetrics, setOpfsName, setOpfsNames, setPhase, setProfileId, setVideoOptions, setWarnings, sourceMediaInspection } = model;
  return (
<div className="control-grid">
                <label>
                  <span>Convert to</span>
                  <select
                    data-testid="format-select"
                    value={profileId ?? ""}
                    onChange={(event) => {
                      const nextProfileId = event.target.value;
                      const nextProfile = profiles.find(
                        (profile) => profile.id === nextProfileId,
                      );
                      const automatic =
                        nextProfile && sourceMediaInspection && batchFiles.length === 1
                          ? selectAutomaticMediaProfile(
                              nextProfile,
                              profiles,
                              sourceMediaInspection,
                            )
                          : null;
                      const effectiveProfile = automatic?.profile ?? nextProfile;
                      const nextAudioCodec = audioCodecForProfile(
                        effectiveProfile ?? null,
                      );
                      if (nextAudioCodec) {
                        setAudioOptions((current) =>
                          normalizeAudioConversionOptionsForCodec(
                            current,
                            nextAudioCodec,
                          ),
                        );
                      }
                      setProfileId(effectiveProfile?.id ?? nextProfileId);
                      setAudioOptions({ ...DEFAULT_AUDIO_CONVERSION_OPTIONS });
                      setVideoOptions({ ...DEFAULT_VIDEO_CONVERSION_OPTIONS });
                      setDestinationHandle(null);
                      setDestinationDirectoryHandle(null);
                      setJobState("idle");
                      setPhase("Ready");
                      setMetrics(null);
                      setWarnings([]);
                      setError(null);
                      setOpfsName(null);
                      setOpfsNames([]);
                      setCompletedBatchOutputNames([]);
                      setBatchCompleted(0);
                      setAutomaticRouteNotice(automatic?.reason ?? null);
                    }}
                    disabled={jobState === "running"}
                  >
                    {profiles.map((profile) => (
                      <option key={profile.id} value={profile.id}>
                        {formatById(profile.output)?.label ?? profile.output}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="route-panel">
                  <span>Processing route</span>
                  <strong>
                    {selectedProfile?.route === "stream"
                      ? "Bounded stream"
                      : selectedProfile?.route === "stream-copy"
                        ? "Lossless stream copy"
                        : "Decode + re-encode"}
                  </strong>
                </div>
              </div>
  );
}

function renderAudioControls(model: ConverterAppModel) {
  const { audioEncodingOptionsEnabled, audioOptions, jobState, selectableAudioProfiles, selectedAudioCodec, setAudioOptions, setProfileId } = model;
  return (
audioEncodingOptionsEnabled && selectedAudioCodec ? (
                <fieldset className="encoding-options" disabled={jobState === "running"}>
                  <legend>Audio encoding options</legend>
                  <p>
                    Automatic retains the fastest certified profile. Codec and
                    compression choices move to a genuinely tested destination;
                    custom values are applied by the native encoder.
                  </p>
                  <div className="encoding-options-grid">
                    <label>
                      <span>Codec</span>
                      <select
                        data-testid="audio-codec-select"
                        value={audioOptions.codec}
                        onChange={(event) => {
                          const codec = event.target.value as AudioConversionOptions["codec"];
                          const effectiveCodec =
                            codec === "automatic" ? selectedAudioCodec : codec;
                          setAudioOptions((current) =>
                            normalizeAudioConversionOptionsForCodec(
                              { ...current, codec, compression: "automatic" },
                              effectiveCodec,
                            ),
                          );
                          if (codec === "automatic") return;
                          const replacement = selectableAudioProfiles.find(
                            (profile) => audioCodecForProfile(profile) === codec,
                          );
                          if (replacement) setProfileId(replacement.id);
                        }}
                      >
                        <option value="automatic">
                          Automatic ({selectedAudioCodec.toUpperCase()})
                        </option>
                        {[...new Set(
                          selectableAudioProfiles
                            .map((profile) => audioCodecForProfile(profile))
                            .filter((codec): codec is NonNullable<typeof codec> => codec !== null),
                        )].map((codec) => (
                          <option key={codec} value={codec}>
                            {codec === "pcm" ? "PCM" : codec.toUpperCase()}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      <span>Compression</span>
                      <select
                        data-testid="audio-compression-select"
                        value={audioOptions.compression}
                        onChange={(event) => {
                          const compression = event.target.value as AudioConversionOptions["compression"];
                          const replacement =
                            compression === "automatic"
                              ? null
                              : selectableAudioProfiles.find((profile) => {
                                  const codec = audioCodecForProfile(profile);
                                  return codec && audioCompressionForCodec(codec) === compression;
                                });
                          const replacementCodec = audioCodecForProfile(
                            replacement ?? null,
                          );
                          setAudioOptions((current) =>
                            normalizeAudioConversionOptionsForCodec(
                              {
                                ...current,
                                codec: "automatic",
                                compression,
                              },
                              replacementCodec ?? selectedAudioCodec,
                            ),
                          );
                          if (replacement) setProfileId(replacement.id);
                        }}
                      >
                        <option value="automatic">
                          Automatic ({audioCompressionForCodec(selectedAudioCodec)})
                        </option>
                        {selectableAudioProfiles.some((profile) => {
                          const codec = audioCodecForProfile(profile);
                          return codec && audioCompressionForCodec(codec) === "lossy";
                        }) ? <option value="lossy">Lossy</option> : null}
                        {selectableAudioProfiles.some((profile) => {
                          const codec = audioCodecForProfile(profile);
                          return codec && audioCompressionForCodec(codec) === "lossless";
                        }) ? <option value="lossless">Lossless</option> : null}
                      </select>
                    </label>
                    <label>
                      <span>Bitrate</span>
                      <select
                        data-testid="audio-bitrate-select"
                        value={audioOptions.bitRateBps}
                        onChange={(event) =>
                          setAudioOptions((current) => ({
                            ...current,
                            bitRateBps: Number(event.target.value) as AudioConversionOptions["bitRateBps"],
                          }))
                        }
                      >
                        <option value={0}>Automatic</option>
                        {(selectedAudioCodec === "mp3" ||
                        selectedAudioCodec === "aac" ||
                        selectedAudioCodec === "opus" ||
                        selectedAudioCodec === "wma"
                          ? MP3_BIT_RATES_BPS
                          : []).map((value) => (
                          <option key={value} value={value}>
                            {value / 1_000} kb/s
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      <span>Sample rate</span>
                      <select
                        data-testid="audio-sample-rate-select"
                        value={audioOptions.sampleRateHz}
                        onChange={(event) =>
                          setAudioOptions((current) => ({
                            ...current,
                            sampleRateHz: Number(event.target.value) as AudioConversionOptions["sampleRateHz"],
                          }))
                        }
                      >
                        <option value={0}>Automatic</option>
                        {audioSampleRatesForCodec(selectedAudioCodec).map((value) => (
                          <option key={value} value={value}>
                            {value.toLocaleString("en-US")} Hz
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      <span>Channels</span>
                      <select
                        data-testid="audio-channels-select"
                        value={audioOptions.channels}
                        onChange={(event) =>
                          setAudioOptions((current) => ({
                            ...current,
                            channels: Number(event.target.value) as AudioConversionOptions["channels"],
                          }))
                        }
                      >
                        <option value={0}>Automatic</option>
                        {selectedAudioCodec !== "amr" ? (
                          <>
                            <option value={1}>Mono</option>
                            <option value={2}>Stereo</option>
                          </>
                        ) : null}
                      </select>
                    </label>
                    <label>
                      <span>Quality policy</span>
                      <select
                        data-testid="audio-quality-select"
                        value={audioOptions.quality}
                        onChange={(event) =>
                          setAudioOptions((current) => ({
                            ...current,
                            quality: event.target.value as AudioConversionOptions["quality"],
                          }))
                        }
                      >
                        {AUDIO_QUALITIES.map((quality) => (
                          <option
                            key={quality}
                            value={quality}
                            disabled={
                              quality !== "automatic" &&
                              !["mp3", "aac", "opus", "vorbis", "wma"].includes(
                                selectedAudioCodec,
                              )
                            }
                          >
                            {quality === "automatic"
                              ? "Automatic (fastest certified)"
                              : quality === "smaller"
                                ? "Smaller file"
                                : quality === "balanced"
                                  ? "Balanced"
                                  : "Higher quality"}
                          </option>
                        ))}
                      </select>
                    </label>
                  </div>
                </fieldset>
              ) : null
  );
}

function renderVideoControls(model: ConverterAppModel) {
  const { jobState, selectedProfile, setProfileId, setVideoOptions, videoEncodingOptionsEnabled, videoOptions } = model;
  return (
videoEncodingOptionsEnabled ? (
                <fieldset
                  className="encoding-options"
                  disabled={jobState === "running"}
                >
                  <legend>Video encoding options</legend>
                  <p>
                    Automatic retains the fastest certified profile. Width and
                    frame rate are no-upscale caps; the encoder never invents
                    resolution or frames above the source.
                  </p>
                  <div className="encoding-options-grid">
                    <label>
                      <span>Codec</span>
                      <select
                        data-testid="video-codec-select"
                        value={videoOptions.codec}
                        onChange={(event) => {
                          const codec =
                            event.target.value as VideoConversionOptions["codec"];
                          setVideoOptions((current) => ({
                            ...current,
                            codec,
                          }));
                          if (selectedProfile && codec === "vp9") {
                            const vp9Id = selectedProfile.id.endsWith("-vp9")
                              ? selectedProfile.id
                              : `${selectedProfile.id}-vp9`;
                            if (
                              conversionProfiles.some(
                                (profile) => profile.id === vp9Id,
                              )
                            ) {
                              setProfileId(vp9Id);
                            }
                          } else if (
                            selectedProfile &&
                            codec === "vp8" &&
                            selectedProfile.id.endsWith("-vp9")
                          ) {
                            setProfileId(selectedProfile.id.slice(0, -4));
                          }
                        }}
                      >
                        <option value="automatic">
                          Automatic ({selectedProfile?.output === "webm-vp9"
                            ? "VP9"
                            : selectedProfile?.output === "webm"
                              ? "VP8"
                              : selectedProfile?.output === "ogv"
                                ? "Theora"
                              : "MPEG-4 Part 2"})
                        </option>
                        {selectedProfile?.output === "ogv" ? (
                          <option value="theora">Theora</option>
                        ) : selectedProfile?.output === "webm" ||
                          selectedProfile?.output === "webm-vp9" ? (
                          <>
                            <option value="vp8">VP8</option>
                            <option value="vp9">VP9</option>
                          </>
                        ) : (
                          <option value="mpeg4">MPEG-4 Part 2</option>
                        )}
                      </select>
                    </label>
                    <label>
                      <span>Maximum width</span>
                      <select
                        data-testid="video-width-select"
                        value={videoOptions.maxWidth}
                        onChange={(event) =>
                          setVideoOptions((current) => ({
                            ...current,
                            maxWidth: Number(event.target.value) as VideoConversionOptions["maxWidth"],
                          }))
                        }
                      >
                        <option value={0}>Automatic</option>
                        {VIDEO_MAX_WIDTHS.map((value) => (
                          <option key={value} value={value}>
                            {value}px cap
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      <span>Bitrate</span>
                      <select
                        data-testid="video-bitrate-select"
                        value={videoOptions.bitRateBps}
                        disabled={selectedProfile?.output === "ogv"}
                        onChange={(event) =>
                          setVideoOptions((current) => ({
                            ...current,
                            bitRateBps: Number(event.target.value) as VideoConversionOptions["bitRateBps"],
                          }))
                        }
                      >
                        <option value={0}>
                          {selectedProfile?.output === "ogv"
                            ? "Quality-based VBR"
                            : "Automatic"}
                        </option>
                        {selectedProfile?.output !== "ogv"
                          ? VIDEO_BIT_RATES_BPS.map((value) => (
                              <option key={value} value={value}>
                                {value / 1_000} kb/s
                              </option>
                            ))
                          : null}
                      </select>
                    </label>
                    <label>
                      <span>Maximum frame rate</span>
                      <select
                        data-testid="video-frame-rate-select"
                        value={videoOptions.frameRateFps}
                        onChange={(event) =>
                          setVideoOptions((current) => ({
                            ...current,
                            frameRateFps: Number(event.target.value) as VideoConversionOptions["frameRateFps"],
                          }))
                        }
                      >
                        <option value={0}>Automatic</option>
                        {VIDEO_FRAME_RATES_FPS.map((value) => (
                          <option key={value} value={value}>
                            {value} fps cap
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      <span>Quality policy</span>
                      <select
                        data-testid="video-quality-select"
                        value={videoOptions.quality}
                        onChange={(event) =>
                          setVideoOptions((current) => ({
                            ...current,
                            quality: event.target.value as VideoConversionOptions["quality"],
                          }))
                        }
                      >
                        <option value="automatic">Automatic (fastest certified)</option>
                        <option value="smaller">Smaller file</option>
                        <option value="balanced">Balanced</option>
                        <option value="higher">Higher visual quality</option>
                      </select>
                    </label>
                  </div>
                </fieldset>
              ) : null
  );
}

function renderMediaPlan(model: ConverterAppModel) {
  const { batchFiles, mediaConversionPlan } = model;
  return (
mediaConversionPlan ? (
                <section
                  className="conversion-plan"
                  data-testid="media-conversion-plan"
                  aria-labelledby="media-conversion-plan-heading"
                >
                  <div className="conversion-plan-heading">
                    <strong id="media-conversion-plan-heading">
                      Conversion plan
                    </strong>
                    <span>Based on the bounded source scan</span>
                  </div>
                  {mediaConversionPlan.blockingReasons.length ? (
                    <div className="conversion-plan-blocker" role="alert">
                      <strong>This fixed profile cannot accept the inspected source.</strong>
                      <ul>
                        {mediaConversionPlan.blockingReasons.map((reason) => (
                          <li key={reason}>{reason}</li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                  <ul>
                    {mediaConversionPlan.streams.map((stream) => (
                      <li
                        key={`${stream.mediaType}-${stream.streamIndex}`}
                        data-testid={`media-plan-stream-${stream.streamIndex}`}
                      >
                        <span
                          className={`plan-action plan-action-${stream.action}`}
                        >
                          {mediaPlanActionLabel(stream.action)}
                        </span>
                        <span>
                          <strong>
                            Stream {stream.streamIndex + 1}: {stream.codec}
                          </strong>
                          {stream.detail}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <p>{mediaConversionPlan.metadataSummary}</p>
                  {batchFiles.length > 1 ? (
                    <p>
                      This preview describes the first selected file. Every batch
                      item is inspected and validated by the conversion engine
                      before output is committed.
                    </p>
                  ) : null}
                </section>
              ) : null
  );
}

function renderProgressPanel(model: ConverterAppModel) {
  const { estimatedRemainingMs, jobState, metrics, peakJsHeap, phase, progress, selectedProfile, throughput } = model;
  return (
metrics ? (
                <div className="progress-panel" aria-live="polite">
                  <div className="progress-topline">
                    <strong>{phase}</strong>
                    <span>{progress.toFixed(progress < 10 ? 1 : 0)}%</span>
                  </div>
                  <div className="progress-track" aria-hidden="true">
                    <span style={{ width: `${progress}%` }} />
                  </div>
                  <dl className="live-metrics">
                    <div>
                      <dt>Read</dt>
                      <dd>{formatBytes(metrics.inputBytes)}</dd>
                    </div>
                    <div>
                      <dt>Written</dt>
                      <dd>{formatBytes(metrics.outputBytes)}</dd>
                    </div>
                    <div>
                      <dt>Throughput</dt>
                      <dd>{formatBytes(throughput)}/s</dd>
                    </div>
                    <div>
                      <dt>Elapsed</dt>
                      <dd>{formatDuration(metrics.elapsedMs)}</dd>
                    </div>
                    <div>
                      <dt>Estimated remaining</dt>
                      <dd>
                        {jobState === "error" || jobState === "cancelled"
                          ? "Not applicable"
                          : estimatedRemainingMs == null
                          ? "Calculating"
                          : formatDuration(estimatedRemainingMs)}
                      </dd>
                    </div>
                    <div>
                      <dt>Active engine</dt>
                      <dd>{selectedProfile?.engine ?? "Unavailable"}</dd>
                    </div>
                    <div>
                      <dt>Queued</dt>
                      <dd>{formatBytes(metrics.queuedBytes)}</dd>
                    </div>
                    <div>
                      <dt>Peak Wasm</dt>
                      <dd>
                        {metrics.peakWasmMemoryBytes
                          ? formatBytes(metrics.peakWasmMemoryBytes)
                          : "Not used"}
                      </dd>
                    </div>
                    <div>
                      <dt>Conversion workers</dt>
                      <dd>{metrics.activeWorkerCount ?? "Unavailable"}</dd>
                    </div>
                    <div>
                      <dt>Peak JS heap</dt>
                      <dd>{peakJsHeap == null ? "Unavailable" : formatBytes(peakJsHeap)}</dd>
                    </div>
                    <div>
                      <dt>Incremental private</dt>
                      <dd>Profiler only</dd>
                    </div>
                  </dl>
                </div>
              ) : null
  );
}

function renderPrivacyProof(model: ConverterAppModel) {
  return (
<section className="proof-section" id="proof">
        <div className="section-intro">
          <p className="eyebrow">The privacy proof</p>
          <h2>Your file takes the short route.</h2>
          <p>
            Browser APIs connect a bounded reader to a worker and then directly
            to the destination you approve. The hosting server only supplies the
            app itself.
          </p>
        </div>
        <ol className="data-flow">
          <li>
            <span>1</span>
            <div>
              <strong>Open locally</strong>
              <p>Read small chunks from the original browser File.</p>
            </div>
          </li>
          <li>
            <span>2</span>
            <div>
              <strong>Process off-screen</strong>
              <p>A dedicated worker owns the active engine and its fixed buffers.</p>
            </div>
          </li>
          <li>
            <span>3</span>
            <div>
              <strong>Write with backpressure</strong>
              <p>One awaited write at a time prevents an output queue from growing.</p>
            </div>
          </li>
        </ol>
        {renderCapabilities(model)}
        {renderStorageManagement(model)}
      </section>
  );
}

function renderCapabilities(model: ConverterAppModel) {
  const { capabilityItems } = model;
  return (
<div className="capability-strip">
          {capabilityItems.map(([label, available]) => (
            <span key={label} className={available ? "yes" : "no"}>
              <i aria-hidden="true" />
              {label}
            </span>
          ))}
        </div>
  );
}

function renderStorageManagement(model: ConverterAppModel) {
  const { capabilities, cleanupMessage, clearAppTemporaryStorage, jobState, setCleanupMessage, storageQuota, storageUsage } = model;
  return (
<div className="storage-card">
          <div>
            <strong>App-owned temporary storage</strong>
            <p>
              {cleanupMessage} User-selected destination files are never included
              in this cleanup.
            </p>
            <small>
              {storageUsage == null
                ? "Browser storage usage unavailable"
                : `${formatBytes(storageUsage)} used${storageQuota == null ? "" : ` of ${formatBytes(storageQuota)}`}`}
            </small>
          </div>
          <button
            type="button"
            onClick={() => {
              setCleanupMessage("Checking app-owned temporary storage…");
              void clearAppTemporaryStorage()
                .then((removed) => {
                  setCleanupMessage(
                    removed
                      ? `Removed ${removed} app-owned temporary ${removed === 1 ? "file" : "files"}.`
                      : "No app-owned temporary files detected.",
                  );
                })
                .catch(() => {
                  setCleanupMessage(
                    "Temporary storage could not be cleared in this browser.",
                  );
                });
            }}
            disabled={jobState === "running" || !capabilities?.opfs}
          >
            Clear temporary storage
          </button>
        </div>
  );
}

function renderSiteFooter(model: ConverterAppModel) {
  const { jsHeap } = model;
  return (
<footer>
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            W
          </span>
          <span>Within</span>
        </div>
        <p>
          No accounts. No analytics. No file or filename telemetry. No PDFs.{" "}
          <a href="/THIRD_PARTY_NOTICES.txt">Codec notices</a>.
        </p>
        <span className="footer-memory">
          Current page JS heap: {jsHeap == null ? "unavailable" : formatBytes(jsHeap)}
        </span>
      </footer>
  );
}

function renderFileDrop(model: ConverterAppModel) {
  const { batchFiles, clearFile, dragging, file, fileInputRef, inputFormat, jobState, onDrop, onFileInput, setDragging, totalInputBytes } = model;
  return (
<div
            className={`drop-zone ${dragging ? "dragging" : ""} ${file ? "has-file" : ""}`}
            onDragEnter={(event) => {
              event.preventDefault();
              setDragging(true);
            }}
            onDragOver={(event) => event.preventDefault()}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
          >
            <input
              ref={fileInputRef}
              data-testid="file-input"
              id="file-input"
              type="file"
              multiple
              onChange={onFileInput}
              disabled={jobState === "running"}
            />
            {file ? (
              <div className="selected-file">
                <div className="file-glyph" aria-hidden="true">
                  {batchFiles.length > 1
                    ? "BATCH"
                    : file.name.split(".").pop()?.slice(0, 4).toUpperCase() ||
                      "FILE"}
                </div>
                <div className="file-copy">
                  <strong>
                    {file.name}
                    {batchFiles.length > 1
                      ? ` + ${batchFiles.length - 1} more`
                      : ""}
                  </strong>
                  <span>
                    {formatById(inputFormat)?.label ?? "Unknown format"} ·{" "}
                    {formatBytes(
                      batchFiles.length > 1 ? totalInputBytes : file.size,
                    )}
                  </span>
                </div>
                <button
                  className="text-button"
                  type="button"
                  onClick={clearFile}
                  disabled={jobState === "running"}
                >
                  Remove
                </button>
              </div>
            ) : (
              <label htmlFor="file-input">
                <span className="plus" aria-hidden="true">
                  +
                </span>
                <strong>Drop files here</strong>
                <span>or choose one or more matching files from your device</span>
              </label>
            )}
          </div>
  );
}

export function ConverterApp() {
  return renderConverterPage(useConverterAppModel());
}
