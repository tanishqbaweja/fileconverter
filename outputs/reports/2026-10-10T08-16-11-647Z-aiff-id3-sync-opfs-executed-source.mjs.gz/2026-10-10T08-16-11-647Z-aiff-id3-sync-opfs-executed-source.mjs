import { chromium } from "@playwright/test";
import { createHash } from "node:crypto";
import { execFile, spawn } from "node:child_process";
import { createReadStream } from "node:fs";
import {
  mkdir,
  lstat,
  realpath,
  mkdtemp,
  open,
  readFile,
  readdir,
  rm,
  stat,
  writeFile,
} from "node:fs/promises";
import { createServer } from "node:net";
import path from "node:path";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import { sampleChromiumTree, stableWindow } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/chromium-private-memory.mjs";
import { startParallelMemoryObserver } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/parallel-memory-observer.mjs";
import { combinedTreePeak } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/native-memory-history.mjs";
import { createOwnedRuntimeScratch, finishOwnedCleanup } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/owned-runtime-scratch.mjs";

const execFilePromise = promisify(execFile);
const execFileAsync = (command, args, options = {}) => execFilePromise(command, args, {
  ...options,
  env: options.env ?? runtimeScratch?.env ?? process.env,
  windowsHide: true,
});

function parseBoundedIntegerEnvironment(name, allowed) {
  const raw = process.env[name] ?? "0";
  const value = Number.parseInt(raw, 10);
  if (!allowed.includes(value) || String(value) !== raw) {
    throw new Error(`${name} must be one of: ${allowed.join(", ")}.`);
  }
  return value;
}

function parseBoundedStringEnvironment(name, allowed, defaultValue) {
  const value = process.env[name] ?? defaultValue;
  if (!allowed.includes(value)) {
    throw new Error(`${name} must be one of: ${allowed.join(", ")}.`);
  }
  return value;
}

const projectRoot = "H:\\Github Repositories\\fileconverter";
void fileURLToPath;
const fixturePath = path.resolve(
  projectRoot,
  process.argv[2] ?? "fixtures/stress/deterministic-256m.bin",
);
const profileId = process.argv[3] ?? "gzip-compress";
const audioOptions = {
  codec: parseBoundedStringEnvironment(
    "WITHIN_AUDIO_CODEC",
    [
      "automatic",
      "mp3",
      "aac",
      "opus",
      "vorbis",
      "wma",
      "amr",
      "flac",
      "alac",
      "pcm",
    ],
    "automatic",
  ),
  compression: parseBoundedStringEnvironment(
    "WITHIN_AUDIO_COMPRESSION",
    ["automatic", "lossy", "lossless"],
    "automatic",
  ),
  bitRateBps: parseBoundedIntegerEnvironment(
    "WITHIN_AUDIO_BIT_RATE_BPS",
    [0, 64_000, 96_000, 128_000, 192_000, 256_000, 320_000],
  ),
  sampleRateHz: parseBoundedIntegerEnvironment(
    "WITHIN_AUDIO_SAMPLE_RATE_HZ",
    [0, 24_000, 32_000, 44_100, 48_000],
  ),
  channels: parseBoundedIntegerEnvironment("WITHIN_AUDIO_CHANNELS", [0, 1, 2]),
  quality: parseBoundedStringEnvironment(
    "WITHIN_AUDIO_QUALITY",
    ["automatic", "smaller", "balanced", "higher"],
    "automatic",
  ),
};
const videoOptions = {
  codec: parseBoundedStringEnvironment(
    "WITHIN_VIDEO_CODEC",
    ["automatic", "vp8", "vp9", "mpeg4", "theora"],
    "automatic",
  ),
  maxWidth: parseBoundedIntegerEnvironment(
    "WITHIN_VIDEO_MAX_WIDTH",
    [0, 320, 480, 640],
  ),
  bitRateBps: parseBoundedIntegerEnvironment(
    "WITHIN_VIDEO_BIT_RATE_BPS",
    [0, 300_000, 600_000, 1_000_000, 2_000_000, 4_000_000],
  ),
  frameRateFps: parseBoundedIntegerEnvironment(
    "WITHIN_VIDEO_FRAME_RATE_FPS",
    [0, 15, 24, 25, 30],
  ),
  quality: parseBoundedStringEnvironment(
    "WITHIN_VIDEO_QUALITY",
    ["automatic", "smaller", "balanced", "higher"],
    "automatic",
  ),
};
const AIFF_OUTPUT_PROFILES = [
  "3gp-to-aiff",
  "m4a-to-aiff",
  "aac-to-aiff",
  "amr-to-aiff",
  "amr-wb-to-aiff",
  "mp3-to-aiff",
  "flac-to-aiff",
  "wav-to-aiff",
  "wma-to-aiff",
  "ogg-to-aiff",
  "opus-to-aiff",
  "mkv-to-aiff",
  "mp4-to-aiff",
  "mov-to-aiff",
  "mpeg-ts-to-aiff",
  "flv-to-aiff",
  "avi-to-aiff",
  "ogv-to-aiff",
  "webm-to-aiff",
];
const AMR_OUTPUT_PROFILES = [
  "3gp-to-amr",
  "webm-to-amr",
  "mkv-to-amr",
  "mp4-to-amr",
  "mov-to-amr",
  "mpeg-ts-to-amr",
  "flv-to-amr",
  "avi-to-amr",
  "ogv-to-amr",
  "m4a-to-amr",
  "aac-to-amr",
  "mp3-to-amr",
  "flac-to-amr",
  "wav-to-amr",
  "wma-to-amr",
  "aiff-to-amr",
  "ogg-to-amr",
  "opus-to-amr",
];
const MP3_OUTPUT_PROFILES = [
  "webm-to-mp3",
  "ogv-to-mp3",
  "3gp-to-mp3",
  "m4a-to-mp3",
  "aac-to-mp3",
  "amr-to-mp3",
  "amr-wb-to-mp3",
  "flac-to-mp3",
  "wav-to-mp3",
  "wma-to-mp3",
  "aiff-to-mp3",
  "ogg-to-mp3",
  "opus-to-mp3",
];
const COMPATIBLE_AVI_PROFILES = [
  "mkv-to-avi",
  "mp4-to-avi",
  "mov-to-avi",
  "3gp-to-avi",
  "mpeg-ts-to-avi",
];
const IVF_PROFILES = ["mkv-to-ivf", "webm-to-ivf"];
const IVF_INPUT_PROFILES = ["ivf-to-webm", "ivf-to-mkv"];
const COMPATIBLE_WEBM_PROFILES = [
  "mkv-to-webm-av1",
  "mp4-to-webm-av1",
];
const THEORA_OGV_PROFILES = ["avi-to-ogv", "mp4-to-ogv", "m2v-to-ogv"];
const isIvfProfile =
  IVF_PROFILES.includes(profileId) || IVF_INPUT_PROFILES.includes(profileId);
const isVideoOptionsProfile =
  /^(?:mkv|mp4|mov|3gp|mpeg-ts|flv|avi|ogv|m2v|h264)-to-webm(?:-vp9)?$/.test(
    profileId,
  ) ||
  /^(?:mkv|m2v)-to-mp4-mpeg4$/.test(profileId) ||
  THEORA_OGV_PROFILES.includes(profileId);
if (
  (videoOptions.codec !== "automatic" ||
    videoOptions.maxWidth !== 0 ||
    videoOptions.bitRateBps !== 0 ||
    videoOptions.frameRateFps !== 0 ||
    videoOptions.quality !== "automatic") &&
  !isVideoOptionsProfile
) {
  throw new Error(
    "Custom video options are supported only for public video re-encode profiles.",
  );
}
const AAC_OUTPUT_PROFILES = [
  "webm-to-aac",
  "avi-to-aac",
  "ogv-to-aac",
  "m4a-to-aac",
  "amr-to-aac",
  "amr-wb-to-aac",
  "mp3-to-aac",
  "flac-to-aac",
  "wav-to-aac",
  "wma-to-aac",
  "aiff-to-aac",
  "ogg-to-aac",
  "opus-to-aac",
];
const M4A_TRANSCODE_OUTPUT_PROFILES = [
  "avi-to-m4a",
  "ogv-to-m4a",
  "webm-to-m4a",
];
const OPUS_OUTPUT_PROFILES = [
  "mp4-to-opus",
  "mov-to-opus",
  "mpeg-ts-to-opus",
  "flv-to-opus",
  "avi-to-opus",
  "ogv-to-opus",
  "3gp-to-opus",
  "m4a-to-opus",
  "aac-to-opus",
  "amr-to-opus",
  "amr-wb-to-opus",
  "mp3-to-opus",
  "flac-to-opus",
  "wav-to-opus",
  "wma-to-opus",
  "aiff-to-opus",
  "ogg-to-opus",
];
const VORBIS_OUTPUT_PROFILES = [
  "mp4-to-ogg",
  "mov-to-ogg",
  "mpeg-ts-to-ogg",
  "flv-to-ogg",
  "avi-to-ogg",
  "3gp-to-ogg",
  "m4a-to-ogg",
  "aac-to-ogg",
  "amr-to-ogg",
  "amr-wb-to-ogg",
  "mp3-to-ogg",
  "flac-to-ogg",
  "wav-to-ogg",
  "wma-to-ogg",
  "aiff-to-ogg",
  "opus-to-ogg",
];
const WMA_OUTPUT_PROFILES = [
  "m4a-to-wma",
  "aac-to-wma",
  "amr-wb-to-wma",
  "mp3-to-wma",
  "aiff-to-wma",
  "ogg-to-wma",
  "opus-to-wma",
  "wav-to-wma",
  "flac-to-wma",
  "mkv-to-wma",
  "mp4-to-wma",
  "mov-to-wma",
  "3gp-to-wma",
  "mpeg-ts-to-wma",
  "flv-to-wma",
  "avi-to-wma",
  "ogv-to-wma",
  "webm-to-wma",
];
const isAudioOptionsProfile =
  MP3_OUTPUT_PROFILES.includes(profileId) ||
  AAC_OUTPUT_PROFILES.includes(profileId) ||
  M4A_TRANSCODE_OUTPUT_PROFILES.includes(profileId) ||
  OPUS_OUTPUT_PROFILES.includes(profileId) ||
  VORBIS_OUTPUT_PROFILES.includes(profileId) ||
  WMA_OUTPUT_PROFILES.includes(profileId) ||
  AMR_OUTPUT_PROFILES.includes(profileId) ||
  AIFF_OUTPUT_PROFILES.includes(profileId) ||
  profileId.endsWith("-to-wav") ||
  profileId.endsWith("-to-flac") ||
  profileId === "wav-to-alac" ||
  profileId === "flac-to-alac";
const hasCustomAudioOptions =
  audioOptions.codec !== "automatic" ||
  audioOptions.compression !== "automatic" ||
  audioOptions.bitRateBps !== 0 ||
  audioOptions.sampleRateHz !== 0 ||
  audioOptions.channels !== 0 ||
  audioOptions.quality !== "automatic";
if (hasCustomAudioOptions && !isAudioOptionsProfile) {
  throw new Error(
    "Custom audio options are supported only for public audio re-encode profiles.",
  );
}
const manifestPath = path.resolve(
  projectRoot,
  process.argv[4] ?? `${fixturePath}.json`,
);
const fixtureManifest = JSON.parse(await readFile(manifestPath, "utf8"));
const isImageProfile =
  /^(?:(?:png|jpeg|webp|gif|avif|bmp)-to-(?:png|jpeg|webp|bmp|ico|jxl|avif)|(?:png|gif|webp|avif|jxl)-to-zip|(?:gif|webp)-to-apng|(?:png|webp)-to-gif|tiff-to-(?:png|zip)|jxl-to-png|svg-to-png)$/.test(
    profileId,
  );
const isAnimatedFrameArchiveProfile = /^(?:png|gif|webp|avif|jxl)-to-zip$/.test(
  profileId,
);
const isAnimatedApngProfile = /^(?:gif|webp)-to-apng$/.test(profileId);
const isAnimatedGifProfile = /^(?:png|webp)-to-gif$/.test(profileId);
const isAnimatedWebpProfile =
  /^(?:png|gif)-to-webp$/.test(profileId) &&
  Number(fixtureManifest.probe?.streams?.[0]?.nb_frames ?? 1) > 1;
const isAnimatedJxlProfile =
  /^(?:png|gif|webp|avif)-to-jxl$/.test(profileId) &&
  fixtureManifest.probe?.streams?.some(
    (stream) => Number(stream.nb_frames ?? stream.nb_read_frames ?? 1) > 1,
  );
const isTiffPageArchiveProfile = profileId === "tiff-to-zip";
const isDocxOutputProfile = profileId === "txt-to-docx";
const isOdtOutputProfile = profileId === "txt-to-odt";
const isMarkdownEpubOutputProfile = profileId === "md-to-epub";
const isEpubOutputProfile =
  profileId === "txt-to-epub" || isMarkdownEpubOutputProfile;
const isStreamingTextProfile =
  /^(?:csv|tsv|ndjson|json)-to-(?:csv|tsv|ndjson|json)$/.test(profileId) ||
  profileId === "srt-to-vtt" ||
  profileId === "vtt-to-srt" ||
  profileId === "srt-to-ass" ||
  profileId === "vtt-to-ass" ||
  profileId === "ass-to-srt" ||
  profileId === "ass-to-vtt" ||
  profileId === "srt-to-ttml" ||
  profileId === "vtt-to-ttml" ||
  profileId === "ttml-to-srt" ||
  profileId === "ttml-to-vtt" ||
  profileId === "txt-to-html" ||
  isDocxOutputProfile ||
  isOdtOutputProfile ||
  isEpubOutputProfile ||
  profileId === "md-to-html" ||
  profileId === "html-to-txt" ||
  profileId === "docx-to-txt" ||
  profileId === "epub-to-txt" ||
  profileId === "pptx-to-txt" ||
  profileId === "odt-to-txt" ||
  profileId === "ods-to-csv" ||
  profileId === "odp-to-txt" ||
  profileId === "xlsx-to-csv" ||
  profileId === "xml-to-ndjson";
const isArchiveCompressionProfile =
  profileId === "tar-to-tar-gz" || profileId === "tar-gz-to-tar";
const isCompressionTranscodeProfile = [
  "gzip-to-bzip2",
  "gzip-to-xz",
  "bzip2-to-gzip",
  "bzip2-to-xz",
  "xz-to-gzip",
  "xz-to-bzip2",
].includes(profileId);
const isBzip2Profile =
  profileId === "bzip2-compress" ||
  profileId === "bzip2-decompress" ||
  profileId === "tar-to-tar-bz2" ||
  profileId === "tar-bz2-to-tar" ||
  profileId === "tar-bz2-to-zip" ||
  profileId === "zip-to-tar-bz2" ||
  profileId === "sevenzip-to-tar-bz2" ||
  profileId === "tar-bz2-to-sevenzip" ||
  profileId === "tar-gz-to-tar-bz2" ||
  profileId === "tar-bz2-to-tar-gz" ||
  profileId === "tar-bz2-to-tar-xz" ||
  profileId === "tar-xz-to-tar-bz2" ||
  profileId === "gzip-to-bzip2" ||
  profileId === "bzip2-to-gzip" ||
  profileId === "bzip2-to-xz" ||
  profileId === "xz-to-bzip2";
const isBzip2CompressedOutput =
  profileId === "bzip2-compress" ||
  profileId === "tar-to-tar-bz2" ||
  profileId === "tar-gz-to-tar-bz2" ||
  profileId === "tar-xz-to-tar-bz2" ||
  profileId === "gzip-to-bzip2" ||
  profileId === "xz-to-bzip2";
const isXzProfile =
  profileId === "xz-compress" ||
  profileId === "xz-decompress" ||
  profileId === "tar-to-tar-xz" ||
  profileId === "tar-xz-to-tar" ||
  profileId === "tar-xz-to-zip" ||
  profileId === "zip-to-tar-xz" ||
  profileId === "sevenzip-to-tar-xz" ||
  profileId === "tar-xz-to-sevenzip" ||
  profileId === "tar-gz-to-tar-xz" ||
  profileId === "tar-bz2-to-tar-xz" ||
  profileId === "tar-xz-to-tar-gz" ||
  profileId === "tar-xz-to-tar-bz2" ||
  profileId === "gzip-to-xz" ||
  profileId === "bzip2-to-xz" ||
  profileId === "xz-to-gzip" ||
  profileId === "xz-to-bzip2";
const isXzCompressedOutput =
  profileId === "xz-compress" ||
  profileId === "tar-to-tar-xz" ||
  profileId === "tar-gz-to-tar-xz" ||
  profileId === "tar-bz2-to-tar-xz" ||
  profileId === "gzip-to-xz" ||
  profileId === "bzip2-to-xz";
const isGzipCompressedOutput =
  profileId === "gzip-compress" ||
  profileId === "tar-to-tar-gz" ||
  profileId === "bzip2-to-gzip" ||
  profileId === "xz-to-gzip";
const isSevenZipProfile =
  profileId === "tar-to-sevenzip" ||
  profileId === "tar-gz-to-sevenzip" ||
  profileId === "tar-bz2-to-sevenzip" ||
  profileId === "tar-xz-to-sevenzip" ||
  profileId === "zip-to-sevenzip" ||
  profileId === "sevenzip-to-tar" ||
  profileId === "sevenzip-to-tar-gz" ||
  profileId === "sevenzip-to-tar-bz2" ||
  profileId === "sevenzip-to-tar-xz" ||
  profileId === "sevenzip-to-zip";
const isArchiveTransformProfile =
  profileId === "zip-to-tar" ||
  profileId === "zip-to-tar-gz" ||
  profileId === "tar-to-zip" ||
  profileId === "tar-gz-to-zip" ||
  profileId === "tar-bz2-to-zip" ||
  profileId === "tar-xz-to-zip" ||
  profileId === "zip-to-tar-bz2" ||
  profileId === "zip-to-tar-xz" ||
  profileId === "tar-gz-to-tar-bz2" ||
  profileId === "tar-gz-to-tar-xz" ||
  profileId === "tar-bz2-to-tar-gz" ||
  profileId === "tar-bz2-to-tar-xz" ||
  profileId === "tar-xz-to-tar-gz" ||
  profileId === "tar-xz-to-tar-bz2" ||
  isSevenZipProfile;
const isSevenZipOutputProfile =
  profileId === "tar-to-sevenzip" ||
  profileId === "tar-gz-to-sevenzip" ||
  profileId === "tar-bz2-to-sevenzip" ||
  profileId === "tar-xz-to-sevenzip" ||
  profileId === "zip-to-sevenzip";
if (
  ![
    ...AIFF_OUTPUT_PROFILES,
    ...AMR_OUTPUT_PROFILES,
    ...MP3_OUTPUT_PROFILES,
    ...AAC_OUTPUT_PROFILES,
    ...M4A_TRANSCODE_OUTPUT_PROFILES,
    ...OPUS_OUTPUT_PROFILES,
    ...VORBIS_OUTPUT_PROFILES,
    "gzip-compress",
    "gzip-decompress",
    "bzip2-compress",
    "bzip2-decompress",
    "tar-to-tar-bz2",
    "tar-bz2-to-tar",
    "tar-bz2-to-zip",
    "zip-to-tar-bz2",
    "xz-compress",
    "xz-decompress",
    "tar-to-tar-xz",
    "tar-xz-to-tar",
    "tar-xz-to-zip",
    "zip-to-tar-xz",
    "mkv-to-mp4",
    "mov-to-mp4",
    "3gp-to-mp4",
    "mpeg-ts-to-mp4",
    "flv-to-mp4",
    "avi-to-mp4",
    "h264-to-mp4",
    "mkv-to-h264",
    "mp4-to-h264",
    "mov-to-h264",
    "3gp-to-h264",
    "mpeg-ts-to-h264",
    "flv-to-h264",
    "mkv-to-hevc",
    "mp4-to-hevc",
    "mov-to-hevc",
    "mpeg-ts-to-hevc",
    "mp4-to-mkv",
    "mov-to-mkv",
    "3gp-to-mkv",
    "mpeg-ts-to-mkv",
    "flv-to-mkv",
    "avi-to-mkv",
    "webm-to-mkv",
    "ogv-to-mkv",
    "mkv-to-mpeg-ts",
    "mp4-to-mpeg-ts",
    "mov-to-mpeg-ts",
    "3gp-to-mpeg-ts",
    "flv-to-mpeg-ts",
    "avi-to-mpeg-ts",
    "mkv-to-3gp",
    "mp4-to-3gp",
    "mov-to-3gp",
    "mpeg-ts-to-3gp",
    "flv-to-3gp",
    "avi-to-3gp",
    "mkv-to-mov",
    "mp4-to-mov",
    "3gp-to-mov",
    "mpeg-ts-to-mov",
    "flv-to-mov",
    "avi-to-mov",
    "mkv-to-flv",
    "mp4-to-flv",
    "mov-to-flv",
    "3gp-to-flv",
    "mpeg-ts-to-flv",
    "avi-to-flv",
    "m2v-to-mpeg-ts",
    "mkv-to-m2v",
    "mp4-to-m2v",
    "mov-to-m2v",
    "avi-to-m2v",
    "mpeg-ts-to-m2v",
    "m4v-to-mp4",
    "mkv-to-m4v",
    "mp4-to-m4v",
    "mov-to-m4v",
    "avi-to-m4v",
    "mkv-to-ogv",
    ...COMPATIBLE_AVI_PROFILES,
    ...IVF_PROFILES,
    ...IVF_INPUT_PROFILES,
    ...COMPATIBLE_WEBM_PROFILES,
    "mkv-to-mp3",
    "mp4-to-mp3",
    "mov-to-mp3",
    "avi-to-mp3",
    "mpeg-ts-to-mp3",
    "flv-to-mp3",
    "mkv-to-aac",
    "mp4-to-aac",
    "mov-to-aac",
    "3gp-to-aac",
    "mpeg-ts-to-aac",
    "flv-to-aac",
    "mkv-to-ogg",
    "webm-to-ogg",
    "ogv-to-ogg",
    "mkv-to-opus",
    "webm-to-opus",
    "mkv-to-m4a",
    "mov-to-m4a",
    "3gp-to-m4a",
    "mpeg-ts-to-m4a",
    "flv-to-m4a",
    "mp4-to-m4a",
    "aac-to-m4a",
    "mkv-to-wav",
    "mov-to-wav",
    "3gp-to-wav",
    "mpeg-ts-to-wav",
    "flv-to-wav",
    "avi-to-wav",
    "mp4-to-wav",
    "m4a-to-wav",
    "aac-to-wav",
    "amr-to-wav",
    "amr-wb-to-wav",
    "mp3-to-wav",
    "flac-to-wav",
    "wma-to-wav",
    "aiff-to-wav",
    "ogg-to-wav",
    "opus-to-wav",
    "webm-to-wav",
    "m4a-to-flac",
    "mkv-to-flac",
    "mp4-to-flac",
    "mov-to-flac",
    "3gp-to-flac",
    "mpeg-ts-to-flac",
    "flv-to-flac",
    "avi-to-flac",
    "ogv-to-flac",
    "aac-to-flac",
    "amr-to-flac",
    "amr-wb-to-flac",
    "mp3-to-flac",
    "wav-to-flac",
    "wma-to-flac",
    "aiff-to-flac",
    "ogg-to-flac",
    "opus-to-flac",
    "webm-to-flac",
    "wav-to-alac",
    "flac-to-alac",
    ...WMA_OUTPUT_PROFILES,
    "mkv-to-mp4-mpeg4",
    "mkv-to-webm",
    "mkv-to-webm-vp9",
    "mp4-to-webm",
    "mp4-to-webm-vp9",
    "mov-to-webm",
    "mov-to-webm-vp9",
    "3gp-to-webm",
    "3gp-to-webm-vp9",
    "mpeg-ts-to-webm",
    "mpeg-ts-to-webm-vp9",
    "flv-to-webm",
    "flv-to-webm-vp9",
    "avi-to-webm",
    "avi-to-webm-vp9",
    "avi-to-ogv",
    "mp4-to-ogv",
    "m2v-to-ogv",
    "ogv-to-webm",
    "ogv-to-webm-vp9",
    "ogv-to-wav",
    "m2v-to-mp4-mpeg4",
    "m2v-to-webm",
    "m2v-to-webm-vp9",
    "h264-to-webm",
    "h264-to-webm-vp9",
    "hevc-to-webm",
    "hevc-to-webm-vp9",
  ].includes(profileId) &&
  !isImageProfile &&
  !isStreamingTextProfile &&
  !isArchiveCompressionProfile &&
  !isCompressionTranscodeProfile &&
  !isArchiveTransformProfile
) {
  throw new Error(`Unsupported memory-profile route: ${profileId}`);
}
const isMediaProfile =
  AIFF_OUTPUT_PROFILES.includes(profileId) ||
  AMR_OUTPUT_PROFILES.includes(profileId) ||
  MP3_OUTPUT_PROFILES.includes(profileId) ||
  AAC_OUTPUT_PROFILES.includes(profileId) ||
  M4A_TRANSCODE_OUTPUT_PROFILES.includes(profileId) ||
  OPUS_OUTPUT_PROFILES.includes(profileId) ||
  VORBIS_OUTPUT_PROFILES.includes(profileId) ||
  WMA_OUTPUT_PROFILES.includes(profileId) ||
  profileId === "mkv-to-mp4" ||
  profileId === "mov-to-mp4" ||
  profileId === "3gp-to-mp4" ||
  profileId === "mpeg-ts-to-mp4" ||
  profileId === "flv-to-mp4" ||
  profileId === "avi-to-mp4" ||
  profileId === "h264-to-mp4" ||
  profileId === "mkv-to-h264" ||
  profileId === "mp4-to-h264" ||
  profileId === "mov-to-h264" ||
  profileId === "3gp-to-h264" ||
  profileId === "mpeg-ts-to-h264" ||
  profileId === "flv-to-h264" ||
  profileId === "mkv-to-hevc" ||
  profileId === "mp4-to-hevc" ||
  profileId === "mov-to-hevc" ||
  profileId === "mpeg-ts-to-hevc" ||
  profileId === "mp4-to-mkv" ||
  profileId === "mov-to-mkv" ||
  profileId === "3gp-to-mkv" ||
  profileId === "mpeg-ts-to-mkv" ||
  profileId === "flv-to-mkv" ||
  profileId === "avi-to-mkv" ||
  profileId === "webm-to-mkv" ||
  profileId === "ogv-to-mkv" ||
  profileId === "mkv-to-mpeg-ts" ||
  profileId === "mp4-to-mpeg-ts" ||
  profileId === "mov-to-mpeg-ts" ||
  profileId === "3gp-to-mpeg-ts" ||
  profileId === "flv-to-mpeg-ts" ||
  profileId === "avi-to-mpeg-ts" ||
  profileId === "mkv-to-3gp" ||
  profileId === "mp4-to-3gp" ||
  profileId === "mov-to-3gp" ||
  profileId === "mpeg-ts-to-3gp" ||
  profileId === "flv-to-3gp" ||
  profileId === "avi-to-3gp" ||
  profileId === "mkv-to-mov" ||
  profileId === "mp4-to-mov" ||
  profileId === "3gp-to-mov" ||
  profileId === "mpeg-ts-to-mov" ||
  profileId === "flv-to-mov" ||
  profileId === "avi-to-mov" ||
  profileId === "mkv-to-flv" ||
  profileId === "mp4-to-flv" ||
  profileId === "mov-to-flv" ||
  profileId === "3gp-to-flv" ||
  profileId === "mpeg-ts-to-flv" ||
  profileId === "avi-to-flv" ||
  THEORA_OGV_PROFILES.includes(profileId) ||
  profileId === "m2v-to-mpeg-ts" ||
  profileId === "mkv-to-m2v" ||
  profileId === "mp4-to-m2v" ||
  profileId === "mov-to-m2v" ||
  profileId === "avi-to-m2v" ||
  profileId === "mpeg-ts-to-m2v" ||
  profileId === "m4v-to-mp4" ||
  profileId === "mkv-to-m4v" ||
  profileId === "mp4-to-m4v" ||
  profileId === "mov-to-m4v" ||
  profileId === "avi-to-m4v" ||
  profileId === "mkv-to-ogv" ||
  COMPATIBLE_AVI_PROFILES.includes(profileId) ||
  isIvfProfile ||
  COMPATIBLE_WEBM_PROFILES.includes(profileId) ||
  profileId === "mkv-to-mp3" ||
  profileId === "mp4-to-mp3" ||
  profileId === "mov-to-mp3" ||
  profileId === "avi-to-mp3" ||
  profileId === "mpeg-ts-to-mp3" ||
  profileId === "flv-to-mp3" ||
  profileId === "mkv-to-aac" ||
  profileId === "mp4-to-aac" ||
  profileId === "mov-to-aac" ||
  profileId === "3gp-to-aac" ||
  profileId === "mpeg-ts-to-aac" ||
  profileId === "flv-to-aac" ||
  profileId === "mkv-to-ogg" ||
  profileId === "webm-to-ogg" ||
  profileId === "ogv-to-ogg" ||
  profileId === "mkv-to-opus" ||
  profileId === "webm-to-opus" ||
  profileId === "mkv-to-m4a" ||
  profileId === "mov-to-m4a" ||
  profileId === "3gp-to-m4a" ||
  profileId === "mpeg-ts-to-m4a" ||
  profileId === "flv-to-m4a" ||
  profileId === "mp4-to-m4a" ||
  profileId === "aac-to-m4a" ||
  profileId === "mkv-to-wav" ||
  profileId === "mov-to-wav" ||
  profileId === "3gp-to-wav" ||
  profileId === "mpeg-ts-to-wav" ||
  profileId === "flv-to-wav" ||
  profileId === "avi-to-wav" ||
  profileId === "mp4-to-wav" ||
  profileId === "m4a-to-wav" ||
  profileId === "aac-to-wav" ||
  profileId === "amr-to-wav" ||
  profileId === "amr-wb-to-wav" ||
  profileId === "mp3-to-wav" ||
  profileId === "flac-to-wav" ||
  profileId === "wma-to-wav" ||
  profileId === "aiff-to-wav" ||
  profileId === "ogg-to-wav" ||
  profileId === "opus-to-wav" ||
  profileId === "webm-to-wav" ||
  profileId === "m4a-to-flac" ||
  profileId === "mkv-to-flac" ||
  profileId === "mp4-to-flac" ||
  profileId === "mov-to-flac" ||
  profileId === "3gp-to-flac" ||
  profileId === "mpeg-ts-to-flac" ||
  profileId === "flv-to-flac" ||
  profileId === "avi-to-flac" ||
  profileId === "ogv-to-flac" ||
  profileId === "aac-to-flac" ||
  profileId === "amr-to-flac" ||
  profileId === "amr-wb-to-flac" ||
  profileId === "mp3-to-flac" ||
  profileId === "wav-to-flac" ||
  profileId === "wma-to-flac" ||
  profileId === "aiff-to-flac" ||
  profileId === "ogg-to-flac" ||
  profileId === "opus-to-flac" ||
  profileId === "webm-to-flac" ||
  profileId === "wav-to-alac" ||
  profileId === "flac-to-alac" ||
  WMA_OUTPUT_PROFILES.includes(profileId) ||
  profileId === "mkv-to-mp4-mpeg4" ||
  profileId === "mkv-to-webm" ||
  profileId === "mkv-to-webm-vp9" ||
  profileId === "mp4-to-webm" ||
  profileId === "mp4-to-webm-vp9" ||
  profileId === "mov-to-webm" ||
  profileId === "mov-to-webm-vp9" ||
  profileId === "3gp-to-webm" ||
  profileId === "3gp-to-webm-vp9" ||
  profileId === "mpeg-ts-to-webm" ||
  profileId === "mpeg-ts-to-webm-vp9" ||
  profileId === "flv-to-webm" ||
  profileId === "flv-to-webm-vp9" ||
  profileId === "avi-to-webm" ||
  profileId === "avi-to-webm-vp9" ||
  profileId === "ogv-to-webm" ||
  profileId === "ogv-to-webm-vp9" ||
  profileId === "ogv-to-wav" ||
  profileId === "m2v-to-mp4-mpeg4" ||
  profileId === "m2v-to-webm" ||
  profileId === "m2v-to-webm-vp9" ||
  profileId === "h264-to-webm" ||
  profileId === "h264-to-webm-vp9" ||
  profileId === "hevc-to-webm" ||
  profileId === "hevc-to-webm-vp9";
const expectedProfileValidation =
  fixtureManifest.expectedByProfile?.[profileId];
const expectedValidationBytes =
  expectedProfileValidation?.validationBytes ??
  fixtureManifest.validationBytes ??
  fixtureManifest.bytes;
const expectedValidationHash =
  expectedProfileValidation?.validationSha256 ??
  fixtureManifest.validationSha256 ??
  fixtureManifest.sha256;
const workRoot = path.resolve(projectRoot, "work");
const profileRoot = "H:\\Github Repositories\\fileconverter\\work\\aiff-id3-stress-KxVK4X\\chrome-profile";
const reportRoot = "H:\\Github Repositories\\fileconverter\\outputs\\reports\\aiff-id3-stress-KxVK4X";
const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const wranglerEntry = path.resolve(
  projectRoot,
  "node_modules",
  "wrangler",
  "bin",
  "wrangler.js",
);
const serverPort = await reserveAvailablePort();
const serverUrl = `http://127.0.0.1:${serverPort}`;
const sampleIntervalMs = 1_000;
const cleanupRecoveryLimitMiB = 96;
const runCount = Number.parseInt(process.env.WITHIN_RUN_COUNT ?? "3", 10);
if (!Number.isInteger(runCount) || runCount < 1 || runCount > 10) {
  throw new Error(`Invalid WITHIN_RUN_COUNT: ${process.env.WITHIN_RUN_COUNT}`);
}
const destinationMode = process.env.WITHIN_DESTINATION_MODE ?? "sync-opfs";
if (!new Set(["sync-opfs", "direct-handle"]).has(destinationMode)) {
  throw new Error(
    `Invalid WITHIN_DESTINATION_MODE: ${process.env.WITHIN_DESTINATION_MODE}`,
  );
}
const maximumWriteChunkBytes =
  destinationMode === "direct-handle" &&
  (profileId === "mkv-to-mp4" || IVF_INPUT_PROFILES.includes(profileId))
    ? 1024 * 1024
    : isBzip2Profile || isXzProfile || isSevenZipProfile
      ? 64 * 1024
      : 256 * 1024;
const maximumWasmMemoryBytes =
  profileId === "tar-bz2-to-tar-xz" ||
  profileId === "tar-xz-to-tar-bz2" ||
  profileId === "bzip2-to-xz" ||
  profileId === "xz-to-bzip2"
    ? 56 * 1024 * 1024
    : profileId === "sevenzip-to-tar-bz2"
      ? 64 * 1024 * 1024
      : profileId === "tar-bz2-to-sevenzip"
        ? 64 * 1024 * 1024
        : profileId === "sevenzip-to-tar-xz"
          ? 104 * 1024 * 1024
          : profileId === "tar-xz-to-sevenzip"
            ? 80 * 1024 * 1024
            : isBzip2Profile
              ? 8 * 1024 * 1024
              : isXzProfile
                ? 48 * 1024 * 1024
                : isSevenZipProfile
                  ? 64 * 1024 * 1024
                  : isIvfProfile || THEORA_OGV_PROFILES.includes(profileId)
                    ? 96 * 1024 * 1024
                    : 32 * 1024 * 1024;
const testUrl = `${serverUrl}/?test=1${
  destinationMode === "direct-handle" ? "&directory=1" : ""
}`;

assertInside(workRoot, profileRoot);
assertInside(path.resolve(projectRoot, "outputs"), reportRoot);
await mkdir(workRoot, { recursive: true });
await mkdir(reportRoot, { recursive: true });

let serverProcess;
let chromeProcess;
let browser;
let page;
let blankStable = null;
let loadedStable = null;
let lastObservedState = null;
let cancellationCheck = null;
let activeRun = 0;
let reportWritten = false;
let terminationSignal = null;
let nativeObserver = null;
let nativeTemporary = null;
let runtimeScratch = null;
let profileOwned = false;
let browserStartedAt = null;
const sourceHashes = {};
const launches = new Map(), directories = new Map(), forbiddenRequests = [];
import { queryProcessIdentity, observeOwnedProcessExit } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/owned-process-exit-observation.mjs";
async function recordLaunch(pid, role) { const identity = await queryProcessIdentity(pid);
  if (!identity || identity.parentPid !== process.pid) throw new Error("Unverified helper birth");
  launches.set(pid, { role, identity, absence: null }); }
async function recordDirectory(target) { const info = await lstat(target, { bigint: true });
  if (!info.isDirectory() || info.isSymbolicLink() || await realpath(target) !== target) throw new Error("Unowned scratch");
  directories.set(target, { dev: info.dev, ino: info.ino }); }
const samples = [];
const runSummaries = [];
const startedAt = Date.now();
const handleTermination = (signal) => {
  if (terminationSignal) return;
  terminationSignal = signal;
  process.stderr.write(
    `Received ${signal}; stopping the project-local profile safely.\n`,
  );
  void (async () => {
    await browser?.close().catch(() => {});
    if (chromeProcess?.pid) await killProcessTree(chromeProcess.pid);
    if (serverProcess?.pid) await killProcessTree(serverProcess.pid);
  })();
};
const onSigint = () => handleTermination("SIGINT");
const onSigterm = () => handleTermination("SIGTERM");
process.on("SIGINT", onSigint);
process.on("SIGTERM", onSigterm);

try {
  // Refuse an existing profile and never delete it if this mkdir fails.
  await mkdir(profileRoot);
  profileOwned = true;
  await recordDirectory(profileRoot);
  runtimeScratch = await createOwnedRuntimeScratch();
  for (const file of ["scripts/memory-profile.mjs", "scripts/lib/native-memory-peaks.mjs",
    "scripts/lib/parallel-memory-observer.mjs", "scripts/lib/native-memory-history.mjs",
    "scripts/lib/persistent-chromium-memory.mjs", "scripts/lib/chromium-private-memory.mjs",
    "scripts/lib/windows-tree-monitor.cs", "scripts/lib/windows-tree-monitor.ps1",
    "scripts/lib/owned-runtime-scratch.mjs"]) {
    sourceHashes[file] = (await hashFile(path.join(projectRoot, file))).sha256;
  }
  serverProcess = spawn(
    process.execPath,
    [
      wranglerEntry,
      "dev",
      "--config",
      "dist/server/wrangler.json",
      "--port",
      String(serverPort),
    ],
    {
      cwd: projectRoot,
      env: { ...runtimeScratch.env, WRANGLER_SEND_METRICS: "false" },
      stdio: "ignore",
      windowsHide: true,
    },
  );
  await recordLaunch(serverProcess.pid, "production-server");
  await waitForServer(serverUrl, 30_000);

  browserStartedAt = Date.now();
  chromeProcess = spawn(
    chromePath,
    [
      "--headless=new",
      "--remote-debugging-port=0",
      `--user-data-dir=${profileRoot}`,
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-background-networking",
      "--disable-component-update",
      "--disable-default-apps",
      "--disable-domain-reliability",
      "--disable-extensions",
      "--disable-features=MediaRouter,OptimizationGuideModelDownloading,OptimizationHints,OptimizationTargetPrediction",
      "--disable-sync",
      "--metrics-recording-only",
      "about:blank",
    ],
    {
      cwd: projectRoot,
      env: runtimeScratch.env,
      stdio: "ignore",
      windowsHide: true,
    },
  );

  await recordLaunch(chromeProcess.pid, "headless-chrome");
  nativeTemporary = await mkdtemp(path.join(workRoot, "memory-observer-"));
  await recordDirectory(nativeTemporary);
  nativeObserver = await startParallelMemoryObserver(chromeProcess.pid, nativeTemporary);
  await recordLaunch(nativeObserver.pid, "read-only-memory-observer");
  const debugPort = await waitForDebugPort(profileRoot, 30_000);
  browser = await chromium.connectOverCDP(`http://127.0.0.1:${debugPort}`);
  const context = browser.contexts()[0];
  await context.route("**/*", route => { const request = route.request();
    if (!request.url().startsWith(serverUrl + "/") || !["GET", "HEAD"].includes(request.method()) || request.postData()) {
      forbiddenRequests.push({ method: request.method(), url: request.url().slice(0, 256) }); return route.abort(); }
    return route.continue(); });
  const pages = context.pages();
  page = pages[0] ?? (await context.newPage());
  const cdp = await context.newCDPSession(page);
  await cdp.send("DOM.enable");
  await page.goto("about:blank");

  blankStable = await waitForStableMemory(
    chromeProcess.pid,
    page,
    "blank-baseline",
    samples,
    null,
    90_000,
  );
  const blankPrivateBytes = blankStable.privateBytes;
  if (blankPrivateBytes == null || blankStable.stable !== true) {
    throw new Error("Blank Chromium private-memory baseline is unavailable or unstable; no last-sample fallback.");
  }

  nativeObserver.setPhase("loaded-navigation");
  await page.goto(testUrl);
  await page
    .getByRole("heading", { name: "Big files. Small memory." })
    .waitFor();
  await page.waitForFunction(
    () => window.__WITHIN_TEST__?.getState().workerStatus === "ready",
  );
  loadedStable = await waitForStableMemory(
    chromeProcess.pid,
    page,
    "loaded-idle",
    samples,
  );
  if (loadedStable.privateBytes == null || loadedStable.stable !== true) {
    throw new Error("Loaded-site private-memory baseline is unavailable or unstable.");
  }

  for (let run = 1; run <= runCount; run += 1) {
    activeRun = run;
    nativeObserver.setPhase(`pre-conversion-${run}`);
    const validationHash = createHash("sha256");
    let validationBytes = 0;
    let outputSha256 = null;
    let externalValidationSha256 = null;
    await page.goto(testUrl);
    await page.waitForFunction(
      () => window.__WITHIN_TEST__?.getState().workerStatus === "ready",
    );
    await setLocalFileInput(cdp, fixturePath);
    const selectedFileBytes = await page
      .locator('[data-testid="file-input"]')
      .evaluate((input) => input.files?.[0]?.size ?? null);
    if (selectedFileBytes !== fixtureManifest.bytes) {
      throw new Error(
        `Chromium selected ${selectedFileBytes ?? "no"} bytes; expected ${fixtureManifest.bytes}.`,
      );
    }
    await page.locator('[data-testid="format-select"]').selectOption(profileId);
    if (isAudioOptionsProfile) {
      await page
        .locator('[data-testid="audio-codec-select"]')
        .selectOption(audioOptions.codec);
      await page
        .locator('[data-testid="audio-compression-select"]')
        .selectOption(audioOptions.compression);
      await page
        .locator('[data-testid="audio-bitrate-select"]')
        .selectOption(String(audioOptions.bitRateBps));
      await page
        .locator('[data-testid="audio-sample-rate-select"]')
        .selectOption(String(audioOptions.sampleRateHz));
      await page
        .locator('[data-testid="audio-channels-select"]')
        .selectOption(String(audioOptions.channels));
      await page
        .locator('[data-testid="audio-quality-select"]')
        .selectOption(audioOptions.quality);
    }
    if (isVideoOptionsProfile) {
      await page
        .locator('[data-testid="video-codec-select"]')
        .selectOption(videoOptions.codec);
      await page
        .locator('[data-testid="video-width-select"]')
        .selectOption(String(videoOptions.maxWidth));
      const videoBitRateSelect = page.locator(
        '[data-testid="video-bitrate-select"]',
      );
      if (await videoBitRateSelect.isEnabled()) {
        await videoBitRateSelect.selectOption(String(videoOptions.bitRateBps));
      } else if (
        videoOptions.bitRateBps !== 0 ||
        (await videoBitRateSelect.inputValue()) !== "0"
      ) {
        throw new Error(
          "This video profile uses quality-based VBR and cannot apply a nonzero bitrate.",
        );
      }
      await page
        .locator('[data-testid="video-frame-rate-select"]')
        .selectOption(String(videoOptions.frameRateFps));
      await page
        .locator('[data-testid="video-quality-select"]')
        .selectOption(videoOptions.quality);
    }
    const beforeConversion = await takeSample(chromeProcess.pid, page, `pre-conversion-${run}`);
    samples.push(beforeConversion);
    nativeObserver.setPhase(`conversion-${run}`);
    await page.locator('[data-testid="convert-button"]').click();
    await page.waitForFunction(
      () => window.__WITHIN_TEST__?.getState().jobState !== "idle",
    );

    let peakPrivateBytes = beforeConversion.privateBytes;
    let peakRssBytes = beforeConversion.rssBytes;
    let finalState;
    for (;;) {
      const state = await page.evaluate(() =>
        window.__WITHIN_TEST__?.getState(),
      );
      lastObservedState = state ?? lastObservedState;
      const sample = await takeSample(
        chromeProcess.pid,
        page,
        `conversion-${run}`,
      );
      samples.push(sample);
      if (sample.privateBytes != null) {
        peakPrivateBytes =
          peakPrivateBytes == null
            ? sample.privateBytes
            : Math.max(peakPrivateBytes, sample.privateBytes);
      }
      if (sample.rssBytes != null) {
        peakRssBytes =
          peakRssBytes == null
            ? sample.rssBytes
            : Math.max(peakRssBytes, sample.rssBytes);
      }
      if (state?.jobState !== "running") {
        finalState = state;
        break;
      }
      await delay(sampleIntervalMs);
    }

    const conversionStoppedAt = nativeObserver.setPhase(`validation-${run}`);
    await nativeObserver.through(conversionStoppedAt);
    const cimPeakPrivateBytes = peakPrivateBytes;
    const cimPeakRssBytes = peakRssBytes;
    const nativePeaks = nativeObserver.peaks([`pre-conversion-${run}`, `conversion-${run}`]);
    if (nativePeaks.peak == null || cimPeakPrivateBytes == null) {
      throw new Error(`Complete native/CIM conversion coverage unavailable on run ${run}; no CIM-only acceptance fallback.`);
    }
    peakPrivateBytes = combinedTreePeak(cimPeakPrivateBytes, nativePeaks.peak.privateBytes, blankPrivateBytes).peakPrivateBytes;
    peakRssBytes = Math.max(cimPeakRssBytes, nativePeaks.peakRssBytes);

    const outputStorageName =
      destinationMode === "direct-handle"
        ? finalState?.batchOutputNames?.[0]
        : finalState?.opfsName;
    if (
      !finalState ||
      finalState.jobState !== "complete" ||
      !outputStorageName
    ) {
      throw new Error(
        `Conversion run ${run} failed: ${finalState?.error ?? finalState?.phase ?? "unknown"}`,
      );
    }
    if (peakPrivateBytes == null) {
      throw new Error(`Private-memory samples are unavailable for run ${run}.`);
    }

    let mediaProbe = null;
    if (
      isMediaProfile ||
      isImageProfile ||
      isArchiveTransformProfile ||
      isDocxOutputProfile ||
      isOdtOutputProfile ||
      isEpubOutputProfile ||
      isBzip2CompressedOutput ||
      isXzCompressedOutput ||
      isGzipCompressedOutput
    ) {
      const physicalOutputPath = await findProjectLocalPayload(
        profileRoot,
        finalState.metrics.outputBytes,
      );
      if (isDocxOutputProfile || isOdtOutputProfile || isEpubOutputProfile) {
        outputSha256 = (await hashFile(physicalOutputPath)).sha256;
        const decoded = isDocxOutputProfile
          ? await validateDocxOutput(physicalOutputPath)
          : isOdtOutputProfile
            ? await validateOdtOutput(physicalOutputPath)
            : await validateEpubOutput(
                physicalOutputPath,
                isMarkdownEpubOutputProfile ? "markdown" : "text",
              );
        validationBytes = decoded.bytes;
        externalValidationSha256 = decoded.sha256;
        if (
          validationBytes !== expectedValidationBytes ||
          externalValidationSha256 !== expectedValidationHash
        ) {
          throw new Error(
            "Independent streamed " +
              (isDocxOutputProfile
                ? "DOCX"
                : isOdtOutputProfile
                  ? "ODT"
                  : "EPUB") +
              " validation failed on run " +
              run +
              ": " +
              validationBytes +
              " bytes.",
          );
        }
        mediaProbe = {
          withinValidation: {
            method: isDocxOutputProfile
              ? "python-zipfile-sax-stream-sha256"
              : isOdtOutputProfile
                ? "python-odf-zipfile-sax-stream-sha256"
                : "python-epub-zipfile-sax-stream-sha256",
            passed: true,
            bytes: validationBytes,
            sha256: externalValidationSha256,
            entries: decoded.entries,
            compressionMethods: decoded.methods,
          },
        };
      } else if (
        isBzip2CompressedOutput ||
        isXzCompressedOutput ||
        isGzipCompressedOutput
      ) {
        outputSha256 = (await hashFile(physicalOutputPath)).sha256;
        const decoded = isXzCompressedOutput
          ? await validateXzOutput(physicalOutputPath)
          : isBzip2CompressedOutput
            ? await validateBzip2Output(physicalOutputPath)
            : await validateGzipOutput(physicalOutputPath);
        validationBytes = decoded.bytes;
        externalValidationSha256 = decoded.sha256;
        if (
          validationBytes !== expectedValidationBytes ||
          externalValidationSha256 !== expectedValidationHash
        ) {
          throw new Error(
            `Independent streamed ${isXzCompressedOutput ? "XZ" : isBzip2CompressedOutput ? "BZIP2" : "GZIP"} validation failed on run ${run}: ${validationBytes} bytes.`,
          );
        }
        mediaProbe = {
          withinValidation: {
            method: isXzCompressedOutput
              ? "python-lzma-stream-sha256"
              : isBzip2CompressedOutput
                ? "python-bz2-stream-sha256"
                : "python-gzip-stream-sha256",
            passed: true,
            bytes: validationBytes,
            sha256: externalValidationSha256,
          },
        };
      } else {
        for await (const chunk of createReadStream(physicalOutputPath, {
          highWaterMark: 1024 * 1024,
        })) {
          validationHash.update(chunk);
          validationBytes += chunk.byteLength;
        }
        mediaProbe = isArchiveTransformProfile
          ? await validateArchiveOutput(
              physicalOutputPath,
              fixtureManifest,
              profileId,
            )
          : isMediaProfile
            ? await validateMediaOutput(
                physicalOutputPath,
                fixturePath,
                fixtureManifest,
                finalState,
                profileId,
              )
            : isAnimatedFrameArchiveProfile
              ? await validateAnimatedFrameArchiveOutput(
                  physicalOutputPath,
                  fixturePath,
                  fixtureManifest,
                  finalState,
                  profileId,
                )
              : isAnimatedApngProfile
                ? await validateAnimatedApngOutput(
                    physicalOutputPath,
                    fixturePath,
                    fixtureManifest,
                    finalState,
                  )
                : isAnimatedGifProfile
                  ? await validateAnimatedGifOutput(
                      physicalOutputPath,
                      fixturePath,
                      fixtureManifest,
                      finalState,
                    )
                  : isAnimatedWebpProfile
                    ? await validateAnimatedWebpOutput(
                        physicalOutputPath,
                        fixturePath,
                        fixtureManifest,
                        finalState,
                      )
                    : isAnimatedJxlProfile
                      ? await validateAnimatedJxlOutput(
                          physicalOutputPath,
                          fixturePath,
                          fixtureManifest,
                          finalState,
                          profileId,
                        )
                      : isTiffPageArchiveProfile
                        ? await validateTiffPageArchiveOutput(
                            physicalOutputPath,
                            fixtureManifest,
                            finalState,
                            profileId,
                          )
                        : await validateImageOutput(
                            physicalOutputPath,
                            fixturePath,
                            fixtureManifest,
                            finalState,
                            profileId,
                          );
      }
    } else {
      const validationPage = await context.newPage();
      await validationPage.exposeBinding(
        "__withinValidationChunk",
        async (_source, base64) => {
          const chunk = Buffer.from(base64, "base64");
          validationHash.update(chunk);
          validationBytes += chunk.byteLength;
        },
      );
      await validationPage.goto(`${serverUrl}/test-validator.html`);
      await validationPage.evaluate(
        async ({ opfsName, profileId }) => {
          const root = await navigator.storage.getDirectory();
          const handle = await root.getFileHandle(opfsName);
          const compressed = await handle.getFile();
          const source =
            profileId === "gzip-compress" || profileId === "tar-to-tar-gz"
              ? compressed.stream().pipeThrough(new DecompressionStream("gzip"))
              : compressed.stream();
          const reader = source.getReader();
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            for (
              let offset = 0;
              offset < value.byteLength;
              offset += 64 * 1024
            ) {
              const part = value.subarray(
                offset,
                Math.min(offset + 64 * 1024, value.byteLength),
              );
              let binary = "";
              for (let inner = 0; inner < part.byteLength; inner += 16 * 1024) {
                binary += String.fromCharCode(
                  ...part.subarray(
                    inner,
                    Math.min(inner + 16 * 1024, part.byteLength),
                  ),
                );
              }
              await window.__withinValidationChunk(btoa(binary));
            }
          }
        },
        { opfsName: outputStorageName, profileId },
      );
      await validationPage.close();
      if (
        validationBytes !== expectedValidationBytes ||
        validationHash.copy().digest("hex") !== expectedValidationHash
      ) {
        throw new Error(
          `Independent streamed validation failed on run ${run}: ${validationBytes} bytes.`,
        );
      }
    }
    const validationSha256 =
      externalValidationSha256 ?? validationHash.digest("hex");
    const actualHash = outputSha256 ?? validationSha256;

    const cleanupPage = await context.newPage();
    await cleanupPage.goto(`${serverUrl}/test-validator.html`);
    await cleanupPage.evaluate(async (opfsName) => {
      const root = await navigator.storage.getDirectory();
      await root.removeEntry(opfsName);
    }, outputStorageName);
    await cleanupPage.close();

    await delay(3_000);
    const cleanupStable = await waitForStableMemory(
      chromeProcess.pid,
      page,
      `cleanup-${run}`,
      samples,
      loadedStable.privateBytes + cleanupRecoveryLimitMiB * 1024 * 1024,
      60_000,
    );
    if (cleanupStable.privateBytes == null || cleanupStable.stable !== true) {
      throw new Error(`Cleanup memory is unavailable or did not recover stably for run ${run}.`);
    }

    runSummaries.push({
      run,
      sourceBytes: fixtureManifest.bytes,
      outputBytes: finalState.metrics.outputBytes,
      elapsedMs: finalState.metrics.elapsedMs,
      maxReadChunkBytes: finalState.metrics.maxReadChunkBytes,
      maxWriteChunkBytes: finalState.metrics.maxWriteChunkBytes,
      peakQueuedBytes: finalState.metrics.peakQueuedBytes,
      peakPendingOperations: finalState.metrics.peakPendingOperations,
      wasmMemoryBytes: finalState.metrics.wasmMemoryBytes ?? null,
      peakWasmMemoryBytes: finalState.metrics.peakWasmMemoryBytes ?? null,
      wasmMemories: finalState.metrics.wasmMemories ?? null,
      codecWorkingBytes: finalState.metrics.codecWorkingBytes ?? null,
      peakCodecWorkingBytes: finalState.metrics.peakCodecWorkingBytes ?? null,
      sharedArrayBufferBytes: finalState.metrics.sharedArrayBufferBytes ?? null,
      activeWorkerCount: finalState.metrics.activeWorkerCount ?? null,
      imageFrameFormat: finalState.metrics.imageFrameFormat ?? null,
      imageColorSpace: finalState.metrics.imageColorSpace ?? null,
      imageWorkingBytes: finalState.metrics.imageWorkingBytes ?? null,
      peakImageWorkingBytes: finalState.metrics.peakImageWorkingBytes ?? null,
      maxImagePixelStripBytes:
        finalState.metrics.maxImagePixelStripBytes ?? null,
      archiveCompression: finalState.metrics.archiveCompression ?? null,
      scratchBytes: finalState.metrics.scratchBytes ?? null,
      peakScratchBytes: finalState.metrics.peakScratchBytes ?? null,
      maxScratchReadChunkBytes:
        finalState.metrics.maxScratchReadChunkBytes ?? null,
      maxScratchWriteChunkBytes:
        finalState.metrics.maxScratchWriteChunkBytes ?? null,
      peakPrivateBytes,
      peakRssBytes,
      cimPeakPrivateBytes,
      cimPeakRssBytes,
      nativePeaks,
      incrementalPrivateMiB:
        (peakPrivateBytes - blankPrivateBytes) / (1024 * 1024),
      conversionOnlyPrivateMiB:
        (peakPrivateBytes - loadedStable.privateBytes) / (1024 * 1024),
      cleanupPrivateBytes: cleanupStable.privateBytes,
      cleanupDeltaFromLoadedMiB:
        (cleanupStable.privateBytes - loadedStable.privateBytes) /
        (1024 * 1024),
      sha256: actualHash,
      validationBytes,
      validationSha256,
      mediaProbe,
    });
  }

  const cancellationProfileFamily = isIvfProfile
    ? "IVF"
    : profileId === "mkv-to-mp4"
      ? "MKV-to-MP4"
    : profileId === "m4a-to-aiff"
      ? "AIFF"
    : THEORA_OGV_PROFILES.includes(profileId)
      ? "Theora OGV"
      : COMPATIBLE_AVI_PROFILES.includes(profileId) ||
          profileId === "avi-to-3gp" ||
          profileId === "avi-to-mov" ||
          profileId === "avi-to-mpeg-ts" ||
          profileId === "avi-to-flv"
        ? "AVI"
        : "OGV";
  if (
    profileId === "mkv-to-mp4" ||
    profileId === "mkv-to-ogv" ||
    profileId === "m4a-to-aiff" ||
    profileId === "avi-to-3gp" ||
    profileId === "avi-to-mov" ||
    profileId === "avi-to-mpeg-ts" ||
    profileId === "avi-to-flv" ||
    THEORA_OGV_PROFILES.includes(profileId) ||
    COMPATIBLE_AVI_PROFILES.includes(profileId) ||
    isIvfProfile
  ) {
    nativeObserver.setPhase("cancellation");
    const namesBefore = await page.evaluate(async () => {
      const root = await navigator.storage.getDirectory();
      const names = [];
      for await (const [name] of root.entries()) names.push(name);
      return names.sort();
    });
    await setLocalFileInput(cdp, fixturePath);
    await page.locator('[data-testid="format-select"]').selectOption(profileId);
    await page.locator('[data-testid="convert-button"]').click();
    await page.waitForFunction(({ activeProfileId, activeDestinationMode }) => {
      const state = window.__WITHIN_TEST__?.getState();
      return (
        (state?.jobState === "running" &&
          ((activeProfileId === "mkv-to-avi" ||
            activeProfileId === "3gp-to-avi" ||
            activeProfileId === "mov-to-avi" ||
            activeProfileId === "mpeg-ts-to-avi" ||
            activeProfileId === "avi-to-3gp" ||
            activeProfileId === "avi-to-mpeg-ts") &&
          activeDestinationMode === "sync-opfs"
            ? (activeProfileId !== "mkv-to-avi" &&
                activeProfileId !== "3gp-to-avi" &&
                activeProfileId !== "mov-to-avi" &&
                activeProfileId !== "mpeg-ts-to-avi") ||
              (state.metrics?.outputBytes ?? 0) >= 1024 * 1024
          : activeProfileId === "mp4-to-avi" ||
          activeProfileId === "mov-to-avi" ||
          activeProfileId === "3gp-to-avi" ||
          activeProfileId === "mkv-to-avi" ||
          activeProfileId === "mpeg-ts-to-avi" ||
          activeProfileId === "mkv-to-mp4" ||
          activeProfileId === "avi-to-3gp" ||
          activeProfileId === "avi-to-mpeg-ts" ||
          (activeProfileId === "m2v-to-ogv" &&
            activeDestinationMode === "direct-handle")
            ? state.phase ===
                (activeProfileId === "mp4-to-avi" ||
                activeProfileId === "mov-to-avi" ||
                activeProfileId === "3gp-to-avi" ||
                activeProfileId === "mkv-to-avi" ||
                activeProfileId === "mpeg-ts-to-avi"
                  ? "Copying staged AVI to selected destination"
                  : activeProfileId === "avi-to-3gp"
                    ? "Copying staged 3GP to selected destination"
                    : activeProfileId === "avi-to-mpeg-ts"
                      ? "Copying staged MPEG-TS to selected destination"
                    : activeProfileId === "m2v-to-ogv"
                      ? "Copying staged OGV to selected destination"
                    : "Copying staged MP4 to selected destination") &&
              (state.metrics?.outputBytes ?? 0) >= 1024 * 1024
            : activeProfileId === "m4a-to-aiff"
              ? (state.metrics?.outputBytes ?? 0) >= 1024 * 1024
            : activeProfileId === "avi-to-mov" ||
              (state.metrics?.inputBytes ?? 0) >= 256 * 1024)) ||
        state?.jobState === "complete" ||
        state?.jobState === "error"
      );
    }, { activeProfileId: profileId, activeDestinationMode: destinationMode }, {
      timeout: profileId === "m2v-to-ogv" && destinationMode === "direct-handle"
        ? 300_000
        : 120_000,
    });
    const cancellableState = await page.evaluate(() =>
      window.__WITHIN_TEST__?.getState(),
    );
    if (cancellableState?.jobState !== "running") {
      throw new Error(
        `${cancellationProfileFamily} stress conversion reached ${cancellableState?.jobState ?? "an unknown state"} before its cancellation checkpoint.`,
      );
    }
    await page.getByRole("button", { name: "Cancel safely" }).click();
    await page.waitForFunction(
      () => window.__WITHIN_TEST__?.getState().jobState === "cancelled",
    );
    const cancelledState = await page.evaluate(() =>
      window.__WITHIN_TEST__?.getState(),
    );
    lastObservedState = cancelledState ?? lastObservedState;
    await page.waitForFunction(
      () => window.__WITHIN_TEST__?.getState().workerStatus === "ready",
    );
    const namesAfter = await page.evaluate(async () => {
      const root = await navigator.storage.getDirectory();
      const names = [];
      for await (const [name] of root.entries()) names.push(name);
      return names.sort();
    });
    cancellationCheck = {
      passed:
        cancelledState?.opfsName == null &&
        cancelledState?.metrics?.pendingOperations === 0 &&
        cancelledState?.metrics?.queuedBytes === 0 &&
        cancelledState?.metrics?.peakPendingOperations <= 1 &&
        cancelledState?.metrics?.maxReadChunkBytes <= 256 * 1024 &&
        cancelledState?.metrics?.maxWriteChunkBytes <= maximumWriteChunkBytes &&
        JSON.stringify(namesAfter) === JSON.stringify(namesBefore),
      inputBytes: cancelledState?.metrics?.inputBytes ?? null,
      outputBytes: cancelledState?.metrics?.outputBytes ?? null,
      phaseAtTrigger: cancellableState?.phase ?? null,
      phaseAfterCancellation: cancelledState?.phase ?? null,
      maxReadChunkBytes: cancelledState?.metrics?.maxReadChunkBytes ?? null,
      maxWriteChunkBytes: cancelledState?.metrics?.maxWriteChunkBytes ?? null,
      peakPendingOperations:
        cancelledState?.metrics?.peakPendingOperations ?? null,
      pendingOperations: cancelledState?.metrics?.pendingOperations ?? null,
      queuedBytes: cancelledState?.metrics?.queuedBytes ?? null,
      projectLocalEntriesBefore: namesBefore,
      projectLocalEntriesAfter: namesAfter,
    };
    if (!cancellationCheck.passed) {
      throw new Error(
        `${cancellationProfileFamily} cancellation left output state or browser-owned files behind.`,
      );
    }
  }

  await nativeObserver.stop();
  const peakPrivateBytes = Math.max(
    ...runSummaries.map((run) => run.peakPrivateBytes),
  );
  const checks = {
    networkPrivacy: forbiddenRequests.length === 0,
    aiffCancellation: cancellationCheck?.passed === true,
    processTreePrivateMemory:
      (peakPrivateBytes - blankPrivateBytes) / (1024 * 1024) <= 250,
    repeatableOutputHash: runSummaries.every(
      (run) => run.sha256 === runSummaries[0]?.sha256,
    ),
    pendingOperations: runSummaries.every(
      (run) => run.peakPendingOperations <= 1,
    ),
    queuedBytes: runSummaries.every(
      (run) => run.peakQueuedBytes <= maximumWriteChunkBytes,
    ),
    readChunkBytes: runSummaries.every(
      (run) => run.maxReadChunkBytes <= 256 * 1024,
    ),
    writeChunkBytes: runSummaries.every(
      (run) => run.maxWriteChunkBytes <= maximumWriteChunkBytes,
    ),
    scratchChunkBytes: runSummaries.every(
      (run) =>
        !isSevenZipOutputProfile ||
        (run.maxScratchReadChunkBytes <= 64 * 1024 &&
          run.maxScratchWriteChunkBytes <= 64 * 1024),
    ),
    scratchCleanup: runSummaries.every(
      (run) => !isSevenZipOutputProfile || run.scratchBytes === 0,
    ),
    boundedImageWorkingSet: runSummaries.every(
      (run) =>
        (!isAnimatedApngProfile && !isAnimatedGifProfile) ||
        (run.imageWorkingBytes === 0 &&
          run.maxImagePixelStripBytes <= 256 * 1024 &&
          run.peakImageWorkingBytes <= 5 * 1024 * 1024),
    ),
    adaptiveArchiveCompression: runSummaries.every(
      (run) =>
        !isSevenZipOutputProfile ||
        run.archiveCompression === "copy" ||
        run.archiveCompression === "lzma2",
    ),
    imageOutputBytes: runSummaries.every(
      (run) =>
        !isImageProfile ||
        isAnimatedFrameArchiveProfile ||
        isTiffPageArchiveProfile ||
        run.outputBytes <= 64 * 1024 * 1024,
    ),
    wasmMemoryBytes: runSummaries.every(
      (run) =>
        (!isMediaProfile &&
          !isBzip2Profile &&
          !isXzProfile &&
          !isSevenZipProfile) ||
        (typeof run.peakWasmMemoryBytes === "number" &&
          run.peakWasmMemoryBytes <= maximumWasmMemoryBytes),
    ),
    cleanupRecovery: runSummaries.every(
      (run) => run.cleanupDeltaFromLoadedMiB <= cleanupRecoveryLimitMiB,
    ),
    cancellationCleanup:
      (profileId !== "mkv-to-ogv" &&
        profileId !== "avi-to-3gp" &&
        profileId !== "avi-to-mov" &&
        profileId !== "avi-to-mpeg-ts" &&
        profileId !== "avi-to-flv" &&
        !THEORA_OGV_PROFILES.includes(profileId) &&
        !COMPATIBLE_AVI_PROFILES.includes(profileId) &&
        !isIvfProfile) ||
      cancellationCheck?.passed === true,
  };
  const report = {
    generatedAt: new Date().toISOString(),
    browser: {
      executable: chromePath,
      version: await browser.version(),
      rootPid: chromeProcess.pid,
      headless: true,
      startedAt: new Date(browserStartedAt).toISOString(),
    },
    sourceHashes,
    runtimeScratch: { directory: runtimeScratch.directory, cleanup: "finally; independently verify after terminal process" },
    nativeMemory: nativeObserver.report(),
    source: fixtureManifest,
    profileId,
    audioOptions,
    videoOptions,
    destinationMode,
    formula:
      "peak complete Chromium process-tree private memory during conversion - stable clean blank-Chromium process-tree private memory",
    blankBaseline: blankStable,
    loadedIdle: loadedStable,
    peakPrivateBytes,
    incrementalPrivateMiB:
      (peakPrivateBytes - blankPrivateBytes) / (1024 * 1024),
    limitMiB: 250,
    cleanupRecoveryLimitMiB,
    cancellationCheck,
    checks,
    passed: Object.values(checks).every(Boolean),
    runs: runSummaries,
    samples,
  };
  await writeReports(report);
  reportWritten = true;
  if (!report.passed) {
    const failedChecks = Object.entries(checks)
      .filter(([, passed]) => !passed)
      .map(([name]) => name)
      .join(", ");
    throw new Error(
      `Memory profile failed (${failedChecks}): peak ${report.incrementalPrivateMiB.toFixed(1)} MiB; cleanup deltas ${runSummaries.map((run) => run.cleanupDeltaFromLoadedMiB.toFixed(1)).join(", ")} MiB`,
    );
  }
  process.stdout.write(
    `PASS ${report.incrementalPrivateMiB.toFixed(1)} MiB incremental private memory\n`,
  );
} catch (error) {
  if (!reportWritten) {
    if (chromeProcess?.pid && page) {
      try {
        samples.push(
          await takeSample(
            chromeProcess.pid,
            page,
            `failure-${activeRun || 1}`,
          ),
        );
      } catch {
        // The browser may already be unavailable; prior samples remain useful.
      }
    }
    await nativeObserver?.stop().catch(() => {});
    try {
      await writeFailureReports({
        generatedAt: new Date().toISOString(),
        profileId,
        audioOptions,
        videoOptions,
        destinationMode,
        source: fixtureManifest,
        sourceHashes,
        runtimeScratch: runtimeScratch ? { directory: runtimeScratch.directory, cleanup: "finally; independently verify after terminal process" } : null,
        nativeMemory: nativeObserver?.report() ?? null,
        formula:
          "peak complete Chromium process-tree private memory during conversion - stable clean blank-Chromium process-tree private memory",
        blankBaseline: blankStable,
        loadedIdle: loadedStable,
        activeRun,
        terminationSignal,
        completedRuns: runSummaries,
        cancellationCheck,
        lastObservedState,
        samples,
        failure: {
          name: error instanceof Error ? error.name : "Error",
          message: error instanceof Error ? error.message : String(error),
          stack: error instanceof Error ? (error.stack ?? null) : null,
        },
      });
    } catch (reportError) {
      process.stderr.write(
        `Failure diagnostics could not be written: ${
          reportError instanceof Error
            ? reportError.message
            : String(reportError)
        }\n`,
      );
    }
  }
  throw error;
} finally {
  process.off("SIGINT", onSigint);
  process.off("SIGTERM", onSigterm);
  await nativeObserver?.stop().catch(() => {});
  await browser?.close().catch(() => {});
  if (chromeProcess?.pid) await killProcessTree(chromeProcess.pid);
  if (serverProcess?.pid) await killProcessTree(serverProcess.pid);
  await finishOwnedCleanup([
    async () => { if (profileOwned) await removeWithRetries(profileRoot); },
    async () => {
      if (nativeTemporary) { assertInside(workRoot, nativeTemporary); await removeWithRetries(nativeTemporary); }
    },
    async () => { await runtimeScratch?.close(); },
  ]);
  for (const row of launches.values()) { row.absence = await observeOwnedProcessExit(row.identity);
    if (row.absence.status !== "owned-identity-absent") throw new Error("Helper cleanup unavailable"); }
  await writeFile("H:\\Github Repositories\\fileconverter\\work\\aiff-id3-stress-KxVK4X\\helper-identities.json", JSON.stringify({ launches: [...launches.values()], forbiddenRequests, profileRemoved: true, observerScratchRemoved: true, runtime: runtimeScratch?.directory ?? null }), { flag: "wx" });
}

async function validateMediaOutput(
  localPath,
  sourcePath,
  source,
  finalState,
  route,
) {
  const mp3Output =
    MP3_OUTPUT_PROFILES.includes(route) ||
    route === "mkv-to-mp3" ||
    route === "mp4-to-mp3" ||
    route === "mov-to-mp3" ||
    route === "avi-to-mp3" ||
    route === "mpeg-ts-to-mp3" ||
    route === "flv-to-mp3";
  const aacPacketCopyOutput =
    route === "mkv-to-aac" ||
    route === "mp4-to-aac" ||
    route === "mov-to-aac" ||
    route === "3gp-to-aac" ||
    route === "mpeg-ts-to-aac" ||
    route === "flv-to-aac";
  const m4aTranscodeOutput = M4A_TRANSCODE_OUTPUT_PROFILES.includes(route);
  const aacTranscodeOutput =
    AAC_OUTPUT_PROFILES.includes(route) || m4aTranscodeOutput;
  const aacOutput = aacPacketCopyOutput || aacTranscodeOutput;
  const oggPacketOutput =
    route === "mkv-to-ogg" ||
    route === "webm-to-ogg" ||
    route === "ogv-to-ogg" ||
    route === "mkv-to-opus" ||
    route === "webm-to-opus";
  const opusOutput = route.endsWith("-to-opus");
  const opusTranscodeOutput = OPUS_OUTPUT_PROFILES.includes(route);
  const vorbisTranscodeOutput = VORBIS_OUTPUT_PROFILES.includes(route);
  const aiffOutput = AIFF_OUTPUT_PROFILES.includes(route);
  const amrOutput = AMR_OUTPUT_PROFILES.includes(route);
  const mp3TranscodeOutput = MP3_OUTPUT_PROFILES.includes(route);
  const audioOnly =
    aiffOutput ||
    amrOutput ||
    mp3Output ||
    aacOutput ||
    opusTranscodeOutput ||
    vorbisTranscodeOutput ||
    oggPacketOutput ||
    route === "mkv-to-m4a" ||
    route === "mov-to-m4a" ||
    route === "3gp-to-m4a" ||
    route === "mpeg-ts-to-m4a" ||
    route === "flv-to-m4a" ||
    route === "mp4-to-m4a" ||
    route === "aac-to-m4a" ||
    m4aTranscodeOutput ||
    route === "mkv-to-wav" ||
    route === "mov-to-wav" ||
    route === "3gp-to-wav" ||
    route === "mpeg-ts-to-wav" ||
    route === "flv-to-wav" ||
    route === "avi-to-wav" ||
    route === "ogv-to-wav" ||
    route === "mp4-to-wav" ||
    route === "m4a-to-wav" ||
    route === "aac-to-wav" ||
    route === "amr-to-wav" ||
    route === "amr-wb-to-wav" ||
    route === "mp3-to-wav" ||
    route === "flac-to-wav" ||
    route === "wma-to-wav" ||
    route === "aiff-to-wav" ||
    route === "ogg-to-wav" ||
    route === "opus-to-wav" ||
    route === "webm-to-wav" ||
    route === "m4a-to-flac" ||
    route === "mkv-to-flac" ||
    route === "mp4-to-flac" ||
    route === "mov-to-flac" ||
    route === "3gp-to-flac" ||
    route === "mpeg-ts-to-flac" ||
    route === "flv-to-flac" ||
    route === "avi-to-flac" ||
    route === "ogv-to-flac" ||
    route === "aac-to-flac" ||
    route === "amr-to-flac" ||
    route === "amr-wb-to-flac" ||
    route === "mp3-to-flac" ||
    route === "wav-to-flac" ||
    route === "wma-to-flac" ||
    route === "aiff-to-flac" ||
    route === "ogg-to-flac" ||
    route === "opus-to-flac" ||
    route === "webm-to-flac" ||
    route === "wav-to-alac" ||
    route === "flac-to-alac" ||
    WMA_OUTPUT_PROFILES.includes(route);
  const pcmOutput =
    aiffOutput ||
    route === "mkv-to-wav" ||
    route === "mov-to-wav" ||
    route === "3gp-to-wav" ||
    route === "mpeg-ts-to-wav" ||
    route === "flv-to-wav" ||
    route === "avi-to-wav" ||
    route === "ogv-to-wav" ||
    route === "mp4-to-wav" ||
    route === "m4a-to-wav" ||
    route === "aac-to-wav" ||
    route === "amr-to-wav" ||
    route === "amr-wb-to-wav" ||
    route === "mp3-to-wav" ||
    route === "flac-to-wav" ||
    route === "wma-to-wav" ||
    route === "aiff-to-wav" ||
    route === "ogg-to-wav" ||
    route === "opus-to-wav" ||
    route === "webm-to-wav";
  const flacOutput =
    route === "m4a-to-flac" ||
    route === "mkv-to-flac" ||
    route === "mp4-to-flac" ||
    route === "mov-to-flac" ||
    route === "3gp-to-flac" ||
    route === "mpeg-ts-to-flac" ||
    route === "flv-to-flac" ||
    route === "avi-to-flac" ||
    route === "ogv-to-flac" ||
    route === "aac-to-flac" ||
    route === "amr-to-flac" ||
    route === "amr-wb-to-flac" ||
    route === "mp3-to-flac" ||
    route === "wav-to-flac" ||
    route === "wma-to-flac" ||
    route === "aiff-to-flac" ||
    route === "ogg-to-flac" ||
    route === "opus-to-flac" ||
    route === "webm-to-flac";
  const alacOutput = route === "wav-to-alac" || route === "flac-to-alac";
  const wmaOutput = WMA_OUTPUT_PROFILES.includes(route);
  const h264Output =
    route === "mkv-to-h264" ||
    route === "mp4-to-h264" ||
    route === "mov-to-h264" ||
    route === "3gp-to-h264" ||
    route === "mpeg-ts-to-h264" ||
    route === "flv-to-h264";
  const hevcOutput =
    route === "mkv-to-hevc" ||
    route === "mp4-to-hevc" ||
    route === "mov-to-hevc" ||
    route === "mpeg-ts-to-hevc";
  const mpeg2Output =
    route === "mkv-to-m2v" ||
    route === "mp4-to-m2v" ||
    route === "mov-to-m2v" ||
    route === "avi-to-m2v" ||
    route === "mpeg-ts-to-m2v";
  const m4vOutput =
    route === "mkv-to-m4v" ||
    route === "mp4-to-m4v" ||
    route === "mov-to-m4v" ||
    route === "avi-to-m4v";
  const m4vMp4Output = route === "m4v-to-mp4";
  const compatibleOgvCopy = route === "mkv-to-ogv";
  const theoraOgvReencode = THEORA_OGV_PROFILES.includes(route);
  const compatibleAviCopy = COMPATIBLE_AVI_PROFILES.includes(route);
  const ivfOutput = IVF_PROFILES.includes(route);
  const ivfInputCopy = IVF_INPUT_PROFILES.includes(route);
  const compatibleWebmCopy = COMPATIBLE_WEBM_PROFILES.includes(route);
  const mkvMp4Copy = route === "mkv-to-mp4";
  const matroskaCopy = [
    "mp4-to-mkv",
    "mov-to-mkv",
    "3gp-to-mkv",
    "mpeg-ts-to-mkv",
    "flv-to-mkv",
    "avi-to-mkv",
    "webm-to-mkv",
    "ogv-to-mkv",
    "ivf-to-mkv",
  ].includes(route);
  const liveMatroskaCopy = matroskaCopy && route !== "avi-to-mkv";
  const containerMpegTsCopy = [
    "mkv-to-mpeg-ts",
    "mp4-to-mpeg-ts",
    "mov-to-mpeg-ts",
    "3gp-to-mpeg-ts",
    "flv-to-mpeg-ts",
    "avi-to-mpeg-ts",
  ].includes(route);
  const aviMpegTsCopy = route === "avi-to-mpeg-ts";
  const containerThreeGpCopy = [
    "mkv-to-3gp",
    "mp4-to-3gp",
    "mov-to-3gp",
    "mpeg-ts-to-3gp",
    "flv-to-3gp",
    "avi-to-3gp",
  ].includes(route);
  const aviVideoOnlyIsoCopy =
    route === "avi-to-3gp" || route === "avi-to-mov";
  const containerMovCopy = [
    "mkv-to-mov",
    "mp4-to-mov",
    "3gp-to-mov",
    "mpeg-ts-to-mov",
    "flv-to-mov",
    "avi-to-mov",
  ].includes(route);
  const containerFlvCopy = [
    "mkv-to-flv",
    "mp4-to-flv",
    "mov-to-flv",
    "3gp-to-flv",
    "mpeg-ts-to-flv",
    "avi-to-flv",
  ].includes(route);
  const elementaryVideoOutput =
    h264Output || hevcOutput || mpeg2Output || m4vOutput || ivfOutput;
  const mpeg2TransportOutput = route === "m2v-to-mpeg-ts";
  const videoOnlyCopy =
    route === "h264-to-mp4" ||
    m4vMp4Output ||
    elementaryVideoOutput ||
    mpeg2TransportOutput ||
    ivfInputCopy;
  const vp9Reencode =
    route === "mkv-to-webm-vp9" ||
    route === "mp4-to-webm-vp9" ||
    route === "mov-to-webm-vp9" ||
    route === "3gp-to-webm-vp9" ||
    route === "mpeg-ts-to-webm-vp9" ||
    route === "flv-to-webm-vp9" ||
    route === "avi-to-webm-vp9" ||
    route === "ogv-to-webm-vp9" ||
    route === "m2v-to-webm-vp9" ||
    route === "h264-to-webm-vp9" ||
    route === "hevc-to-webm-vp9";
  const webmReencode =
    route === "mkv-to-webm" ||
    route === "mp4-to-webm" ||
    route === "mov-to-webm" ||
    route === "3gp-to-webm" ||
    route === "mpeg-ts-to-webm" ||
    route === "flv-to-webm" ||
    route === "avi-to-webm" ||
    route === "ogv-to-webm" ||
    route === "m2v-to-webm" ||
    route === "h264-to-webm" ||
    route === "hevc-to-webm" ||
    vp9Reencode;
  const webmAudioCopy = route === "ogv-to-webm" || route === "ogv-to-webm-vp9";
  const videoReencode =
    route === "mkv-to-mp4-mpeg4" ||
    route === "m2v-to-mp4-mpeg4" ||
    theoraOgvReencode ||
    webmReencode;
  const probedSourceDurationSeconds = Number(source.probe?.format?.duration);
  const decodedVideoDurationSeconds = Number(
    source.decodedVideoDurationSeconds,
  );
  const expectedProfileDurationSeconds = Number(
    expectedProfileValidation?.durationSeconds,
  );
  const sourceDurationSeconds =
    Number.isFinite(expectedProfileDurationSeconds)
      ? expectedProfileDurationSeconds
      : (videoReencode || m4vMp4Output || matroskaCopy || ivfInputCopy) &&
          Number.isFinite(decodedVideoDurationSeconds)
        ? decodedVideoDurationSeconds
        : Number.isFinite(probedSourceDurationSeconds)
          ? probedSourceDurationSeconds
          : Number(source.durationSeconds);
  const minimumComparableSize =
    ivfOutput && Number.isFinite(Number(source.videoPacketBytes))
      ? Math.floor(Number(source.videoPacketBytes))
      : webmReencode && Number.isFinite(sourceDurationSeconds)
        ? Math.floor((sourceDurationSeconds * 300_000) / 8)
        : audioOnly || videoReencode
          ? 1
          : Math.floor(source.bytes * 0.85);
  const sourceAudioForSize = source.probe.streams.find(
    (stream) => stream.codec_type === "audio",
  );
  const selectedAudioChannels =
    audioOptions.channels || Math.min(Number(sourceAudioForSize?.channels), 2);
  const compressedAudioOutputBitRate =
    audioOptions.bitRateBps ||
    (audioOptions.quality === "smaller"
      ? selectedAudioChannels === 1
        ? 64_000
        : 96_000
      : audioOptions.quality === "higher"
        ? selectedAudioChannels === 1
          ? 192_000
          : 256_000
        : selectedAudioChannels === 1
          ? 128_000
          : 192_000);
  const mp3SourceSampleRate = Number(sourceAudioForSize?.sample_rate);
  const mp3OutputSampleRate =
    audioOptions.sampleRateHz ||
    (mp3SourceSampleRate === 8_000 || mp3SourceSampleRate === 16_000
      ? mp3SourceSampleRate
      : mp3SourceSampleRate <= 32_000
        ? 32_000
        : mp3SourceSampleRate <= 44_100
          ? 44_100
          : 48_000);
  const mp3OutputChannels = selectedAudioChannels;
  const mp3OutputBitRate =
    audioOptions.bitRateBps ||
    (audioOptions.quality === "smaller"
      ? mp3OutputChannels === 1
        ? 64_000
        : 96_000
      : audioOptions.quality === "balanced"
        ? mp3OutputChannels === 1
          ? 128_000
          : 192_000
        : audioOptions.quality === "higher"
          ? mp3OutputChannels === 1
            ? 256_000
            : 320_000
          : mp3OutputChannels === 1
            ? mp3OutputSampleRate === 8_000
              ? 32_000
              : mp3OutputSampleRate === 16_000
                ? 64_000
                : 128_000
            : 192_000);
  const opusOutputBitRate =
    audioOptions.bitRateBps ||
    (audioOptions.quality === "smaller"
      ? selectedAudioChannels === 1
        ? 48_000
        : 64_000
      : audioOptions.quality === "higher"
        ? selectedAudioChannels === 1
          ? 128_000
          : 192_000
        : selectedAudioChannels === 1
          ? 64_000
          : 128_000);
  const vorbisOutputBitRate = 220_000;
  const maximumComparableSize =
    ivfOutput &&
    Number.isFinite(Number(source.videoPacketBytes)) &&
    Number.isFinite(Number(source.decodedVideoFrames))
      ? Math.ceil(
          Number(source.videoPacketBytes) +
            Number(source.decodedVideoFrames) * 16 +
            1024 * 1024,
        )
      : webmReencode && Number.isFinite(sourceDurationSeconds)
        ? Math.ceil((sourceDurationSeconds * 1_200_000) / 8) + 1024 * 1024
        : mp3TranscodeOutput && Number.isFinite(sourceDurationSeconds)
          ? Math.ceil((sourceDurationSeconds * mp3OutputBitRate * 1.04) / 8) +
            1024 * 1024
          : aacTranscodeOutput && Number.isFinite(sourceDurationSeconds)
            ? Math.ceil(
                (sourceDurationSeconds * compressedAudioOutputBitRate * 1.04) /
                  8,
              ) +
              1024 * 1024
            : opusTranscodeOutput && Number.isFinite(sourceDurationSeconds)
              ? Math.ceil(
                  (sourceDurationSeconds * opusOutputBitRate * 1.25) / 8,
                ) +
                1024 * 1024
              : vorbisTranscodeOutput && Number.isFinite(sourceDurationSeconds)
                ? Math.ceil((sourceDurationSeconds * vorbisOutputBitRate) / 8) +
                  1024 * 1024
                : wmaOutput && Number.isFinite(sourceDurationSeconds)
                  ? Math.ceil((sourceDurationSeconds * 640_000 * 1.04) / 8) +
                    1024 * 1024
                  : mpeg2TransportOutput || containerMpegTsCopy
                    ? Math.ceil(source.bytes * 1.1)
                    : compatibleAviCopy
                      ? Math.ceil(source.bytes * 1.15)
                      : pcmOutput
                        ? Number.MAX_SAFE_INTEGER
                        : flacOutput || alacOutput
                          ? source.bytes * 10
                          : audioOnly
                            ? source.bytes
                            : videoReencode
                              ? source.bytes * 3
                              : Math.ceil(source.bytes * 1.05);
  if (
    finalState.metrics.outputBytes < minimumComparableSize ||
    finalState.metrics.outputBytes > maximumComparableSize
  ) {
    throw new Error(
      `Browser media output size is outside the validated range: ${finalState.metrics.outputBytes} bytes.`,
    );
  }
  let independentAudioValidation = null;
  if (
    (pcmOutput || flacOutput || alacOutput) &&
    source.losslessPcmReference &&
    source.decodedPcmSha256
  ) {
    const { stdout: decodedPcmHash } = await execFileAsync(
      "ffmpeg",
      [
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        localPath,
        "-map",
        "0:a:0",
        "-c:a",
        "pcm_s16le",
        "-f",
        "hash",
        "-hash",
        "sha256",
        "-",
      ],
      {
        cwd: projectRoot,
        windowsHide: true,
        maxBuffer: 8 * 1024 * 1024,
      },
    );
    if (decodedPcmHash.trim().split("=")[1] !== source.decodedPcmSha256) {
      throw new Error(
        "Browser decoded audio content does not match the independently decoded source audio.",
      );
    }
    independentAudioValidation = {
      method: "decoded-pcm-sha256",
      passed: true,
      sha256: source.decodedPcmSha256,
    };
  } else if (
    pcmOutput ||
    flacOutput ||
    alacOutput ||
    wmaOutput ||
    amrOutput ||
    mp3TranscodeOutput ||
    aacTranscodeOutput ||
    opusTranscodeOutput ||
    vorbisTranscodeOutput
  ) {
    const asdrOutput =
      amrOutput ||
      mp3TranscodeOutput ||
      aacTranscodeOutput ||
      opusTranscodeOutput ||
      vorbisTranscodeOutput ||
      wmaOutput;
    const minimumQualityDb = amrOutput
      ? -3
      : mp3TranscodeOutput
        ? -5
        : aacTranscodeOutput
          ? -6.5
          : opusTranscodeOutput
            ? -6.5
            : vorbisTranscodeOutput || wmaOutput
              ? -6.5
              : (source.minimumDecodedAudioPsnrDb ?? 60);
    const comparisonFilter = amrOutput
      ? "[0:a:0]aresample=8000:async=1:first_pts=0,aformat=sample_fmts=fltp:sample_rates=8000:channel_layouts=mono[source];[1:a:0]aresample=8000:async=1:first_pts=0,aformat=sample_fmts=fltp:sample_rates=8000:channel_layouts=mono[converted];[source][converted]apsnr[quality]"
      : "[0:a:0]aresample=async=1:first_pts=0,aformat=sample_fmts=fltp[source];[1:a:0]aresample=async=1:first_pts=0,aformat=sample_fmts=fltp[converted];[source][converted]apsnr[quality]";
    const { stderr: qualityLog } = await execFileAsync(
      "ffmpeg",
      [
        "-hide_banner",
        "-nostdin",
        "-i",
        sourcePath,
        "-i",
        localPath,
        "-filter_complex",
        asdrOutput
          ? comparisonFilter.replace("apsnr[quality]", "asdr[quality]")
          : comparisonFilter,
        "-map",
        "[quality]",
        "-f",
        "null",
        "NUL",
      ],
      {
        cwd: projectRoot,
        windowsHide: true,
        maxBuffer: 16 * 1024 * 1024,
      },
    );
    const channelQualityDb = [
      ...qualityLog.matchAll(
        asdrOutput
          ? /SDR ch\d+:\s+(inf|[+-]?(?:\d+(?:\.\d+)?|\.\d+))\s+dB/gi
          : /PSNR ch\d+:\s+(inf|[+-]?(?:\d+(?:\.\d+)?|\.\d+))\s+dB/gi,
      ),
    ].map((match) =>
      match[1].toLowerCase() === "inf"
        ? Number.POSITIVE_INFINITY
        : Number.parseFloat(match[1]),
    );
    if (
      channelQualityDb.length === 0 ||
      channelQualityDb.some(
        (value) =>
          !Number.isFinite(value) && value !== Number.POSITIVE_INFINITY,
      ) ||
      channelQualityDb.some((value) => value < minimumQualityDb)
    ) {
      throw new Error(
        `Browser decoded audio quality validation failed: ${channelQualityDb.join(", ") || `no ${asdrOutput ? "ASDR" : "APSNR"} result`} dB.`,
      );
    }
    independentAudioValidation = {
      method: asdrOutput ? "decoded-audio-asdr" : "decoded-audio-apsnr",
      passed: true,
      minimumRequiredDb: minimumQualityDb,
      [asdrOutput ? "channelSdrDb" : "channelPsnrDb"]: channelQualityDb.map(
        (value) => (value === Number.POSITIVE_INFINITY ? "Infinity" : value),
      ),
    };
  }
  if (route === "aac-to-m4a") {
    const packetHashes = [];
    for (const [candidateIndex, candidate] of [
      sourcePath,
      localPath,
    ].entries()) {
      const sourceAdtsFilter =
        candidateIndex === 0 ? ["-bsf:a", "aac_adtstoasc"] : [];
      const { stdout: packetHash } = await execFileAsync(
        "ffmpeg",
        [
          "-hide_banner",
          "-loglevel",
          "error",
          "-i",
          candidate,
          "-map",
          "0:a:0",
          "-c:a",
          "copy",
          ...sourceAdtsFilter,
          "-f",
          "hash",
          "-hash",
          "sha256",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 8 * 1024 * 1024,
        },
      );
      packetHashes.push(packetHash.trim().split("=")[1]);
    }
    if (!packetHashes[0] || packetHashes[0] !== packetHashes[1]) {
      throw new Error(
        "Browser M4A AAC packets do not match the raw ADTS source payload.",
      );
    }
    independentAudioValidation = {
      method: "aac-packet-sha256",
      passed: true,
      sha256: packetHashes[0],
    };
  }
  if (route === "3gp-to-amr") {
    const packetHashes = [];
    for (const candidate of [sourcePath, localPath]) {
      const { stdout: packetHash } = await execFileAsync(
        "ffmpeg",
        [
          "-hide_banner",
          "-loglevel",
          "error",
          "-i",
          candidate,
          "-map",
          "0:a:0",
          "-c:a",
          "copy",
          "-f",
          "hash",
          "-hash",
          "sha256",
          "-",
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
      );
      packetHashes.push(packetHash.trim().split("=")[1]);
    }
    if (!packetHashes[0] || packetHashes[0] !== packetHashes[1]) {
      throw new Error(
        "Browser AMR packets do not match the 3GP source payload.",
      );
    }
    independentAudioValidation = {
      method: "amr-packet-sha256",
      passed: true,
      sha256: packetHashes[0],
    };
  }
  if (mp3Output && !mp3TranscodeOutput) {
    const { stdout: packetHash } = await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-i",
        localPath,
        "-map",
        "0:a:0",
        "-c",
        "copy",
        "-f",
        "hash",
        "-hash",
        "sha256",
        "-",
      ],
      {
        cwd: projectRoot,
        windowsHide: true,
        maxBuffer: 8 * 1024 * 1024,
      },
    );
    const sha256 = packetHash.trim().split("=")[1]?.toLowerCase();
    if (!sha256 || sha256 !== source.mp3PacketSha256) {
      throw new Error(
        "Browser MP3 output packets do not exactly match the source MP3 payload.",
      );
    }
    independentAudioValidation = {
      method: "mp3-packet-sha256",
      passed: true,
      sha256,
    };
  }
  if (aacPacketCopyOutput) {
    const { stdout: packetHash } = await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-i",
        localPath,
        "-map",
        "0:a:0",
        "-c",
        "copy",
        "-bsf:a",
        "aac_adtstoasc",
        "-f",
        "hash",
        "-hash",
        "sha256",
        "-",
      ],
      {
        cwd: projectRoot,
        windowsHide: true,
        maxBuffer: 8 * 1024 * 1024,
      },
    );
    const sha256 = packetHash.trim().split("=")[1]?.toLowerCase();
    if (!sha256 || sha256 !== source.aacAccessUnitSha256) {
      throw new Error(
        "Browser raw AAC access units do not exactly match the source AAC payload.",
      );
    }
    independentAudioValidation = {
      method: "aac-access-unit-sha256",
      passed: true,
      sha256,
    };
  }
  if (oggPacketOutput) {
    const { stdout: packetHash } = await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-xerror",
        "-i",
        localPath,
        "-map",
        "0:a:0",
        "-c",
        "copy",
        "-f",
        "hash",
        "-hash",
        "sha256",
        "-",
      ],
      {
        cwd: projectRoot,
        windowsHide: true,
        maxBuffer: 8 * 1024 * 1024,
      },
    );
    const sha256 = packetHash.trim().split("=")[1]?.toLowerCase();
    if (!sha256 || sha256 !== source.audioPacketSha256) {
      throw new Error(
        `Browser ${opusOutput ? "Opus" : "Vorbis"} packets do not exactly match the source payload.`,
      );
    }
    independentAudioValidation = {
      method: `${opusOutput ? "opus" : "vorbis"}-packet-sha256`,
      passed: true,
      sha256,
    };
  }
  if (compatibleOgvCopy || compatibleAviCopy || ivfOutput) {
    const packetHashes = {};
    const packetStreams = [
      ["video", "0:v:0", source.videoPacketSha256],
      ...(!ivfOutput && source.audioPacketSha256
        ? [["audio", "0:a:0", source.audioPacketSha256]]
        : []),
    ];
    for (const [kind, map, expected] of packetStreams) {
      const { stdout: packetHash } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-xerror",
          "-i",
          localPath,
          "-map",
          map,
          "-c",
          "copy",
          "-f",
          "hash",
          "-hash",
          "sha256",
          "-",
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
      );
      const sha256 = packetHash.trim().split("=")[1]?.toLowerCase();
      if (!sha256 || sha256 !== expected) {
        throw new Error(
          `Browser compatible ${ivfOutput ? "IVF" : compatibleAviCopy ? "AVI" : "OGV"} ${kind} packets do not exactly match the source payload.`,
        );
      }
      packetHashes[kind] = sha256;
    }
    independentAudioValidation = {
      method: ivfOutput
        ? `${source.probe?.streams?.find((stream) => stream.codec_type === "video")?.codec_name ?? "video"}-packet-sha256`
        : compatibleAviCopy
          ? source.audioPacketSha256
            ? `${source.probe?.streams?.find((stream) => stream.codec_type === "video")?.codec_name ?? "video"}-mp3-packet-sha256`
            : `${source.probe?.streams?.find((stream) => stream.codec_type === "video")?.codec_name ?? "video"}-packet-sha256`
          : "theora-vorbis-packet-sha256",
      passed: true,
      videoSha256: packetHashes.video,
      ...(!ivfOutput && source.audioPacketSha256
        ? { audioSha256: packetHashes.audio }
        : {}),
    };
  }
  if (compatibleWebmCopy) {
    const { stdout: decodedStreamHashes } = await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-xerror",
        "-i",
        localPath,
        "-map",
        "0:v:0",
        "-map",
        "0:a:0",
        "-f",
        "streamhash",
        "-hash",
        "sha256",
        "-",
      ],
      {
        cwd: projectRoot,
        windowsHide: true,
        maxBuffer: 16 * 1024 * 1024,
      },
    );
    const hashes = new Map(
      decodedStreamHashes
        .trim()
        .split(/\r?\n/)
        .map((line) => {
          const match = line.match(/^(\d+),([av]),SHA256=([0-9a-f]{64})$/i);
          return match ? [match[2], match[3].toLowerCase()] : ["", ""];
        }),
    );
    if (
      hashes.get("v") !== source.decodedVideoSha256 ||
      hashes.get("a") !== source.decodedAudioSha256
    ) {
      throw new Error(
        "Browser compatible WebM copy does not exactly match the decoded source video or audio.",
      );
    }
    independentAudioValidation = {
      method: "decoded-av-streamhash-sha256",
      passed: true,
      videoSha256: hashes.get("v"),
      audioSha256: hashes.get("a"),
    };
  }
  if (ivfInputCopy) {
    const { stdout: decodedHash } = await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-xerror",
        "-i",
        localPath,
        "-map",
        "0:v:0",
        "-f",
        "hash",
        "-hash",
        "sha256",
        "-",
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
    );
    const decodedVideoSha256 = decodedHash
      .trim()
      .match(/^SHA256=([0-9a-f]{64})$/i)?.[1]
      ?.toLowerCase();
    if (decodedVideoSha256 !== source.decodedVideoSha256) {
      throw new Error(
        "Browser IVF-input copy does not exactly match the decoded source video.",
      );
    }
    const sourceVideoCodec = source.probe?.streams?.find(
      (stream) => stream.codec_type === "video",
    )?.codec_name;
    let packetSha256 = null;
    if (sourceVideoCodec !== "av1") {
      const { stdout: packetHash } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-xerror",
          "-i",
          localPath,
          "-map",
          "0:v:0",
          "-c",
          "copy",
          "-f",
          "hash",
          "-hash",
          "sha256",
          "-",
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
      );
      packetSha256 = packetHash
        .trim()
        .match(/^SHA256=([0-9a-f]{64})$/i)?.[1]
        ?.toLowerCase();
      if (packetSha256 !== source.videoPacketSha256) {
        throw new Error(
          "Browser IVF-input copy changed the compressed VP8/VP9 packets.",
        );
      }
    }
    independentAudioValidation = {
      method:
        sourceVideoCodec === "av1"
          ? "decoded-video-sha256-with-av1-delimiter-normalization"
          : "decoded-video-and-packet-sha256",
      passed: true,
      decodedVideoSha256,
      ...(packetSha256 ? { videoPacketSha256: packetSha256 } : {}),
    };
  }
  const needsDecodedFrameCounts =
    aacOutput ||
    amrOutput ||
    elementaryVideoOutput ||
    compatibleOgvCopy ||
    compatibleAviCopy ||
    compatibleWebmCopy ||
    ivfInputCopy ||
    aviMpegTsCopy ||
    route === "avi-to-mkv";
  // Packet-copy routes are validated by a full output hash, packet counts,
  // metadata checks, and a complete copy traversal below. Decoding unchanged
  // video solely to populate nb_read_frames adds hours at multi-GiB scale.
  const { stdout } = await execFileAsync(
    "ffprobe",
    [
      "-v",
      "error",
      "-show_format",
      "-show_streams",
      "-show_chapters",
      ...(needsDecodedFrameCounts ? ["-count_frames"] : []),
      "-count_packets",
      "-of",
      "json",
      localPath,
    ],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
  );
  const probe = JSON.parse(stdout);
  const attachedPictures = probe.streams.filter(
    (stream) => stream.disposition?.attached_pic === 1,
  );
  if (
    (compatibleOgvCopy || theoraOgvReencode) &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("ogg")
  ) {
    throw new Error(
      "Browser OGV output did not probe as genuine Ogg.",
    );
  }
  if (
    compatibleAviCopy &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("avi")
  ) {
    throw new Error(
      "Browser compatible AVI output did not probe as genuine AVI.",
    );
  }
  if (
    ivfOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("ivf")
  ) {
    throw new Error("Browser IVF output did not probe as genuine IVF.");
  }
  if (
    ivfInputCopy &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("matroska")
  ) {
    throw new Error("Browser IVF-input output did not probe as Matroska/WebM.");
  }
  if (
    matroskaCopy &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("matroska")
  ) {
    throw new Error("Browser Matroska output did not probe as Matroska.");
  }
  if (
    containerMpegTsCopy &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("mpegts")
  ) {
    throw new Error("Browser MPEG-TS output did not probe as MPEG-TS.");
  }
  if (
    containerThreeGpCopy &&
    (!String(probe.format?.format_name ?? "")
      .split(",")
      .includes("3gp") ||
      !String(probe.format?.tags?.major_brand ?? "").startsWith("3gp"))
  ) {
    throw new Error("Browser 3GP output did not probe as genuine 3GP.");
  }
  if (
    containerMovCopy &&
    (!String(probe.format?.format_name ?? "")
      .split(",")
      .includes("mov") ||
      String(probe.format?.tags?.major_brand ?? "") !== "qt  ")
  ) {
    throw new Error(
      "Browser MOV output did not probe as genuine QuickTime MOV.",
    );
  }
  if (
    containerFlvCopy &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("flv")
  ) {
    throw new Error("Browser FLV output did not probe as genuine FLV.");
  }
  if (
    aiffOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("aiff")
  ) {
    throw new Error("Browser AIFF output did not probe as genuine AIFF.");
  }
  if (
    amrOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("amr")
  ) {
    throw new Error("Browser AMR output did not probe as genuine AMR.");
  }
  if (
    mp3TranscodeOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("mp3")
  ) {
    throw new Error("Browser MP3 output did not probe as genuine MP3.");
  }
  if (
    aacTranscodeOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes(m4aTranscodeOutput ? "mov" : "aac")
  ) {
    throw new Error(
      m4aTranscodeOutput
        ? "Browser M4A output did not probe as genuine QuickTime/M4A."
        : "Browser AAC output did not probe as genuine AAC ADTS.",
    );
  }
  if (
    opusTranscodeOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("ogg")
  ) {
    throw new Error("Browser Opus output did not probe as genuine Ogg.");
  }
  if (
    vorbisTranscodeOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("ogg")
  ) {
    throw new Error("Browser Vorbis output did not probe as genuine Ogg.");
  }
  if (
    wmaOutput &&
    !String(probe.format?.format_name ?? "")
      .split(",")
      .includes("asf")
  ) {
    throw new Error("Browser WMA output did not probe as genuine ASF.");
  }
  if (independentAudioValidation) {
    probe.withinValidation = independentAudioValidation;
  }
  if (source.artwork) {
    if (!(mp3Output || flacOutput || aiffOutput) || attachedPictures.length !== 1) {
      throw new Error(
        `Browser audio artwork validation expected one attached picture; received ${attachedPictures.length}.`,
      );
    }
    const outputArtwork = attachedPictures[0];
    if (
      outputArtwork.codec_name !== source.artwork.codec ||
      outputArtwork.width !== source.artwork.width ||
      outputArtwork.height !== source.artwork.height
    ) {
      throw new Error(
        `Browser audio artwork metadata changed: ${outputArtwork.codec_name ?? "unknown"} ${outputArtwork.width ?? 0}x${outputArtwork.height ?? 0}.`,
      );
    }
    const artworkValidationPath = path.join(
      path.dirname(localPath),
      `.artwork-validation-${process.pid}.${source.artwork.codec === "png" ? "png" : "jpg"}`,
    );
    try {
      await execFileAsync(
        "ffmpeg",
        [
          "-hide_banner",
          "-loglevel",
          "error",
          "-y",
          "-i",
          localPath,
          "-map",
          "0:v:0",
          "-c",
          "copy",
          artworkValidationPath,
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
      );
      const artworkValidation = await hashFile(artworkValidationPath);
      if (
        artworkValidation.bytes !== source.artwork.bytes ||
        artworkValidation.sha256 !== source.artwork.sha256
      ) {
        throw new Error(
          `Browser audio artwork bytes do not exactly match the source artwork: ${artworkValidation.bytes} bytes/${artworkValidation.sha256} != ${source.artwork.bytes} bytes/${source.artwork.sha256}.`,
        );
      }
      for (const [key, value] of Object.entries(source.expectedTags ?? {})) {
        if (probe.format?.tags?.[key] !== value) {
          throw new Error(
            `Browser audio tag ${key} changed: ${probe.format?.tags?.[key] ?? "missing"}.`,
          );
        }
      }
      probe.withinArtworkValidation = {
        method: "attached-picture-packet-sha256",
        passed: true,
        codec: outputArtwork.codec_name,
        width: outputArtwork.width,
        height: outputArtwork.height,
        bytes: artworkValidation.bytes,
        sha256: artworkValidation.sha256,
        tags: source.expectedTags ?? {},
      };
    } finally {
      await rm(artworkValidationPath, { force: true });
    }
  }
  const primaryStreams = probe.streams.filter(
    (stream) => stream.disposition?.attached_pic !== 1,
  );
  const codecs = primaryStreams.map((stream) => stream.codec_name);
  const sourceVideo = source.probe.streams.find(
    (stream) =>
      stream.codec_type === "video" && !stream.disposition?.attached_pic,
  );
  const sourceAudio = source.probe.streams.find(
    (stream) => stream.codec_type === "audio",
  );
  if (
    (audioOnly &&
      (codecs.length !== 1 ||
        codecs[0] !==
          (aiffOutput
            ? "pcm_s16be"
            : amrOutput
              ? "amr_nb"
              : pcmOutput
                ? "pcm_s16le"
                : flacOutput
                  ? "flac"
                  : alacOutput
                    ? "alac"
                    : wmaOutput
                      ? "wmav2"
                      : mp3Output
                        ? "mp3"
                        : opusTranscodeOutput
                          ? "opus"
                          : vorbisTranscodeOutput
                            ? "vorbis"
                            : oggPacketOutput
                              ? opusOutput
                                ? "opus"
                                : "vorbis"
                              : "aac"))) ||
    (videoReencode &&
      (codecs.length !== (webmAudioCopy ? 2 : 1) ||
        codecs[0] !==
          (theoraOgvReencode
            ? "theora"
            : vp9Reencode
              ? "vp9"
              : webmReencode
                ? "vp8"
                : "mpeg4") ||
        (webmAudioCopy && codecs[1] !== "vorbis"))) ||
    (videoOnlyCopy &&
      (codecs.length !== 1 ||
        codecs[0] !==
          (ivfOutput || ivfInputCopy
            ? sourceVideo?.codec_name
            : mpeg2Output || mpeg2TransportOutput
              ? "mpeg2video"
              : m4vOutput || m4vMp4Output
                ? "mpeg4"
                : hevcOutput
                  ? "hevc"
                  : "h264"))) ||
    (compatibleAviCopy &&
      (codecs.length !== (sourceAudio ? 2 : 1) ||
        codecs[0] !== sourceVideo?.codec_name ||
        (sourceAudio && codecs[1] !== "mp3"))) ||
    (aviVideoOnlyIsoCopy &&
      (codecs.length !== 1 || codecs[0] !== sourceVideo?.codec_name)) ||
    (!audioOnly &&
      !videoReencode &&
      !videoOnlyCopy &&
      !compatibleAviCopy &&
      !aviVideoOnlyIsoCopy &&
      (codecs.length !== 2 ||
        codecs[0] !== sourceVideo?.codec_name ||
        codecs[1] !== sourceAudio?.codec_name))
  ) {
    throw new Error(`Unexpected browser media streams: ${codecs.join(", ")}.`);
  }
  const video = primaryStreams.find((stream) => stream.codec_type === "video");
  const audio = primaryStreams.find((stream) => stream.codec_type === "audio");
  const [videoRateNumerator, videoRateDenominator] = String(
    primaryStreams.find((stream) => stream.codec_type === "video")
      ?.avg_frame_rate ?? "0/0",
  )
    .split("/")
    .map(Number);
  const decodedVideoDuration =
    (Number(video?.nb_read_frames) * videoRateDenominator) / videoRateNumerator;
  const decodedAacDuration =
    (Number(audio?.nb_read_frames) * 1024) / Number(audio?.sample_rate);
  const probedOutputDuration = Number(probe.format.duration);
  const countedAmrDuration = amrOutput
    ? Number(audio?.nb_read_frames) * 0.02
    : Number.NaN;
  const duration =
    amrOutput && Number.isFinite(countedAmrDuration)
      ? countedAmrDuration
      : aacOutput && Number.isFinite(decodedAacDuration)
        ? decodedAacDuration
        : route === "avi-to-mkv" && Number.isFinite(decodedVideoDuration)
          ? decodedVideoDuration
          : Number.isFinite(probedOutputDuration)
            ? probedOutputDuration
            : decodedVideoDuration;
  const normalizedOutputLanguage =
    audio?.tags?.language && audio.tags.language !== "und"
      ? audio.tags.language
      : null;
  const normalizedSourceLanguage =
    sourceAudio?.tags?.language && sourceAudio.tags.language !== "und"
      ? sourceAudio.tags.language
      : null;
  const sourceDuration = sourceDurationSeconds;
  const expectedDuration = compatibleAviCopy
    ? sourceDuration +
      Math.max(0, Number(source.probe?.format?.start_time) || 0)
    : elementaryVideoOutput
      ? decodedVideoDuration
      : aacPacketCopyOutput &&
          Number.isFinite(Number(source.aacAccessUnitCount))
        ? (Number(source.aacAccessUnitCount) * 1024) /
          Number(sourceAudio?.sample_rate)
        : audioOnly &&
            (pcmOutput ||
              flacOutput ||
              alacOutput ||
              amrOutput ||
              mp3TranscodeOutput ||
              aacTranscodeOutput ||
              opusTranscodeOutput ||
              vorbisTranscodeOutput ||
              wmaOutput ||
              route === "aac-to-m4a")
          ? (source.decodedAudioDurationSeconds ?? sourceDuration)
          : sourceDuration;
  const boundedWidthVideoReencode = webmReencode || theoraOgvReencode;
  const expectedVideoWidth = boundedWidthVideoReencode
    ? Math.min(640, sourceVideo?.width ?? 0)
    : sourceVideo?.width;
  const expectedVideoHeight =
    boundedWidthVideoReencode && (sourceVideo?.width ?? 0) > 640
      ? Math.max(
          2,
          Math.floor(
            ((sourceVideo?.height ?? 0) * expectedVideoWidth) /
              sourceVideo.width,
          ) & ~1,
        )
      : sourceVideo?.height;
  const expectedTranscodedAudioChannels =
    audioOptions.channels || Math.min(2, sourceAudio?.channels ?? 0);
  const measuredAudioBitRate = Number(audio?.bit_rate);
  const customAacBitRateMatches =
    measuredAudioBitRate >= compressedAudioOutputBitRate * 0.6 &&
    measuredAudioBitRate <= compressedAudioOutputBitRate * 1.15;
  const customOpusBitRateMatches =
    measuredAudioBitRate >= opusOutputBitRate * 0.6 &&
    measuredAudioBitRate <= opusOutputBitRate * 1.25;
  const customWmaBitRateMatches =
    measuredAudioBitRate >= audioOptions.bitRateBps * 0.6 &&
    measuredAudioBitRate <= audioOptions.bitRateBps * 1.15;
  if (
    (!audioOnly &&
      (video?.width !== expectedVideoWidth ||
        video?.height !== expectedVideoHeight)) ||
    (!videoOnlyCopy &&
      (audioOnly ||
        webmAudioCopy ||
        compatibleOgvCopy ||
        compatibleAviCopy ||
        compatibleWebmCopy ||
        matroskaCopy ||
        containerMpegTsCopy ||
        (containerThreeGpCopy && !aviVideoOnlyIsoCopy) ||
        (containerMovCopy && !aviVideoOnlyIsoCopy) ||
        containerFlvCopy) &&
      audio?.channels !==
        (amrOutput
          ? 1
          : mp3TranscodeOutput
            ? expectedTranscodedAudioChannels
            : aacTranscodeOutput
              ? expectedTranscodedAudioChannels
              : opusTranscodeOutput
                ? expectedTranscodedAudioChannels
                : vorbisTranscodeOutput
                  ? expectedTranscodedAudioChannels
                  : wmaOutput
                    ? expectedTranscodedAudioChannels
                    : sourceAudio?.channels)) ||
    (audioOnly &&
      audioOptions.sampleRateHz !== 0 &&
      !opusTranscodeOutput &&
      Number(audio?.sample_rate) !== audioOptions.sampleRateHz) ||
    (amrOutput &&
      (Number(audio?.sample_rate) !== 8000 ||
        Number(audio?.bit_rate) !== 12400)) ||
    (mp3TranscodeOutput &&
      (Number(audio?.sample_rate) !== mp3OutputSampleRate ||
        Number(audio?.bit_rate) !== mp3OutputBitRate)) ||
    (aacTranscodeOutput &&
      ((audioOptions.sampleRateHz === 0 &&
        ![
          8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000,
        ].includes(Number(audio?.sample_rate))) ||
        (hasCustomAudioOptions
          ? !customAacBitRateMatches
          : measuredAudioBitRate <= 0 || measuredAudioBitRate > 220000))) ||
    (opusTranscodeOutput &&
      (Number(audio?.sample_rate) !== 48000 ||
        (hasCustomAudioOptions
          ? !customOpusBitRateMatches
          : measuredAudioBitRate <= 0 || measuredAudioBitRate > 160000))) ||
    (vorbisTranscodeOutput &&
      (Number(audio?.sample_rate) <= 0 ||
        Number(audio?.sample_rate) > 48000 ||
        measuredAudioBitRate <= 0 ||
        measuredAudioBitRate >
          (audioOptions.quality === "higher" ? 500000 : 220000))) ||
    (wmaOutput &&
      (Number(audio?.sample_rate) !==
        (audioOptions.sampleRateHz ||
          (route === "amr-wb-to-wma" ? 32000 : 48000)) ||
        (audioOptions.bitRateBps !== 0
          ? !customWmaBitRateMatches
          : measuredAudioBitRate !==
            (route === "amr-wb-to-wma" ? 64000 : 320000)))) ||
    ((route === "mkv-to-m4a" ||
      route === "mov-to-m4a" ||
      route === "3gp-to-m4a" ||
      route === "mpeg-ts-to-m4a" ||
      route === "flv-to-m4a" ||
      route === "mp4-to-m4a" ||
      route === "aac-to-m4a" ||
      m4aTranscodeOutput ||
      route === "wav-to-alac" ||
      route === "flac-to-alac" ||
      oggPacketOutput ||
      webmAudioCopy ||
      compatibleOgvCopy ||
      compatibleWebmCopy ||
      matroskaCopy ||
      containerThreeGpCopy ||
      containerMovCopy) &&
      normalizedOutputLanguage !== normalizedSourceLanguage) ||
    ((compatibleWebmCopy || liveMatroskaCopy) &&
      Number.isFinite(probedOutputDuration)) ||
    ((!matroskaCopy || route === "avi-to-mkv") &&
      Math.abs(duration - expectedDuration) >
        (aacTranscodeOutput
          ? Math.max(0.2, 2048 / Number(audio?.sample_rate) + 0.01)
          : 0.25))
  ) {
    throw new Error(
      `Browser media metadata validation failed: ${JSON.stringify({
        actualVideo: [video?.width ?? null, video?.height ?? null],
        expectedVideo: [expectedVideoWidth ?? null, expectedVideoHeight ?? null],
        actualAudioChannels: audio?.channels ?? null,
        expectedSourceAudioChannels: sourceAudio?.channels ?? null,
        videoOnlyCopy,
        outputLanguage: normalizedOutputLanguage,
        sourceLanguage: normalizedSourceLanguage,
        probedOutputDuration: Number.isFinite(probedOutputDuration)
          ? probedOutputDuration
          : null,
        measuredDuration: duration,
        expectedDuration,
        durationDelta: Math.abs(duration - expectedDuration),
      })}.`,
    );
  }
  if (
    ivfInputCopy &&
    Number(video?.nb_read_packets) !== Number(source.videoPacketCount)
  ) {
    throw new Error(
      `Browser IVF-input packet count changed: ${video?.nb_read_packets ?? "unavailable"} video packets.`,
    );
  }
  if (
    aacPacketCopyOutput &&
    Number(audio?.nb_read_frames) !== Number(source.aacAccessUnitCount)
  ) {
    throw new Error(
      `Browser raw AAC output produced ${audio?.nb_read_frames ?? "unavailable"} access units; expected ${source.aacAccessUnitCount}.`,
    );
  }
  if (
    oggPacketOutput &&
    Number(audio?.nb_read_packets) !== Number(source.audioPacketCount)
  ) {
    throw new Error(
      `Browser ${opusOutput ? "Opus" : "Vorbis"} output produced ${audio?.nb_read_packets ?? "unavailable"} packets; expected ${source.audioPacketCount}.`,
    );
  }
  if (
    (compatibleOgvCopy || compatibleAviCopy || ivfOutput) &&
    (Number(video?.nb_read_packets) !== Number(source.videoPacketCount) ||
      (!ivfOutput &&
        source.audioPacketSha256 &&
        Number(audio?.nb_read_packets) !== Number(source.audioPacketCount)))
  ) {
    throw new Error(
      `Browser compatible ${ivfOutput ? "IVF" : compatibleAviCopy ? "AVI" : "OGV"} packet counts changed: ${video?.nb_read_packets ?? "unavailable"} video/${audio?.nb_read_packets ?? "not applicable"} audio.`,
    );
  }
  if (
    (elementaryVideoOutput ||
      compatibleOgvCopy ||
      compatibleAviCopy ||
      compatibleWebmCopy ||
      ivfInputCopy) &&
    Number.isFinite(Number(source.decodedVideoFrames)) &&
    Number(video?.nb_read_frames) !== Number(source.decodedVideoFrames)
  ) {
    throw new Error(
      `Browser video output produced ${video?.nb_read_frames ?? "unavailable"} decoded frames; expected ${source.decodedVideoFrames}.`,
    );
  }
  if (
    (compatibleOgvCopy ||
      compatibleAviCopy ||
      ivfOutput ||
      compatibleWebmCopy ||
      ivfInputCopy) &&
    (probe.chapters?.length ?? 0) !== 0
  ) {
    throw new Error(
      "Browser compatible stream-copy output unexpectedly contains chapters.",
    );
  }
  if (videoReencode && video) {
    const midpoint =
      route.startsWith("h264-to-") || route.startsWith("hevc-to-")
      ? 0
      : Math.max(0, sourceDuration / 2);
    const seekArguments = midpoint > 0 ? ["-ss", midpoint.toFixed(3)] : [];
    const { stderr: similarityLog } = await execFileAsync(
      "ffmpeg",
      [
        "-hide_banner",
        "-nostdin",
        ...seekArguments,
        "-i",
        sourcePath,
        ...seekArguments,
        "-i",
        localPath,
        "-filter_complex",
        `[0:v:0]scale=${video.width}:${video.height}:flags=bicubic,format=yuv420p,setpts=PTS-STARTPTS[source];[1:v:0]format=yuv420p,setpts=PTS-STARTPTS[converted];[source][converted]ssim[quality]`,
        "-map",
        "[quality]",
        "-frames:v",
        "1",
        "-f",
        "null",
        "NUL",
      ],
      {
        cwd: projectRoot,
        windowsHide: true,
        maxBuffer: 16 * 1024 * 1024,
      },
    );
    const similarity = Number.parseFloat(
      similarityLog.match(/SSIM[^\r\n]*All:([0-9.]+)/)?.[1] ?? "",
    );
    if (!Number.isFinite(similarity) || similarity < 0.35) {
      const diagnosticTail = similarityLog
        .split(/\r?\n/)
        .filter(Boolean)
        .slice(-8)
        .join(" | ")
        .slice(0, 2_048);
      throw new Error(
        `Browser video midpoint visual validation failed: SSIM ${Number.isFinite(similarity) ? similarity : "unavailable"}.${diagnosticTail ? ` Validator tail: ${diagnosticTail}` : ""}`,
      );
    }
    probe.withinValidation = {
      ...(probe.withinValidation ?? {}),
      midpointSeconds: midpoint,
      midpointVisualSsim: similarity,
      minimumVisualSsim: 0.35,
    };
  }
  const sourceHasSubtitle = source.probe.streams.some(
    (stream) => stream.codec_type === "subtitle",
  );
  const sourceAttachedPictureCount = source.probe.streams.filter(
    (stream) => stream.disposition?.attached_pic === 1,
  ).length;
  const preservedArtworkCount =
    source.artwork && (mp3Output || flacOutput) ? 1 : 0;
  const sourceHasAttachment =
    source.probe.streams.some((stream) => stream.codec_type === "attachment") ||
    sourceAttachedPictureCount > preservedArtworkCount;
  if (
    (!matroskaCopy &&
      sourceHasSubtitle &&
      !finalState.warnings.some((warning) => warning.includes("subtitle"))) ||
    (!matroskaCopy &&
      sourceHasAttachment &&
      !finalState.warnings.some(
        (warning) =>
          warning.includes("attachment") ||
          warning.includes("attached picture"),
      ))
  ) {
    throw new Error(
      "The browser did not explicitly disclose excluded subtitle and attachment streams.",
    );
  }
  if (
    !matroskaCopy &&
    (source.probe.chapters?.length ?? 0) > 0 &&
    !finalState.warnings.some((warning) => warning.includes("chapter"))
  ) {
    throw new Error(
      "The browser did not explicitly disclose the excluded source chapters.",
    );
  }
  if (
    audioOnly &&
    sourceVideo &&
    !finalState.warnings.some((warning) => warning.includes("video stream"))
  ) {
    throw new Error(
      "The browser did not explicitly disclose the excluded video stream.",
    );
  }
  if (
    videoReencode &&
    !webmAudioCopy &&
    sourceAudio &&
    !finalState.warnings.some((warning) => warning.includes("audio stream"))
  ) {
    throw new Error(
      "The browser did not explicitly disclose the excluded audio stream.",
    );
  }
  if (
    elementaryVideoOutput &&
    sourceAudio &&
    !finalState.warnings.some((warning) =>
      warning.includes("Audio cannot be represented"),
    )
  ) {
    throw new Error(
      "The browser did not explicitly disclose audio excluded from elementary-video output.",
    );
  }
  if (
    aviVideoOnlyIsoCopy &&
    sourceAudio &&
    !finalState.warnings.some((warning) =>
      warning.includes("incompatible AVI audio was explicitly excluded"),
    )
  ) {
    throw new Error(
      `The browser did not explicitly disclose incompatible AVI audio excluded from ${route === "avi-to-3gp" ? "3GP" : "MOV"}.`,
    );
  }
  const requiresFullDecodeTraversal =
    videoReencode ||
    elementaryVideoOutput ||
    mpeg2TransportOutput ||
    m4vMp4Output ||
    compatibleOgvCopy ||
    compatibleAviCopy ||
    compatibleWebmCopy ||
    ivfInputCopy ||
    matroskaCopy ||
    containerThreeGpCopy ||
    containerMovCopy ||
    containerFlvCopy ||
    mp3Output ||
    aacOutput ||
    oggPacketOutput ||
    route === "h264-to-mp4" ||
    route === "mkv-to-m4a" ||
    route === "mov-to-m4a" ||
    route === "3gp-to-m4a" ||
    route === "mpeg-ts-to-m4a" ||
    route === "flv-to-m4a" ||
    route === "mp4-to-m4a" ||
    route === "aac-to-m4a" ||
    m4aTranscodeOutput ||
    route === "wav-to-alac" ||
    route === "flac-to-alac" ||
    WMA_OUTPUT_PROFILES.includes(route);
  const outputHasAudio =
    audioOnly ||
    webmAudioCopy ||
    (!aviVideoOnlyIsoCopy &&
      (compatibleAviCopy
        ? Boolean(source.audioPacketSha256)
        : !videoReencode && !videoOnlyCopy));
  if (compatibleAviCopy) {
    probe.withinAviStructure = await inspectAviOpenDml(
      localPath,
      source.maximumPacketBytes,
      Boolean(source.audioPacketSha256),
    );
    const midpoint = Math.max(0, sourceDurationSeconds / 2);
    await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-xerror",
        "-ss",
        midpoint.toFixed(3),
        "-i",
        localPath,
        "-map",
        "0:v:0",
        "-frames:v",
        "1",
        "-f",
        "null",
        "NUL",
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
    );
    probe.withinAviStructure.midpointSeekSeconds = midpoint;
    probe.withinAviStructure.midpointSeekPassed = true;
  }
  if (ivfOutput) {
    const sourceRate = String(
      sourceVideo?.avg_frame_rate || sourceVideo?.r_frame_rate || "0/0",
    )
      .split("/")
      .map(Number);
    const header = Buffer.alloc(32);
    const file = await open(localPath, "r");
    try {
      const { bytesRead } = await file.read(header, 0, header.length, 0);
      if (bytesRead !== header.length) {
        throw new Error(
          `Browser IVF header is truncated at ${bytesRead} bytes.`,
        );
      }
    } finally {
      await file.close();
    }
    const expectedFourCc = new Map([
      ["av1", "AV01"],
      ["vp8", "VP80"],
      ["vp9", "VP90"],
    ]).get(sourceVideo?.codec_name);
    const structure = {
      signature: header.toString("ascii", 0, 4),
      version: header.readUInt16LE(4),
      headerBytes: header.readUInt16LE(6),
      fourCc: header.toString("ascii", 8, 12),
      width: header.readUInt16LE(12),
      height: header.readUInt16LE(14),
      rate: header.readUInt32LE(16),
      scale: header.readUInt32LE(20),
      frameCount: header.readUInt32LE(24),
    };
    if (
      structure.signature !== "DKIF" ||
      structure.version !== 0 ||
      structure.headerBytes !== 32 ||
      !expectedFourCc ||
      structure.fourCc !== expectedFourCc ||
      structure.width !== sourceVideo?.width ||
      structure.height !== sourceVideo?.height ||
      structure.rate !== sourceRate[0] ||
      structure.scale !== sourceRate[1] ||
      structure.frameCount !== Number(source.decodedVideoFrames)
    ) {
      throw new Error(
        `Browser IVF header is invalid: ${JSON.stringify(structure)}.`,
      );
    }
    const midpoint = Math.max(0, sourceDurationSeconds / 2);
    await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-xerror",
        "-ss",
        midpoint.toFixed(3),
        "-i",
        localPath,
        "-map",
        "0:v:0",
        "-frames:v",
        "1",
        "-f",
        "null",
        "NUL",
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
    );
    const { stdout: decodedHash } = await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-xerror",
        "-i",
        localPath,
        "-map",
        "0:v:0",
        "-f",
        "hash",
        "-hash",
        "sha256",
        "-",
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
    );
    const decodedVideoSha256 = decodedHash
      .trim()
      .match(/^SHA256=([0-9a-f]{64})$/i)?.[1]
      ?.toLowerCase();
    if (decodedVideoSha256 !== source.decodedVideoSha256) {
      throw new Error(
        "Browser IVF decoded video does not exactly match the source frames.",
      );
    }
    probe.withinIvfStructure = {
      ...structure,
      midpointSeekSeconds: midpoint,
      midpointSeekPassed: true,
      decodedVideoSha256,
      decodedVideoHashPassed: true,
    };
  }
  if (matroskaCopy) {
    const hashes = [];
    for (const candidate of [sourcePath, localPath]) {
      const { stdout: decodedStreamHashes } = await execFileAsync(
        "ffmpeg",
        route === "avi-to-mkv" || route === "ivf-to-mkv"
          ? [
              "-v",
              "error",
              "-xerror",
              "-i",
              candidate,
              "-map",
              "0:v:0",
              "-f",
              "hash",
              "-hash",
              "sha256",
              "-",
            ]
          : [
              "-v",
              "error",
              "-xerror",
              "-i",
              candidate,
              "-map",
              "0:v:0",
              "-map",
              "0:a:0",
              "-f",
              "streamhash",
              "-hash",
              "sha256",
              "-",
            ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 16 * 1024 * 1024,
        },
      );
      hashes.push(decodedStreamHashes.trim());
    }
    if (!hashes[0] || hashes[0] !== hashes[1]) {
      throw new Error(
        "Browser Matroska decoded video or audio does not exactly match the source.",
      );
    }
    probe.withinValidation = {
      ...(probe.withinValidation ?? {}),
      decodedStreamHash: hashes[0],
    };
    if (route === "avi-to-mkv") {
      const packetHashes = [];
      for (const candidate of [sourcePath, localPath]) {
        const { stdout: packetHash } = await execFileAsync(
          "ffmpeg",
          [
            "-v",
            "error",
            "-xerror",
            "-i",
            candidate,
            "-map",
            "0:a:0",
            "-c",
            "copy",
            "-f",
            "hash",
            "-hash",
            "sha256",
            "-",
          ],
          {
            cwd: projectRoot,
            windowsHide: true,
            maxBuffer: 16 * 1024 * 1024,
          },
        );
        packetHashes.push(packetHash.trim());
      }
      if (!packetHashes[0] || packetHashes[0] !== packetHashes[1]) {
        throw new Error(
          "Browser AVI-to-Matroska MP3 packets do not exactly match the source.",
        );
      }
      probe.withinValidation.audioPacketHash = packetHashes[0];
    }
  } else if (mkvMp4Copy) {
    const packetStreamHashes = [];
    for (const candidate of [sourcePath, localPath]) {
      const { stdout: packetStreamHash } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-xerror",
          "-i",
          candidate,
          "-map",
          "0:v:0",
          "-map",
          "0:a:0",
          "-c",
          "copy",
          "-f",
          "streamhash",
          "-hash",
          "sha256",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 16 * 1024 * 1024,
        },
      );
      packetStreamHashes.push(packetStreamHash.trim());
    }
    if (
      !packetStreamHashes[0] ||
      packetStreamHashes[0] !== packetStreamHashes[1]
    ) {
      throw new Error(
        "Browser MKV-to-MP4 compressed HEVC or AAC packets do not exactly match the source.",
      );
    }
    probe.withinValidation = {
      ...(probe.withinValidation ?? {}),
      compressedPacketStreamHash: packetStreamHashes[0],
    };
  } else if (aviMpegTsCopy) {
    const hashesByKind = { decodedVideo: [], videoPacket: [], audioPacket: [] };
    for (const candidate of [sourcePath, localPath]) {
      for (const [kind, arguments_] of [
        ["decodedVideo", ["-map", "0:v:0"]],
        ["videoPacket", ["-map", "0:v:0", "-c", "copy"]],
        ["audioPacket", ["-map", "0:a:0", "-c", "copy"]],
      ]) {
        const { stdout: hashOutput } = await execFileAsync(
          "ffmpeg",
          [
            "-v",
            "error",
            "-xerror",
            "-i",
            candidate,
            ...arguments_,
            "-f",
            "hash",
            "-hash",
            "sha256",
            "-",
          ],
          {
            cwd: projectRoot,
            windowsHide: true,
            maxBuffer: 16 * 1024 * 1024,
          },
        );
        hashesByKind[kind].push(hashOutput.trim());
      }
    }
    for (const [kind, hashes] of Object.entries(hashesByKind)) {
      if (!hashes[0] || hashes[0] !== hashes[1]) {
        throw new Error(`Browser AVI-to-MPEG-TS ${kind} hash changed.`);
      }
    }
    probe.withinValidation = {
      ...(probe.withinValidation ?? {}),
      decodedVideoHash: hashesByKind.decodedVideo[0],
      videoPacketHash: hashesByKind.videoPacket[0],
      audioPacketHash: hashesByKind.audioPacket[0],
    };
  } else if (containerMpegTsCopy) {
    const packetStreamHashes = [];
    for (const candidate of [sourcePath, localPath]) {
      const { stdout: packetStreamHash } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-xerror",
          "-i",
          candidate,
          "-map",
          "0:v:0",
          "-map",
          "0:a:0",
          "-c:v",
          "rawvideo",
          "-pix_fmt",
          "yuv420p",
          "-c:a",
          "copy",
          "-bsf:a",
          "aac_adtstoasc",
          "-f",
          "streamhash",
          "-hash",
          "sha256",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 16 * 1024 * 1024,
        },
      );
      packetStreamHashes.push(packetStreamHash.trim());
    }
    if (
      !packetStreamHashes[0] ||
      packetStreamHashes[0] !== packetStreamHashes[1]
    ) {
      throw new Error(
        "Browser MPEG-TS decoded video frames or AAC access units do not exactly match the source.",
      );
    }
    probe.withinValidation = {
      ...(probe.withinValidation ?? {}),
      decodedVideoAndAacStreamHash: packetStreamHashes[0],
    };
  } else if (containerThreeGpCopy || containerMovCopy || containerFlvCopy) {
    const packetStreamHashes = [];
    for (const [candidateIndex, candidate] of [
      sourcePath,
      localPath,
    ].entries()) {
      const sourceAdtsFilter =
        candidateIndex === 0 &&
        (route === "mpeg-ts-to-3gp" ||
          route === "mpeg-ts-to-mov" ||
          route === "mpeg-ts-to-flv")
          ? ["-bsf:a", "aac_adtstoasc"]
          : [];
      const { stdout: packetStreamHash } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-xerror",
          "-i",
          candidate,
          "-map",
          "0:v:0",
          ...(aviVideoOnlyIsoCopy ? [] : ["-map", "0:a:0"]),
          "-c:v",
          "rawvideo",
          "-pix_fmt",
          "yuv420p",
          ...(aviVideoOnlyIsoCopy ? [] : ["-c:a", "copy"]),
          ...sourceAdtsFilter,
          "-f",
          "streamhash",
          "-hash",
          "sha256",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 16 * 1024 * 1024,
        },
      );
      packetStreamHashes.push(packetStreamHash.trim());
    }
    if (
      !packetStreamHashes[0] ||
      packetStreamHashes[0] !== packetStreamHashes[1]
    ) {
      throw new Error(
        `Browser ${containerThreeGpCopy ? "3GP" : containerMovCopy ? "MOV" : "FLV"} decoded video frames${aviVideoOnlyIsoCopy ? "" : route === "avi-to-flv" ? " or MP3 packets" : " or AAC access units"} do not exactly match the source.`,
      );
    }
    probe.withinValidation = {
      ...(probe.withinValidation ?? {}),
      decodedVideoAndAacStreamHash: packetStreamHashes[0],
    };
  } else if (!compatibleWebmCopy) {
    await execFileAsync(
      "ffmpeg",
      [
        "-v",
        "error",
        "-i",
        localPath,
        ...(audioOnly ? [] : ["-map", "0:v:0"]),
        ...(outputHasAudio ? ["-map", "0:a:0"] : []),
        ...(requiresFullDecodeTraversal ? [] : ["-c", "copy"]),
        "-f",
        "null",
        "NUL",
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 16 * 1024 * 1024 },
    );
  }
  probe.withinValidation = {
    ...(probe.withinValidation ?? {}),
    mediaTraversal:
      mkvMp4Copy
        ? "full-compressed-packet-hash"
        : compatibleOgvCopy ||
            compatibleAviCopy ||
            ivfOutput ||
            ivfInputCopy ||
            aviMpegTsCopy
          ? "full-native-decode-and-packet-hash"
          : compatibleWebmCopy || matroskaCopy
            ? "full-native-decode-and-streamhash"
            : containerMpegTsCopy ||
              containerThreeGpCopy ||
              containerMovCopy ||
              containerFlvCopy
              ? route === "avi-to-flv"
                ? "full-decoded-video-and-mp3-streamhash"
                : "full-decoded-video-and-aac-streamhash"
              : requiresFullDecodeTraversal
                ? "full-native-decode"
                : "full-packet-traversal",
  };
  return probe;
}

async function inspectAviOpenDml(
  filePath,
  sourceMaximumPacketBytes,
  expectAudio = true,
) {
  const riffLimitBytes = 8 * 1024 * 1024;
  const maximumPacketBytes = Number.isFinite(Number(sourceMaximumPacketBytes))
    ? Number(sourceMaximumPacketBytes)
    : 1024 * 1024;
  const maximumSegmentBytes = riffLimitBytes + maximumPacketBytes + 1024 * 1024;
  const handle = await open(filePath, "r");
  try {
    const file = await handle.stat();
    const segments = [];
    let offset = 0;
    let hasMasterIndex = false;
    let standardVideoIndexes = 0;
    let standardAudioIndexes = 0;
    while (offset < file.size) {
      const header = Buffer.alloc(12);
      const headerRead = await handle.read(header, 0, header.length, offset);
      if (
        headerRead.bytesRead !== header.length ||
        header.toString("ascii", 0, 4) !== "RIFF"
      ) {
        throw new Error(
          `AVI RIFF segment header is invalid at byte ${offset}.`,
        );
      }
      const bytes = header.readUInt32LE(4) + 8;
      const formType = header.toString("ascii", 8, 12);
      if (
        bytes < 12 ||
        offset + bytes > file.size ||
        (segments.length === 0 ? formType !== "AVI " : formType !== "AVIX")
      ) {
        throw new Error(
          `AVI RIFF segment ${segments.length} has an invalid size or form type.`,
        );
      }
      if (bytes > maximumSegmentBytes) {
        throw new Error(
          `AVI RIFF segment ${segments.length} is ${bytes} bytes; the bounded design allows at most ${maximumSegmentBytes}.`,
        );
      }
      const data = Buffer.alloc(bytes);
      const segmentRead = await handle.read(data, 0, data.length, offset);
      if (segmentRead.bytesRead !== data.length) {
        throw new Error(
          `AVI RIFF segment ${segments.length} could not be read completely.`,
        );
      }
      hasMasterIndex ||= data.indexOf("indx", 12, "ascii") >= 0;
      standardVideoIndexes += countAscii(data, "ix00");
      standardAudioIndexes += countAscii(data, "ix01");
      segments.push({ index: segments.length, offset, bytes, formType });
      offset += bytes + (bytes & 1);
    }
    if (
      offset !== file.size ||
      !hasMasterIndex ||
      standardVideoIndexes < 1 ||
      (expectAudio ? standardAudioIndexes < 1 : standardAudioIndexes !== 0) ||
      (file.size > riffLimitBytes && segments.length < 2)
    ) {
      throw new Error(
        "AVI OpenDML indexes or bounded RIFF rollover are incomplete.",
      );
    }
    return {
      fileBytes: file.size,
      configuredRiffLimitBytes: riffLimitBytes,
      maximumPacketBytes,
      maximumAllowedSegmentBytes: maximumSegmentBytes,
      maximumObservedSegmentBytes: Math.max(
        ...segments.map((segment) => segment.bytes),
      ),
      segmentCount: segments.length,
      hasMasterIndex,
      standardVideoIndexes,
      standardAudioIndexes,
      segments,
    };
  } finally {
    await handle.close();
  }
}

function countAscii(buffer, value) {
  let count = 0;
  let offset = 0;
  for (;;) {
    const index = buffer.indexOf(value, offset, "ascii");
    if (index < 0) return count;
    count += 1;
    offset = index + value.length;
  }
}

async function hashFile(filePath) {
  const hash = createHash("sha256");
  let bytes = 0;
  for await (const chunk of createReadStream(filePath, {
    highWaterMark: 1024 * 1024,
  })) {
    hash.update(chunk);
    bytes += chunk.byteLength;
  }
  return { bytes, sha256: hash.digest("hex") };
}

async function validateDocxOutput(filePath) {
  const python = String.raw`
import hashlib, json, sys, xml.sax, zipfile
from xml.etree import ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

class DocumentHandler(xml.sax.ContentHandler):
    def __init__(self):
        super().__init__()
        self.hash = hashlib.sha256()
        self.bytes = 0
        self.in_text = False

    def add(self, value):
        encoded = value.encode("utf-8")
        self.hash.update(encoded)
        self.bytes += len(encoded)

    def startElementNS(self, name, qname, attrs):
        if name == (W, "t"):
            self.in_text = True
        elif name == (W, "tab"):
            self.add("\t")

    def endElementNS(self, name, qname):
        if name == (W, "t"):
            self.in_text = False
        elif name == (W, "p"):
            self.add("\n")

    def characters(self, content):
        if self.in_text:
            self.add(content)

expected = ["[Content_Types].xml", "_rels/.rels", "word/document.xml"]
with zipfile.ZipFile(sys.argv[1], "r") as package:
    bad = package.testzip()
    entries = package.namelist()
    methods = [item.compress_type for item in package.infolist()]
    content_types = ET.fromstring(package.read("[Content_Types].xml"))
    relationships = ET.fromstring(package.read("_rels/.rels"))
    handler = DocumentHandler()
    parser = xml.sax.make_parser()
    parser.setFeature(xml.sax.handler.feature_namespaces, True)
    parser.setContentHandler(handler)
    with package.open("word/document.xml", "r") as document:
        parser.parse(document)

if bad is not None:
    raise RuntimeError("DOCX package CRC failed for " + bad)
if entries != expected:
    raise RuntimeError("DOCX package entries differ: " + repr(entries))
if methods != [8, 8, 8]:
    raise RuntimeError("DOCX does not use DEFLATE for every entry: " + repr(methods))

content_ns = "http://schemas.openxmlformats.org/package/2006/content-types"
relationship_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
main_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
main_overrides = [
    item for item in content_types.findall("{%s}Override" % content_ns)
    if item.attrib.get("PartName") == "/word/document.xml"
    and item.attrib.get("ContentType") == main_type
]
office_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
office_relationships = [
    item for item in relationships.findall("{%s}Relationship" % relationship_ns)
    if item.attrib.get("Type") == office_type
    and item.attrib.get("Target") == "word/document.xml"
]
if len(main_overrides) != 1:
    raise RuntimeError("DOCX content types do not declare the main document")
if len(office_relationships) != 1:
    raise RuntimeError("DOCX root relationships do not target the main document")

print(json.dumps({
    "bytes": handler.bytes,
    "sha256": handler.hash.hexdigest(),
    "entries": entries,
    "methods": methods,
}))
`;
  const { stdout } = await execFileAsync("python", ["-c", python, filePath], {
    cwd: projectRoot,
    windowsHide: true,
    maxBuffer: 1024 * 1024,
  });
  const result = JSON.parse(stdout);
  if (
    !Number.isSafeInteger(result.bytes) ||
    result.bytes < 0 ||
    !/^[0-9a-f]{64}$/.test(result.sha256) ||
    !Array.isArray(result.entries) ||
    !Array.isArray(result.methods)
  ) {
    throw new Error(
      "The independent DOCX validator returned invalid evidence.",
    );
  }
  return result;
}

async function validateOdtOutput(filePath) {
  const python = String.raw`
import hashlib, json, struct, sys, xml.sax, zipfile
from xml.etree import ElementTree as ET

MIME = "application/vnd.oasis.opendocument.text"
OFFICE = "urn:oasis:names:tc:opendocument:xmlns:office:1.0"
TEXT = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"
MANIFEST = "urn:oasis:names:tc:opendocument:xmlns:manifest:1.0"

class ContentHandler(xml.sax.ContentHandler):
    def __init__(self):
        super().__init__()
        self.hash = hashlib.sha256()
        self.bytes = 0
        self.in_paragraph = False
        self.root_seen = False

    def add(self, value):
        encoded = value.encode("utf-8")
        self.hash.update(encoded)
        self.bytes += len(encoded)

    def startElementNS(self, name, qname, attrs):
        if not self.root_seen:
            if name != (OFFICE, "document-content"):
                raise RuntimeError("ODT content has an invalid root")
            self.root_seen = True
        if name == (TEXT, "p"):
            if self.in_paragraph:
                raise RuntimeError("ODT contains nested text paragraphs")
            self.in_paragraph = True
        elif self.in_paragraph and name == (TEXT, "s"):
            count = int(attrs.get((TEXT, "c"), "1"))
            if count < 1 or count > 1048576:
                raise RuntimeError("ODT explicit-space count is invalid")
            self.add(" " * count)
        elif self.in_paragraph and name == (TEXT, "tab"):
            self.add("\t")

    def endElementNS(self, name, qname):
        if name == (TEXT, "p"):
            if not self.in_paragraph:
                raise RuntimeError("ODT paragraph state is invalid")
            self.add("\n")
            self.in_paragraph = False

    def characters(self, content):
        if self.in_paragraph:
            self.add(content)

expected = ["mimetype", "META-INF/manifest.xml", "content.xml"]
with zipfile.ZipFile(sys.argv[1], "r") as package:
    bad = package.testzip()
    infos = package.infolist()
    entries = package.namelist()
    methods = [item.compress_type for item in infos]
    extras = [len(item.extra) for item in infos]
    mimetype = package.read("mimetype").decode("ascii")
    manifest = ET.fromstring(package.read("META-INF/manifest.xml"))
    handler = ContentHandler()
    parser = xml.sax.make_parser()
    parser.setFeature(xml.sax.handler.feature_namespaces, True)
    parser.setContentHandler(handler)
    with package.open("content.xml", "r") as content:
        parser.parse(content)

with open(sys.argv[1], "rb") as source:
    local = source.read(128)
signature = struct.unpack_from("<I", local, 0)[0]
flags = struct.unpack_from("<H", local, 6)[0]
method = struct.unpack_from("<H", local, 8)[0]
name_length = struct.unpack_from("<H", local, 26)[0]
extra_length = struct.unpack_from("<H", local, 28)[0]
local_name = local[30:30 + name_length].decode("utf-8")
payload_offset = 30 + name_length + extra_length
first_payload = local[payload_offset:payload_offset + len(MIME)].decode("ascii")

manifest_entries = {
    item.attrib.get("{%s}full-path" % MANIFEST):
        item.attrib.get("{%s}media-type" % MANIFEST)
    for item in manifest.findall("{%s}file-entry" % MANIFEST)
}
if bad is not None:
    raise RuntimeError("ODT package CRC failed for " + bad)
if entries != expected:
    raise RuntimeError("ODT package entries differ: " + repr(entries))
if methods != [0, 8, 8]:
    raise RuntimeError("ODT ZIP methods differ: " + repr(methods))
if extras != [0, 0, 0]:
    raise RuntimeError("ODT ZIP entries contain extra fields")
if infos[0].header_offset != 0 or signature != 0x04034B50:
    raise RuntimeError("ODT mimetype is not the first local entry")
if flags & 0x08 or method != 0 or local_name != "mimetype" or extra_length != 0:
    raise RuntimeError("ODT mimetype local header is not stored canonically")
if mimetype != MIME or first_payload != MIME:
    raise RuntimeError("ODT mimetype payload is invalid")
if manifest.tag != "{%s}manifest" % MANIFEST:
    raise RuntimeError("ODT manifest root is invalid")
if manifest_entries != {"/": MIME, "content.xml": "text/xml"}:
    raise RuntimeError("ODT manifest entries are invalid")
if not handler.root_seen or handler.in_paragraph:
    raise RuntimeError("ODT content XML is incomplete")

print(json.dumps({
    "bytes": handler.bytes,
    "sha256": handler.hash.hexdigest(),
    "entries": entries,
    "methods": methods,
}))
`;
  const { stdout } = await execFileAsync("python", ["-c", python, filePath], {
    cwd: projectRoot,
    windowsHide: true,
    maxBuffer: 1024 * 1024,
  });
  const result = JSON.parse(stdout);
  if (
    !Number.isSafeInteger(result.bytes) ||
    result.bytes < 0 ||
    !/^[0-9a-f]{64}$/.test(result.sha256) ||
    !Array.isArray(result.entries) ||
    !Array.isArray(result.methods)
  ) {
    throw new Error("The independent ODT validator returned invalid evidence.");
  }
  return result;
}

async function validateEpubOutput(filePath, contentMode) {
  if (contentMode !== "text" && contentMode !== "markdown") {
    throw new Error(`Unsupported EPUB validation mode: ${contentMode}`);
  }
  const python = String.raw`
import hashlib, json, re, struct, sys, xml.sax, zipfile
from xml.etree import ElementTree as ET

MIME = "application/epub+zip"
CONTAINER = "urn:oasis:names:tc:opendocument:xmlns:container"
OPF = "http://www.idpf.org/2007/opf"
DC = "http://purl.org/dc/elements/1.1/"
XHTML = "http://www.w3.org/1999/xhtml"
EPUB = "http://www.idpf.org/2007/ops"
MODE = sys.argv[2]
TITLE = "Converted Markdown" if MODE == "markdown" else "Converted text"
MARKDOWN_TAGS = {
    "html", "head", "meta", "title", "body", "h1", "h2", "h3", "h4",
    "h5", "h6", "p", "ul", "ol", "li", "blockquote", "pre", "code",
    "a", "strong", "em", "hr",
}
TEXT_TAGS = {"html", "head", "meta", "title", "body", "pre"}

class ContentHandler(xml.sax.ContentHandler):
    def __init__(self):
        super().__init__()
        self.hash = hashlib.sha256()
        self.bytes = 0
        self.in_pre = False
        self.pre_count = 0
        self.root_seen = False
        self.in_body = False
        self.body_count = 0
        self.semantic_count = 0

    def startElementNS(self, name, qname, attrs):
        if not self.root_seen:
            if name != (XHTML, "html"):
                raise RuntimeError("EPUB content has an invalid XHTML root")
            self.root_seen = True
        if name[0] != XHTML:
            raise RuntimeError("EPUB content contains a non-XHTML element")
        allowed = MARKDOWN_TAGS if MODE == "markdown" else TEXT_TAGS
        if name[1] not in allowed:
            raise RuntimeError("EPUB content contains an unsupported element: " + name[1])
        if name == (XHTML, "body"):
            if self.in_body or self.body_count:
                raise RuntimeError("EPUB content has multiple or nested body elements")
            self.in_body = True
            self.body_count += 1
        elif self.in_body and name[1] in {
            "h1", "h2", "h3", "h4", "h5", "h6", "p", "ul", "ol", "li",
            "blockquote", "pre", "code", "a", "strong", "em", "hr",
        }:
            self.semantic_count += 1
        if name == (XHTML, "pre"):
            if MODE == "text" and (self.in_pre or self.pre_count):
                raise RuntimeError("EPUB content has multiple or nested pre blocks")
            if MODE == "text":
                self.in_pre = True
            self.pre_count += 1

    def endElementNS(self, name, qname):
        if name == (XHTML, "pre") and MODE == "text":
            if not self.in_pre:
                raise RuntimeError("EPUB content pre state is invalid")
            self.in_pre = False
        if name == (XHTML, "body"):
            if not self.in_body:
                raise RuntimeError("EPUB content body state is invalid")
            self.in_body = False

    def characters(self, content):
        if MODE == "text" and self.in_pre:
            encoded = content.encode("utf-8")
            self.hash.update(encoded)
            self.bytes += len(encoded)

expected = [
    "mimetype", "META-INF/container.xml", "EPUB/nav.xhtml",
    "EPUB/content.xhtml", "EPUB/package.opf",
]
with zipfile.ZipFile(sys.argv[1], "r") as package:
    bad = package.testzip()
    infos = package.infolist()
    entries = package.namelist()
    methods = [item.compress_type for item in infos]
    extras = [len(item.extra) for item in infos]
    mimetype = package.read("mimetype").decode("ascii")
    container = ET.fromstring(package.read("META-INF/container.xml"))
    package_document = ET.fromstring(package.read("EPUB/package.opf"))
    navigation = ET.fromstring(package.read("EPUB/nav.xhtml"))
    handler = ContentHandler()
    parser = xml.sax.make_parser()
    parser.setFeature(xml.sax.handler.feature_namespaces, True)
    parser.setContentHandler(handler)
    if MODE == "markdown":
        content_hash = hashlib.sha256()
        content_bytes = 0
        with package.open("EPUB/content.xhtml", "r") as content:
            while True:
                chunk = content.read(262144)
                if not chunk:
                    break
                content_hash.update(chunk)
                content_bytes += len(chunk)
        with package.open("EPUB/content.xhtml", "r") as content:
            parser.parse(content)
    else:
        with package.open("EPUB/content.xhtml", "r") as content:
            parser.parse(content)
        content_hash = handler.hash
        content_bytes = handler.bytes

with open(sys.argv[1], "rb") as source:
    local = source.read(128)
signature = struct.unpack_from("<I", local, 0)[0]
flags = struct.unpack_from("<H", local, 6)[0]
method = struct.unpack_from("<H", local, 8)[0]
name_length = struct.unpack_from("<H", local, 26)[0]
extra_length = struct.unpack_from("<H", local, 28)[0]
local_name = local[30:30 + name_length].decode("utf-8")
payload_offset = 30 + name_length + extra_length
first_payload = local[payload_offset:payload_offset + len(MIME)].decode("ascii")

rootfile = container.find("{%s}rootfiles/{%s}rootfile" % (CONTAINER, CONTAINER))
metadata = package_document.find("{%s}metadata" % OPF)
manifest = package_document.find("{%s}manifest" % OPF)
spine = package_document.find("{%s}spine" % OPF)
if rootfile is None or metadata is None or manifest is None or spine is None:
    raise RuntimeError("EPUB container or package structure is incomplete")
identifier = metadata.find("{%s}identifier" % DC)
title = metadata.find("{%s}title" % DC)
language = metadata.find("{%s}language" % DC)
modified = [item for item in metadata.findall("{%s}meta" % OPF)
            if item.attrib.get("property") == "dcterms:modified"]
manifest_items = {
    item.attrib.get("id"): (item.attrib.get("href"), item.attrib.get("media-type"),
                            item.attrib.get("properties"))
    for item in manifest.findall("{%s}item" % OPF)
}
spine_items = [item.attrib.get("idref") for item in spine.findall("{%s}itemref" % OPF)]
toc = [item for item in navigation.findall(".//{%s}nav" % XHTML)
       if item.attrib.get("{%s}type" % EPUB) == "toc"]
toc_link = toc[0].find("{%s}ol/{%s}li/{%s}a" % (XHTML, XHTML, XHTML)) if len(toc) == 1 else None

if bad is not None:
    raise RuntimeError("EPUB package CRC failed for " + bad)
if entries != expected or methods != [0, 8, 8, 8, 8]:
    raise RuntimeError("EPUB package entries or ZIP methods differ")
if extras != [0, 0, 0, 0, 0]:
    raise RuntimeError("EPUB ZIP entries contain extra fields")
if infos[0].header_offset != 0 or signature != 0x04034B50:
    raise RuntimeError("EPUB mimetype is not the first local entry")
if flags & 0x08 or method != 0 or local_name != "mimetype" or extra_length != 0:
    raise RuntimeError("EPUB mimetype local header is not stored canonically")
if mimetype != MIME or first_payload != MIME:
    raise RuntimeError("EPUB mimetype payload is invalid")
if container.tag != "{%s}container" % CONTAINER or container.attrib.get("version") != "1.0":
    raise RuntimeError("EPUB container root is invalid")
if rootfile.attrib != {"full-path": "EPUB/package.opf", "media-type": "application/oebps-package+xml"}:
    raise RuntimeError("EPUB rootfile declaration is invalid")
if package_document.tag != "{%s}package" % OPF or package_document.attrib.get("version") != "3.0":
    raise RuntimeError("EPUB package document root is invalid")
if package_document.attrib.get("unique-identifier") != "pub-id":
    raise RuntimeError("EPUB unique identifier reference is invalid")
if (identifier is None or identifier.attrib.get("id") != "pub-id" or
        not re.fullmatch(r"urn:uuid:[0-9a-f]{8}-[0-9a-f]{4}-8[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", identifier.text or "")):
    raise RuntimeError("EPUB identifier is invalid")
if title is None or title.text != TITLE or language is None or language.text != "und":
    raise RuntimeError("EPUB required title or language metadata is invalid")
if len(modified) != 1 or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", modified[0].text or ""):
    raise RuntimeError("EPUB modified metadata is invalid")
if manifest_items != {
    "nav": ("nav.xhtml", "application/xhtml+xml", "nav"),
    "content": ("content.xhtml", "application/xhtml+xml", None),
} or spine_items != ["content"]:
    raise RuntimeError("EPUB manifest or spine is invalid")
if (navigation.tag != "{%s}html" % XHTML or len(toc) != 1 or toc_link is None or
        toc_link.attrib.get("href") != "content.xhtml" or toc_link.text != TITLE):
    raise RuntimeError("EPUB navigation document is invalid")
if not handler.root_seen or handler.body_count != 1 or handler.in_body:
    raise RuntimeError("EPUB content XHTML is incomplete")
if MODE == "text" and (handler.pre_count != 1 or handler.in_pre):
    raise RuntimeError("EPUB text content is incomplete")
if MODE == "markdown" and handler.semantic_count == 0:
    raise RuntimeError("EPUB Markdown content contains no semantic structure")

print(json.dumps({"bytes": content_bytes, "sha256": content_hash.hexdigest(),
                  "entries": entries, "methods": methods}))
`;
  const { stdout } = await execFileAsync(
    "python",
    ["-c", python, filePath, contentMode],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 1024 * 1024 },
  );
  const result = JSON.parse(stdout);
  if (
    !Number.isSafeInteger(result.bytes) ||
    result.bytes < 0 ||
    !/^[0-9a-f]{64}$/.test(result.sha256) ||
    !Array.isArray(result.entries) ||
    !Array.isArray(result.methods)
  ) {
    throw new Error(
      "The independent EPUB validator returned invalid evidence.",
    );
  }
  return result;
}

async function validateBzip2Output(filePath) {
  const python = String.raw`
import bz2, hashlib, json, sys
h = hashlib.sha256()
n = 0
with bz2.open(sys.argv[1], "rb") as source:
    while True:
        chunk = source.read(262144)
        if not chunk:
            break
        h.update(chunk)
        n += len(chunk)
print(json.dumps({"bytes": n, "sha256": h.hexdigest()}))
`;
  const { stdout } = await execFileAsync("python", ["-c", python, filePath], {
    cwd: projectRoot,
    windowsHide: true,
    maxBuffer: 1024 * 1024,
  });
  const result = JSON.parse(stdout);
  if (
    !Number.isSafeInteger(result.bytes) ||
    result.bytes < 0 ||
    !/^[0-9a-f]{64}$/.test(result.sha256)
  ) {
    throw new Error(
      "The independent BZIP2 validator returned invalid evidence.",
    );
  }
  return result;
}

async function validateGzipOutput(filePath) {
  const python = String.raw`
import gzip, hashlib, json, sys
h = hashlib.sha256()
n = 0
with gzip.open(sys.argv[1], "rb") as source:
    while True:
        chunk = source.read(262144)
        if not chunk:
            break
        h.update(chunk)
        n += len(chunk)
print(json.dumps({"bytes": n, "sha256": h.hexdigest()}))
`;
  const { stdout } = await execFileAsync("python", ["-c", python, filePath], {
    cwd: projectRoot,
    windowsHide: true,
    maxBuffer: 1024 * 1024,
  });
  const result = JSON.parse(stdout);
  if (
    !Number.isSafeInteger(result.bytes) ||
    result.bytes < 0 ||
    !/^[0-9a-f]{64}$/.test(result.sha256)
  ) {
    throw new Error(
      "The independent GZIP validator returned invalid evidence.",
    );
  }
  return result;
}

async function validateXzOutput(filePath) {
  const python = String.raw`
import hashlib, json, lzma, sys
h = hashlib.sha256()
n = 0
with lzma.open(sys.argv[1], "rb") as source:
    while True:
        chunk = source.read(262144)
        if not chunk:
            break
        h.update(chunk)
        n += len(chunk)
print(json.dumps({"bytes": n, "sha256": h.hexdigest()}))
`;
  const { stdout } = await execFileAsync("python", ["-c", python, filePath], {
    cwd: projectRoot,
    windowsHide: true,
    maxBuffer: 1024 * 1024,
  });
  const result = JSON.parse(stdout);
  if (
    !Number.isSafeInteger(result.bytes) ||
    result.bytes < 0 ||
    !/^[0-9a-f]{64}$/.test(result.sha256)
  ) {
    throw new Error("The independent XZ validator returned invalid evidence.");
  }
  return result;
}

async function validateArchiveOutput(localPath, source, route) {
  if (!Array.isArray(source.entries) || source.entries.length === 0) {
    throw new Error(
      "Archive fixture manifest has no independently verifiable entries.",
    );
  }
  const { stdout } = await execFileAsync("tar", ["-tf", localPath], {
    cwd: projectRoot,
    windowsHide: true,
    maxBuffer: 16 * 1024 * 1024,
  });
  const listedEntries = stdout.split(/\r?\n/).filter((name) => name.length > 0);
  const expectedNames = source.entries.map((entry) => entry.name);
  if (
    listedEntries.length !== expectedNames.length ||
    listedEntries.some((name, index) => name !== expectedNames[index])
  ) {
    throw new Error(
      `Archive entry listing differs from the fixture manifest: ${listedEntries.length} entries.`,
    );
  }

  const verifiedEntries = [];
  for (const entry of source.entries) {
    const result = await hashArchiveEntry(localPath, entry.name);
    if (result.bytes !== entry.size || result.sha256 !== entry.sha256) {
      throw new Error(
        `Archive entry validation failed for ${entry.name}: ${result.bytes} bytes.`,
      );
    }
    verifiedEntries.push({
      name: entry.name,
      bytes: result.bytes,
      sha256: result.sha256,
    });
  }
  return {
    method: "libarchive-entry-sha256",
    route,
    passed: true,
    entryCount: verifiedEntries.length,
    entries: verifiedEntries,
  };
}

async function hashArchiveEntry(localPath, entryName) {
  return new Promise((resolve, reject) => {
    const child = spawn("tar", ["-xOf", localPath, "--", entryName], {
      cwd: projectRoot,
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    const hash = createHash("sha256");
    let bytes = 0;
    let stderr = "";
    child.stdout.on("data", (chunk) => {
      hash.update(chunk);
      bytes += chunk.byteLength;
    });
    child.stderr.on("data", (chunk) => {
      if (stderr.length < 1024 * 1024) stderr += chunk.toString("utf8");
    });
    child.once("error", reject);
    child.once("close", (code) => {
      if (code !== 0) {
        reject(
          new Error(
            `libarchive could not extract ${entryName}: ${stderr.trim() || `exit ${code}`}`,
          ),
        );
        return;
      }
      resolve({ bytes, sha256: hash.digest("hex") });
    });
  });
}

async function validateImageOutput(
  localPath,
  sourcePath,
  source,
  finalState,
  route,
) {
  if (
    finalState.metrics.outputBytes < 1 ||
    finalState.metrics.outputBytes >
      (route.endsWith("-to-jxl") || route.endsWith("-to-avif") ? 128 : 64) *
        1024 *
        1024
  ) {
    throw new Error(
      `Browser image output is outside the bounded range: ${finalState.metrics.outputBytes} bytes.`,
    );
  }
  const outputFormat = route.split("-to-")[1];
  const expectedCodec =
    outputFormat === "jpeg"
      ? "mjpeg"
      : outputFormat === "ico"
        ? "png"
        : outputFormat === "jxl"
          ? "jpegxl"
          : outputFormat === "avif"
            ? "av1"
            : outputFormat;
  const { stdout } = await execFileAsync(
    "ffprobe",
    ["-v", "error", "-show_streams", "-show_format", "-of", "json", localPath],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
  );
  const probe = JSON.parse(stdout);
  const stream = probe.streams?.[0];
  const sourceStream = source.probe?.streams?.[0];
  const sourceWidth = Number(sourceStream?.width);
  const sourceHeight = Number(sourceStream?.height);
  const iconScale =
    outputFormat === "ico"
      ? Math.min(1, 256 / sourceWidth, 256 / sourceHeight)
      : 1;
  const expectedWidth = Math.max(1, Math.round(sourceWidth * iconScale));
  const expectedHeight = Math.max(1, Math.round(sourceHeight * iconScale));
  if (
    (outputFormat === "avif"
      ? ![1, 2, 4].includes(probe.streams?.length)
      : probe.streams?.length !== 1) ||
    stream?.codec_name !== expectedCodec ||
    stream?.width !== expectedWidth ||
    stream?.height !== expectedHeight
  ) {
    throw new Error(
      `Browser image validation failed: ${stream?.codec_name ?? "missing"} ${stream?.width ?? 0}x${stream?.height ?? 0}.`,
    );
  }
  await execFileAsync(
    "ffmpeg",
    ["-v", "error", "-i", localPath, "-f", "null", "NUL"],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
  );
  const comparisonFilter =
    outputFormat === "ico"
      ? `[0:v:0]trim=end_frame=1,setpts=PTS-STARTPTS,scale=${expectedWidth}:${expectedHeight}:flags=lanczos,format=rgb24[source];[1:v:0]trim=end_frame=1,setpts=PTS-STARTPTS,format=rgb24[converted];[source][converted]ssim[quality]`
      : "[0:v:0]trim=end_frame=1,setpts=PTS-STARTPTS,format=rgb24[source];[1:v:0]trim=end_frame=1,setpts=PTS-STARTPTS,format=rgb24[converted];[source][converted]ssim[quality]";
  const comparisonSourcePath = source.validationReference
    ? path.resolve(projectRoot, source.validationReference)
    : sourcePath;
  const comparisonRelative = path.relative(projectRoot, comparisonSourcePath);
  if (
    !comparisonRelative ||
    comparisonRelative.startsWith("..") ||
    path.isAbsolute(comparisonRelative)
  ) {
    throw new Error(
      "Image validation references must stay inside the project.",
    );
  }
  const { stderr: similarityLog } = await execFileAsync(
    "ffmpeg",
    [
      "-hide_banner",
      "-nostdin",
      "-i",
      comparisonSourcePath,
      "-i",
      localPath,
      "-filter_complex",
      comparisonFilter,
      "-map",
      "[quality]",
      "-frames:v",
      "1",
      "-f",
      "null",
      "NUL",
    ],
    {
      cwd: projectRoot,
      windowsHide: true,
      maxBuffer: 16 * 1024 * 1024,
    },
  );
  const similarity = Number.parseFloat(
    similarityLog.match(/SSIM[^\r\n]*All:([0-9.]+)/)?.[1] ?? "",
  );
  if (!Number.isFinite(similarity) || similarity < 0.3) {
    throw new Error(
      `Browser image visual validation failed: SSIM ${Number.isFinite(similarity) ? similarity : "unavailable"}.`,
    );
  }
  if (
    outputFormat !== "jxl" &&
    outputFormat !== "avif" &&
    Number(sourceStream?.nb_frames ?? 1) > 1 &&
    !finalState.warnings.some((warning) =>
      warning.includes("first animation frame"),
    )
  ) {
    throw new Error(
      "The browser did not disclose that only the first animation frame was converted.",
    );
  }
  probe.withinValidation = {
    firstFrameVisualSsim: similarity,
    minimumVisualSsim: 0.3,
    decodedByNativeFfmpeg: true,
  };
  return probe;
}

async function validateAnimatedJxlOutput(
  localPath,
  sourcePath,
  source,
  finalState,
  route,
) {
  if (
    finalState.metrics.outputBytes < 1 ||
    finalState.metrics.outputBytes > 128 * 1024 * 1024
  ) {
    throw new Error(
      `Browser JPEG XL output is outside the bounded range: ${finalState.metrics.outputBytes} bytes.`,
    );
  }
  const { stdout: sourceMetadataJson } = await execFileAsync(
    "python",
    ["scripts/decode-pillow-animation-frame.py", sourcePath, "--metadata"],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 1024 * 1024 },
  );
  const sourceAnimation = JSON.parse(sourceMetadataJson);
  const expectedFrames = Number(sourceAnimation.frameCount);
  const width = Number(sourceAnimation.width);
  const height = Number(sourceAnimation.height);
  if (
    !Number.isSafeInteger(expectedFrames) ||
    expectedFrames < 2 ||
    expectedFrames > 1_000 ||
    !Number.isSafeInteger(width) ||
    !Number.isSafeInteger(height) ||
    width < 1 ||
    height < 1 ||
    !Array.isArray(sourceAnimation.durationsMs) ||
    sourceAnimation.durationsMs.length !== expectedFrames
  ) {
    throw new Error(
      "The animation source metadata is incomplete or outside the bounded limits.",
    );
  }
  let expectedDurationsMs = sourceAnimation.durationsMs.map(Number);
  if (
    expectedDurationsMs.some(
      (duration) => !Number.isFinite(duration) || duration <= 0,
    )
  ) {
    const { stdout: sourceProbeJson } = await execFileAsync(
      "ffprobe",
      [
        "-v",
        "error",
        "-show_entries",
        "frame=stream_index,duration_time",
        "-show_entries",
        "stream=index,nb_frames",
        "-of",
        "json",
        sourcePath,
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
    );
    const sourceProbe = JSON.parse(sourceProbeJson);
    const animationStream = [...(sourceProbe.streams ?? [])].sort(
      (left, right) =>
        Number(right.nb_frames ?? 0) - Number(left.nb_frames ?? 0),
    )[0];
    expectedDurationsMs = (sourceProbe.frames ?? [])
      .filter((frame) => frame.stream_index === animationStream?.index)
      .map((frame) => Number(frame.duration_time) * 1_000);
  }
  if (
    expectedDurationsMs.length !== expectedFrames ||
    expectedDurationsMs.some(
      (duration) => !Number.isFinite(duration) || duration <= 0,
    )
  ) {
    throw new Error(
      "Independent source timing inspection did not return every animation frame.",
    );
  }

  const [{ stdout: probeJson }, { stdout: decoderJson }] = await Promise.all([
    execFileAsync(
      "ffprobe",
      [
        "-v",
        "error",
        "-count_frames",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=codec_name,width,height,pix_fmt,time_base,nb_read_frames",
        "-show_entries",
        "frame=pts_time,duration_time",
        "-of",
        "json",
        localPath,
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
    ),
    execFileAsync(
      process.execPath,
      [
        "scripts/inspect-jxl-animation.mjs",
        path.relative(projectRoot, localPath),
      ],
      { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
    ),
  ]);
  const probe = JSON.parse(probeJson);
  const decoder = JSON.parse(decoderJson);
  const stream = probe.streams?.[0];
  if (
    stream?.codec_name !== "jpegxl_anim" ||
    stream.width !== width ||
    stream.height !== height ||
    stream.time_base !== "1/1000000" ||
    Number(stream.nb_read_frames) !== expectedFrames ||
    probe.frames?.length !== expectedFrames ||
    decoder.hasAnimation !== true ||
    decoder.frameCount !== expectedFrames ||
    decoder.width !== width ||
    decoder.height !== height ||
    decoder.frames?.length !== expectedFrames
  ) {
    throw new Error(
      "Independent decoders did not identify the complete animated JPEG XL output.",
    );
  }
  const expectedNumLoops =
    Number(sourceAnimation.loop) === 0 ? 0 : Number(sourceAnimation.loop) + 1;
  let expectedTimestampMs = 0;
  for (let index = 0; index < expectedFrames; index += 1) {
    const frame = probe.frames[index];
    const decodedFrame = decoder.frames[index];
    const durationMs = expectedDurationsMs[index];
    if (
      Math.abs(Number(frame.pts_time) * 1_000 - expectedTimestampMs) > 0.001 ||
      Math.abs(Number(frame.duration_time) * 1_000 - durationMs) > 0.001 ||
      decodedFrame.ticksPerSecondNumerator !== 1_000_000 ||
      decodedFrame.ticksPerSecondDenominator !== 1 ||
      decodedFrame.durationTicks !== Math.round(durationMs * 1_000) ||
      decodedFrame.numLoops !== expectedNumLoops ||
      decodedFrame.isLast !== (index === expectedFrames - 1)
    ) {
      throw new Error(
        `Animated JPEG XL timing or loop validation failed at frame ${index + 1}.`,
      );
    }
    expectedTimestampMs += durationMs;
  }

  const outputFrame = async (frameIndex) =>
    (
      await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-i",
          localPath,
          "-vf",
          `select=eq(n\\,${frameIndex})`,
          "-fps_mode",
          "vfr",
          "-frames:v",
          "1",
          "-pix_fmt",
          "rgba",
          "-f",
          "rawvideo",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 40 * 1024 * 1024,
          encoding: "buffer",
        },
      )
    ).stdout;
  const sourceFrame = async (frameIndex) =>
    (
      await execFileAsync(
        "python",
        [
          "scripts/decode-pillow-animation-frame.py",
          sourcePath,
          String(frameIndex),
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 40 * 1024 * 1024,
          encoding: "buffer",
        },
      )
    ).stdout;
  const allFrameSha256 = [];
  const frameSimilarity = [];
  const exactSource = /^(?:png|gif)-to-jxl$/.test(route);
  const minimumSimilarity = 0.9;
  for (let index = 0; index < expectedFrames; index += 1) {
    const [output, reference] = await Promise.all([
      outputFrame(index),
      sourceFrame(index),
    ]);
    if (
      output.byteLength !== width * height * 4 ||
      reference.byteLength !== output.byteLength
    ) {
      throw new Error(
        `Animated JPEG XL frame ${index + 1} has an invalid decoded size.`,
      );
    }
    const outputHash = createHash("sha256").update(output).digest("hex");
    const referenceHash = createHash("sha256").update(reference).digest("hex");
    const similarity = rgbaGlobalSsim(reference, output);
    if (
      (exactSource && outputHash !== referenceHash) ||
      (!exactSource &&
        (!Number.isFinite(similarity) || similarity < minimumSimilarity))
    ) {
      throw new Error(
        `Animated JPEG XL frame ${index + 1} differs from the independently decoded source at SSIM ${similarity}.`,
      );
    }
    allFrameSha256.push(outputHash);
    frameSimilarity.push(similarity);
  }
  return {
    format: {
      format_name: "jpegxl_pipe",
      size: String(finalState.metrics.outputBytes),
    },
    streams: probe.streams,
    withinValidation: {
      method: "ffprobe-all-frame-rgba-plus-bounded-libjxl-metadata-inspection",
      frameCount: expectedFrames,
      loopCount: expectedNumLoops === 0 ? "infinite" : expectedNumLoops,
      ticksPerSecond: { numerator: 1_000_000, denominator: 1 },
      timingExact: true,
      allFrameSha256,
      exactSourceFrameMatch: exactSource,
      minimumFrameSsim: Math.min(...frameSimilarity),
      minimumRequiredFrameSsim: exactSource ? 1 : minimumSimilarity,
      decoderPeakAllocationBytes: decoder.peakDecoderAllocationBytes,
      maximumDecoderPngChunkBytes: decoder.maximumPngChunkBytes,
      decodedByNativeFfmpeg: true,
      sourceDecodedByPinnedPillow: true,
    },
  };
}

function rgbaGlobalSsim(left, right) {
  if (left.byteLength !== right.byteLength || left.byteLength % 4 !== 0)
    return NaN;
  const count = left.byteLength / 4;
  const sums = Array.from({ length: 3 }, () => ({
    left: 0,
    right: 0,
    leftSquared: 0,
    rightSquared: 0,
    product: 0,
  }));
  for (let offset = 0; offset < left.byteLength; offset += 4) {
    for (let channel = 0; channel < 3; channel += 1) {
      const leftValue = left[offset + channel];
      const rightValue = right[offset + channel];
      const sum = sums[channel];
      sum.left += leftValue;
      sum.right += rightValue;
      sum.leftSquared += leftValue * leftValue;
      sum.rightSquared += rightValue * rightValue;
      sum.product += leftValue * rightValue;
    }
  }
  const c1 = (0.01 * 255) ** 2;
  const c2 = (0.03 * 255) ** 2;
  return (
    sums.reduce((total, sum) => {
      const leftMean = sum.left / count;
      const rightMean = sum.right / count;
      const leftVariance = sum.leftSquared / count - leftMean ** 2;
      const rightVariance = sum.rightSquared / count - rightMean ** 2;
      const covariance = sum.product / count - leftMean * rightMean;
      return (
        total +
        ((2 * leftMean * rightMean + c1) * (2 * covariance + c2)) /
          ((leftMean ** 2 + rightMean ** 2 + c1) *
            (leftVariance + rightVariance + c2))
      );
    }, 0) / 3
  );
}

async function validateAnimatedFrameArchiveOutput(
  localPath,
  sourcePath,
  source,
  finalState,
  route,
) {
  if (
    finalState.metrics.outputBytes < 1 ||
    finalState.metrics.outputBytes > 4_294_967_295
  ) {
    throw new Error(
      `Browser animation ZIP is outside the ZIP32 range: ${finalState.metrics.outputBytes} bytes.`,
    );
  }
  const expectedFrames = Number(
    source.frameCount ??
      source.probe?.streams?.[0]?.nb_frames ??
      source.probe?.streams?.[0]?.nb_read_frames,
  );
  if (!Number.isSafeInteger(expectedFrames) || expectedFrames < 1) {
    throw new Error(
      "The animation stress manifest does not declare a frame count.",
    );
  }
  const extractionRoot = path.join(
    workRoot,
    `animation-validation-${process.pid}-${route}`,
  );
  assertInside(workRoot, extractionRoot);
  await removeWithRetries(extractionRoot);
  await mkdir(extractionRoot, { recursive: true });
  try {
    const { stdout: listing } = await execFileAsync("tar", ["-tf", localPath], {
      cwd: projectRoot,
      windowsHide: true,
      maxBuffer: 8 * 1024 * 1024,
    });
    const expectedNames = [
      ...Array.from(
        { length: expectedFrames },
        (_, index) => `frame-${String(index + 1).padStart(4, "0")}.png`,
      ),
      "animation.json",
    ];
    const listedNames = listing.trim().split(/\r?\n/);
    if (JSON.stringify(listedNames) !== JSON.stringify(expectedNames)) {
      throw new Error("Animation ZIP entries are incomplete or out of order.");
    }
    await execFileAsync("tar", ["-xf", localPath, "-C", extractionRoot], {
      cwd: projectRoot,
      windowsHide: true,
      maxBuffer: 8 * 1024 * 1024,
    });
    const manifest = JSON.parse(
      await readFile(path.join(extractionRoot, "animation.json"), "utf8"),
    );
    if (
      manifest.schema !== "within-animation-frames-v1" ||
      manifest.sourceFormat !== route.split("-to-")[0] ||
      manifest.frameCount !== expectedFrames ||
      !Array.isArray(manifest.frames) ||
      manifest.frames.length !== expectedFrames
    ) {
      throw new Error("Animation ZIP timing manifest is invalid.");
    }
    const width = Number(source.probe?.streams?.[0]?.width);
    const height = Number(source.probe?.streams?.[0]?.height);
    const frameHashes = [];
    for (let index = 0; index < expectedFrames; index += 1) {
      const name = expectedNames[index];
      const frame = manifest.frames[index];
      if (
        frame.file !== name ||
        frame.index !== index ||
        frame.width !== width ||
        frame.height !== height ||
        !Number.isFinite(frame.timestampMicros) ||
        !(frame.durationMicros > 0) ||
        (index > 0 &&
          frame.timestampMicros <= manifest.frames[index - 1].timestampMicros)
      ) {
        throw new Error(
          `Animation frame metadata is invalid at index ${index}.`,
        );
      }
      const framePath = path.join(extractionRoot, name);
      const { stdout } = await execFileAsync(
        "ffprobe",
        [
          "-v",
          "error",
          "-show_entries",
          "stream=codec_name,width,height",
          "-of",
          "json",
          framePath,
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
      );
      const stream = JSON.parse(stdout).streams?.[0];
      if (
        stream?.codec_name !== "png" ||
        stream.width !== width ||
        stream.height !== height
      ) {
        throw new Error(
          `Animation frame ${index + 1} is not the expected PNG image.`,
        );
      }
      frameHashes.push((await hashFile(framePath)).sha256);
    }
    if (expectedFrames > 1 && new Set(frameHashes).size < 2) {
      throw new Error("Animation ZIP contains only duplicate frame images.");
    }
    const referencePath = source.validationReference
      ? path.resolve(projectRoot, source.validationReference)
      : sourcePath;
    const referenceRelative = path.relative(projectRoot, referencePath);
    if (
      !referenceRelative ||
      referenceRelative.startsWith("..") ||
      path.isAbsolute(referenceRelative)
    ) {
      throw new Error(
        "Animation validation references must stay inside the project.",
      );
    }
    const rawFrame = async (imagePath, frameIndex = 0) =>
      (
        await execFileAsync(
          "ffmpeg",
          [
            "-v",
            "error",
            "-i",
            imagePath,
            "-vf",
            `select=eq(n\\,${frameIndex})`,
            "-fps_mode",
            "vfr",
            "-frames:v",
            "1",
            "-pix_fmt",
            "rgb24",
            "-f",
            "rawvideo",
            "-",
          ],
          {
            cwd: projectRoot,
            windowsHide: true,
            maxBuffer: 32 * 1024 * 1024,
            encoding: "buffer",
          },
        )
      ).stdout;
    const firstFramePath = path.join(extractionRoot, expectedNames[0]);
    const firstFrame = await rawFrame(firstFramePath);
    const referenceFrame = await rawFrame(referencePath);
    const firstFrameSha256 = createHash("sha256")
      .update(firstFrame)
      .digest("hex");
    const referenceFrameSha256 = createHash("sha256")
      .update(referenceFrame)
      .digest("hex");
    const measureSsim = async (expectedPath, actualPath) => {
      const { stderr } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "info",
          "-i",
          expectedPath,
          "-i",
          actualPath,
          "-lavfi",
          "[0:v:0]format=rgb24[reference];[1:v:0]format=rgb24[converted];[reference][converted]ssim",
          "-frames:v",
          "1",
          "-f",
          "null",
          "NUL",
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
      );
      return Number.parseFloat(
        stderr.match(/SSIM[^\r\n]*All:([0-9.]+)/)?.[1] ?? "",
      );
    };
    const firstFrameSsim =
      route === "avif-to-zip"
        ? await measureSsim(referencePath, firstFramePath)
        : firstFrameSha256 === referenceFrameSha256
          ? 1
          : 0;
    if (firstFrameSsim < 0.97) {
      throw new Error(
        "Animation ZIP first frame differs from the independent reference.",
      );
    }
    const allFrameSha256 = [];
    const allFrameSsim = [];
    if (route === "avif-to-zip") {
      for (let index = 0; index < expectedFrames; index += 1) {
        const nativeFramePath = path.join(
          extractionRoot,
          `native-avif-frame-${index + 1}.png`,
        );
        await execFileAsync(
          "ffmpeg",
          [
            "-v",
            "error",
            "-i",
            sourcePath,
            "-map",
            "0:v:1",
            "-vf",
            `select=eq(n\\,${index})`,
            "-fps_mode",
            "vfr",
            "-frames:v",
            "1",
            nativeFramePath,
          ],
          { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
        );
        const similarity = await measureSsim(
          nativeFramePath,
          path.join(extractionRoot, expectedNames[index]),
        );
        if (similarity < 0.97) {
          throw new Error(
            `AVIF frame ${index + 1} scored ${similarity} SSIM against independent native decoding.`,
          );
        }
        allFrameSsim.push(similarity);
      }
    }
    if (route === "jxl-to-zip") {
      for (let index = 0; index < expectedFrames; index += 1) {
        const archived = await rawFrame(
          path.join(extractionRoot, expectedNames[index]),
        );
        const nativeSource = await rawFrame(sourcePath, index);
        const archivedSha256 = createHash("sha256")
          .update(archived)
          .digest("hex");
        const nativeSourceSha256 = createHash("sha256")
          .update(nativeSource)
          .digest("hex");
        if (archivedSha256 !== nativeSourceSha256) {
          throw new Error(
            `JPEG XL frame ${index + 1} differs from independent native decoding.`,
          );
        }
        allFrameSha256.push(archivedSha256);
      }
    }
    return {
      format: {
        format_name: "zip",
        size: String(finalState.metrics.outputBytes),
      },
      withinValidation: {
        method: "native-tar-list-extract-plus-ffprobe-and-rgb-hash",
        frameCount: expectedFrames,
        uniqueFrameHashes: new Set(frameHashes).size,
        firstFrameSha256,
        firstFrameSsim,
        allFrameSha256: allFrameSha256.length > 0 ? allFrameSha256 : undefined,
        allFrameSsim: allFrameSsim.length > 0 ? allFrameSsim : undefined,
        timingManifest: true,
        decodedByNativeFfmpeg: true,
      },
    };
  } finally {
    await removeWithRetries(extractionRoot);
  }
}

async function validateAnimatedApngOutput(
  localPath,
  sourcePath,
  source,
  finalState,
) {
  const encoded = await readFile(localPath);
  const signature = Buffer.from([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
  ]);
  if (!encoded.subarray(0, 8).equals(signature)) {
    throw new Error("Browser APNG output has an invalid PNG signature.");
  }
  const chunks = [];
  let offset = 8;
  while (offset < encoded.byteLength) {
    if (offset + 12 > encoded.byteLength) {
      throw new Error("Browser APNG output ends inside a chunk header.");
    }
    const length = encoded.readUInt32BE(offset);
    const type = encoded.toString("ascii", offset + 4, offset + 8);
    const end = offset + 12 + length;
    if (end > encoded.byteLength) {
      throw new Error(
        `Browser APNG ${type} chunk exceeds the output boundary.`,
      );
    }
    chunks.push({
      type,
      data: encoded.subarray(offset + 8, offset + 8 + length),
    });
    offset = end;
  }
  if (
    chunks[0]?.type !== "IHDR" ||
    chunks[1]?.type !== "acTL" ||
    chunks.at(-1)?.type !== "IEND"
  ) {
    throw new Error("Browser APNG has an invalid IHDR/acTL/IEND layout.");
  }
  const { stdout: metadataJson } = await execFileAsync(
    "python",
    ["scripts/decode-pillow-animation-frame.py", sourcePath, "--metadata"],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 1024 * 1024 },
  );
  const sourceAnimation = JSON.parse(metadataJson);
  const expectedFrames = Number(sourceAnimation.frameCount);
  const width = Number(sourceAnimation.width);
  const height = Number(sourceAnimation.height);
  if (
    !Number.isSafeInteger(expectedFrames) ||
    expectedFrames < 1 ||
    expectedFrames !==
      Number(source.frameCount ?? source.probe?.streams?.[0]?.nb_frames) ||
    !Array.isArray(sourceAnimation.durationsMs) ||
    sourceAnimation.durationsMs.length !== expectedFrames
  ) {
    throw new Error(
      "The independent animation metadata does not match the stress manifest.",
    );
  }
  const animationControl = chunks[1].data;
  const expectedPlays =
    sourceAnimation.loop === 0 ? 0 : Number(sourceAnimation.loop) + 1;
  if (
    animationControl.byteLength !== 8 ||
    animationControl.readUInt32BE(0) !== expectedFrames ||
    animationControl.readUInt32BE(4) !== expectedPlays
  ) {
    throw new Error(
      "Browser APNG frame or loop control differs from the source animation.",
    );
  }
  const frameControls = chunks.filter((chunk) => chunk.type === "fcTL");
  if (frameControls.length !== expectedFrames) {
    throw new Error(
      "Browser APNG does not contain one frame-control chunk per frame.",
    );
  }
  for (let index = 0; index < frameControls.length; index += 1) {
    const control = frameControls[index].data;
    if (
      control.byteLength !== 26 ||
      control.readUInt32BE(4) !== width ||
      control.readUInt32BE(8) !== height ||
      control.readUInt32BE(12) !== 0 ||
      control.readUInt32BE(16) !== 0 ||
      control[24] !== 0 ||
      control[25] !== 0
    ) {
      throw new Error(`Browser APNG frame control ${index + 1} is invalid.`);
    }
    const numerator = control.readUInt16BE(20);
    const denominator = control.readUInt16BE(22) || 100;
    const encodedDurationMs = (numerator * 1_000) / denominator;
    if (
      Math.abs(encodedDurationMs - sourceAnimation.durationsMs[index]) > 0.001
    ) {
      throw new Error(
        `Browser APNG frame ${index + 1} timing differs from the source.`,
      );
    }
  }
  const sequenced = chunks.filter(
    (chunk) => chunk.type === "fcTL" || chunk.type === "fdAT",
  );
  for (let index = 0; index < sequenced.length; index += 1) {
    if (sequenced[index].data.readUInt32BE(0) !== index) {
      throw new Error("Browser APNG animation sequence numbers contain a gap.");
    }
  }
  const maximumFrameChunk = Math.max(
    ...chunks
      .filter((chunk) => chunk.type === "IDAT" || chunk.type === "fdAT")
      .map((chunk) => chunk.data.byteLength),
  );
  if (
    !Number.isFinite(maximumFrameChunk) ||
    maximumFrameChunk > 64 * 1024 - 12
  ) {
    throw new Error(
      "Browser APNG frame chunks exceed the bounded 64 KiB write design.",
    );
  }

  const { stdout: probeJson } = await execFileAsync(
    "ffprobe",
    [
      "-v",
      "error",
      "-count_frames",
      "-select_streams",
      "v:0",
      "-show_entries",
      "stream=codec_name,width,height,nb_read_frames",
      "-show_entries",
      "frame=pts_time,duration_time",
      "-of",
      "json",
      localPath,
    ],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
  );
  const probe = JSON.parse(probeJson);
  const stream = probe.streams?.[0];
  if (
    stream?.codec_name !== "apng" ||
    stream.width !== width ||
    stream.height !== height ||
    Number(stream.nb_read_frames) !== expectedFrames ||
    probe.frames?.length !== expectedFrames
  ) {
    throw new Error("Native FFprobe did not decode the complete APNG output.");
  }
  let expectedTimestampSeconds = 0;
  for (let index = 0; index < expectedFrames; index += 1) {
    const frame = probe.frames[index];
    const durationSeconds = sourceAnimation.durationsMs[index] / 1_000;
    if (
      Math.abs(Number(frame.pts_time) - expectedTimestampSeconds) > 0.000001 ||
      Math.abs(Number(frame.duration_time) - durationSeconds) > 0.000001
    ) {
      throw new Error(
        `Native APNG timing validation failed at frame ${index + 1}.`,
      );
    }
    expectedTimestampSeconds += durationSeconds;
  }

  const outputFrame = async (frameIndex) =>
    (
      await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-i",
          localPath,
          "-vf",
          `select=eq(n\\,${frameIndex})`,
          "-fps_mode",
          "vfr",
          "-frames:v",
          "1",
          "-pix_fmt",
          "rgba",
          "-f",
          "rawvideo",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 32 * 1024 * 1024,
          encoding: "buffer",
        },
      )
    ).stdout;
  const sourceFrame = async (frameIndex) =>
    (
      await execFileAsync(
        "python",
        [
          "scripts/decode-pillow-animation-frame.py",
          sourcePath,
          String(frameIndex),
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 32 * 1024 * 1024,
          encoding: "buffer",
        },
      )
    ).stdout;
  const allFrameSha256 = [];
  for (let index = 0; index < expectedFrames; index += 1) {
    const output = await outputFrame(index);
    const reference = await sourceFrame(index);
    const outputHash = createHash("sha256").update(output).digest("hex");
    const referenceHash = createHash("sha256").update(reference).digest("hex");
    if (outputHash !== referenceHash) {
      throw new Error(
        `Browser APNG frame ${index + 1} differs from native source decoding.`,
      );
    }
    allFrameSha256.push(outputHash);
  }
  return {
    format: {
      format_name: "apng",
      size: String(finalState.metrics.outputBytes),
    },
    streams: probe.streams,
    withinValidation: {
      method: "apng-chunk-audit-plus-ffprobe-and-all-frame-native-rgba-hash",
      frameCount: expectedFrames,
      loopCount: expectedPlays,
      timingExact: true,
      maximumFrameChunk,
      allFrameSha256,
      decodedByNativeFfmpeg: true,
      sourceDecodedByPinnedPillow: true,
    },
  };
}

async function validateAnimatedGifOutput(
  localPath,
  sourcePath,
  source,
  finalState,
) {
  const encoded = await readFile(localPath);
  if (encoded.subarray(0, 6).toString("ascii") !== "GIF89a") {
    throw new Error("Browser GIF output has an invalid GIF89a signature.");
  }
  const width = encoded.readUInt16LE(6);
  const height = encoded.readUInt16LE(8);
  const packed = encoded[10];
  if ((packed & 0x80) === 0) {
    throw new Error(
      "Browser GIF output does not contain its required global palette.",
    );
  }
  let offset = 13 + 3 * 2 ** ((packed & 0x07) + 1);
  let loopCount = null;
  let maximumDataSubblock = 0;
  const frameControls = [];
  const imageDescriptors = [];
  let pendingControl = null;
  const readSubblocks = () => {
    const payloads = [];
    for (;;) {
      if (offset >= encoded.byteLength) {
        throw new Error(
          "Browser GIF output ends inside a data-subblock chain.",
        );
      }
      const size = encoded[offset];
      offset += 1;
      if (size === 0) return payloads;
      if (offset + size > encoded.byteLength) {
        throw new Error(
          "Browser GIF data subblock exceeds the output boundary.",
        );
      }
      maximumDataSubblock = Math.max(maximumDataSubblock, size);
      payloads.push(encoded.subarray(offset, offset + size));
      offset += size;
    }
  };
  let trailerSeen = false;
  while (offset < encoded.byteLength) {
    const marker = encoded[offset];
    if (marker === 0x3b) {
      offset += 1;
      trailerSeen = true;
      break;
    }
    if (marker === 0x21) {
      if (offset + 2 > encoded.byteLength) {
        throw new Error("Browser GIF ends inside an extension header.");
      }
      const label = encoded[offset + 1];
      offset += 2;
      if (label === 0xf9) {
        if (
          offset + 6 > encoded.byteLength ||
          encoded[offset] !== 4 ||
          encoded[offset + 5] !== 0
        ) {
          throw new Error(
            "Browser GIF has an invalid graphic-control extension.",
          );
        }
        pendingControl = {
          packed: encoded[offset + 1],
          delay: encoded.readUInt16LE(offset + 2),
          transparentIndex: encoded[offset + 4],
        };
        offset += 6;
        continue;
      }
      if (offset >= encoded.byteLength) {
        throw new Error("Browser GIF ends inside an extension block.");
      }
      const headerSize = encoded[offset];
      offset += 1;
      if (offset + headerSize > encoded.byteLength) {
        throw new Error(
          "Browser GIF extension header exceeds the output boundary.",
        );
      }
      const identifier = encoded
        .subarray(offset, offset + headerSize)
        .toString("ascii");
      offset += headerSize;
      const payloads = readSubblocks();
      if (
        label === 0xff &&
        identifier === "NETSCAPE2.0" &&
        payloads[0]?.byteLength === 3 &&
        payloads[0][0] === 1
      ) {
        loopCount = payloads[0].readUInt16LE(1);
      }
      continue;
    }
    if (marker === 0x2c) {
      if (offset + 10 > encoded.byteLength || !pendingControl) {
        throw new Error(
          "Browser GIF image is missing a complete descriptor or frame control.",
        );
      }
      const descriptor = {
        left: encoded.readUInt16LE(offset + 1),
        top: encoded.readUInt16LE(offset + 3),
        width: encoded.readUInt16LE(offset + 5),
        height: encoded.readUInt16LE(offset + 7),
        packed: encoded[offset + 9],
      };
      offset += 10;
      if ((descriptor.packed & 0x80) !== 0) {
        offset += 3 * 2 ** ((descriptor.packed & 0x07) + 1);
      }
      if (offset >= encoded.byteLength || encoded[offset] !== 8) {
        throw new Error(
          "Browser GIF image has an invalid LZW minimum code size.",
        );
      }
      offset += 1;
      readSubblocks();
      imageDescriptors.push(descriptor);
      frameControls.push(pendingControl);
      pendingControl = null;
      continue;
    }
    throw new Error(
      `Browser GIF contains an unexpected block marker 0x${marker.toString(16)}.`,
    );
  }
  if (!trailerSeen || offset !== encoded.byteLength || pendingControl) {
    throw new Error("Browser GIF does not end cleanly at its trailer.");
  }

  const { stdout: sourceMetadataJson } = await execFileAsync(
    "python",
    ["scripts/decode-pillow-animation-frame.py", sourcePath, "--metadata"],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 1024 * 1024 },
  );
  const sourceAnimation = JSON.parse(sourceMetadataJson);
  const expectedFrames = Number(sourceAnimation.frameCount);
  if (
    !Number.isSafeInteger(expectedFrames) ||
    expectedFrames < 1 ||
    expectedFrames !== Number(source.probe?.streams?.[0]?.nb_frames ?? 1) ||
    sourceAnimation.width !== width ||
    sourceAnimation.height !== height ||
    !Array.isArray(sourceAnimation.durationsMs) ||
    sourceAnimation.durationsMs.length !== expectedFrames ||
    imageDescriptors.length !== expectedFrames ||
    frameControls.length !== expectedFrames
  ) {
    throw new Error(
      "Browser GIF frame structure differs from the source animation manifest.",
    );
  }
  const expectedLoop =
    expectedFrames === 1
      ? null
      : sourceAnimation.loop === 0
        ? 0
        : Math.max(0, Number(sourceAnimation.loop) - 1);
  if (loopCount !== expectedLoop) {
    throw new Error(
      "Browser GIF loop control differs from the source animation.",
    );
  }
  for (let index = 0; index < expectedFrames; index += 1) {
    const descriptor = imageDescriptors[index];
    const control = frameControls[index];
    if (
      descriptor.left !== 0 ||
      descriptor.top !== 0 ||
      descriptor.width !== width ||
      descriptor.height !== height ||
      descriptor.packed !== 0 ||
      ((control.packed >>> 2) & 0x07) !== 2 ||
      (control.packed & 1) !== 1 ||
      control.transparentIndex !== 0
    ) {
      throw new Error(
        `Browser GIF frame ${index + 1} has invalid bounded controls.`,
      );
    }
    const expectedDelay = Math.round(sourceAnimation.durationsMs[index] / 10);
    if (control.delay !== expectedDelay) {
      throw new Error(
        `Browser GIF frame ${index + 1} timing differs from the source.`,
      );
    }
  }
  if (maximumDataSubblock > 255) {
    throw new Error("Browser GIF contains an oversized image-data subblock.");
  }

  const { stdout: outputMetadataJson } = await execFileAsync(
    "python",
    ["scripts/decode-pillow-animation-frame.py", localPath, "--metadata"],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 1024 * 1024 },
  );
  const outputAnimation = JSON.parse(outputMetadataJson);
  if (
    outputAnimation.frameCount !== expectedFrames ||
    outputAnimation.width !== width ||
    outputAnimation.height !== height ||
    outputAnimation.loop !== (expectedLoop ?? 0) ||
    outputAnimation.durationsMs.some(
      (duration, index) =>
        duration !== Math.round(sourceAnimation.durationsMs[index] / 10) * 10,
    )
  ) {
    throw new Error(
      "Pinned Pillow did not decode the expected GIF timing and loop metadata.",
    );
  }

  const outputFrame = async (frameIndex) =>
    (
      await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-i",
          localPath,
          "-vf",
          `select=eq(n\\,${frameIndex})`,
          "-fps_mode",
          "vfr",
          "-frames:v",
          "1",
          "-pix_fmt",
          "rgba",
          "-f",
          "rawvideo",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 32 * 1024 * 1024,
          encoding: "buffer",
        },
      )
    ).stdout;
  const sourceFrame = async (frameIndex) =>
    (
      await execFileAsync(
        "python",
        [
          "scripts/decode-pillow-animation-frame.py",
          sourcePath,
          String(frameIndex),
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 32 * 1024 * 1024,
          encoding: "buffer",
        },
      )
    ).stdout;
  const quantize = (pixels) => {
    const output = Buffer.allocUnsafe(pixels.byteLength);
    for (let index = 0; index < pixels.byteLength; index += 4) {
      if (pixels[index + 3] < 128) {
        output.set([0, 0, 0, 0], index);
        continue;
      }
      const quantized =
        (pixels[index] & 0xe0) |
        ((pixels[index + 1] & 0xe0) >>> 3) |
        (pixels[index + 2] >>> 6);
      const paletteIndex = quantized === 0 ? 1 : quantized;
      output[index] =
        paletteIndex <= 1
          ? 0
          : Math.round((((paletteIndex >>> 5) & 7) * 255) / 7);
      output[index + 1] =
        paletteIndex <= 1
          ? 0
          : Math.round((((paletteIndex >>> 2) & 7) * 255) / 7);
      output[index + 2] =
        paletteIndex <= 1 ? 0 : Math.round(((paletteIndex & 3) * 255) / 3);
      output[index + 3] = 255;
    }
    return output;
  };
  const allFrameSha256 = [];
  let sourceSsim = null;
  for (let index = 0; index < expectedFrames; index += 1) {
    const output = await outputFrame(index);
    const expected = quantize(await sourceFrame(index));
    const outputHash = createHash("sha256").update(output).digest("hex");
    const expectedHash = createHash("sha256").update(expected).digest("hex");
    if (outputHash !== expectedHash) {
      if (
        expectedFrames !== 1 ||
        path.extname(sourcePath).toLowerCase() !== ".webp"
      ) {
        throw new Error(
          `Browser GIF frame ${index + 1} differs from RGB332 quantization.`,
        );
      }
      const { stderr } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "info",
          "-i",
          sourcePath,
          "-i",
          localPath,
          "-lavfi",
          "[0:v:0]format=rgb24[source];[1:v:0]format=rgb24[converted];[source][converted]ssim",
          "-frames:v",
          "1",
          "-f",
          "null",
          "NUL",
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
      );
      sourceSsim = Number.parseFloat(
        stderr.match(/SSIM[^\r\n]*All:([0-9.]+)/)?.[1] ?? "",
      );
      if (!Number.isFinite(sourceSsim) || sourceSsim < 0.9) {
        throw new Error(
          `Browser GIF static WebP visual validation failed at SSIM ${sourceSsim}.`,
        );
      }
    }
    allFrameSha256.push(outputHash);
  }
  return {
    format: {
      format_name: "gif",
      size: String(finalState.metrics.outputBytes),
    },
    withinValidation: {
      method:
        "gif-block-audit-plus-pillow-metadata-and-native-frame-validation",
      frameCount: expectedFrames,
      loopCount,
      timingRoundedToCentiseconds: true,
      maximumDataSubblock,
      allFrameSha256,
      sourceSsim,
      exactRgb332FrameMatch: sourceSsim == null,
      decodedByNativeFfmpeg: true,
      metadataDecodedByPinnedPillow: true,
    },
  };
}

async function validateAnimatedWebpOutput(
  localPath,
  sourcePath,
  source,
  finalState,
) {
  const encoded = await readFile(localPath);
  if (
    encoded.byteLength < 44 ||
    encoded.subarray(0, 4).toString("ascii") !== "RIFF" ||
    encoded.subarray(8, 12).toString("ascii") !== "WEBP" ||
    encoded.readUInt32LE(4) + 8 !== encoded.byteLength
  ) {
    throw new Error(
      "Browser animated WebP output has an invalid RIFF header or size.",
    );
  }
  const chunks = [];
  let offset = 12;
  while (offset < encoded.byteLength) {
    if (offset + 8 > encoded.byteLength) {
      throw new Error("Browser animated WebP ends inside a chunk header.");
    }
    const type = encoded.toString("ascii", offset, offset + 4);
    const size = encoded.readUInt32LE(offset + 4);
    const payloadOffset = offset + 8;
    const end = payloadOffset + size;
    const paddedEnd = end + (size & 1);
    if (paddedEnd > encoded.byteLength) {
      throw new Error(
        `Browser animated WebP ${type} chunk exceeds the RIFF boundary.`,
      );
    }
    chunks.push({ type, size, payloadOffset, end });
    offset = paddedEnd;
  }
  if (
    offset !== encoded.byteLength ||
    chunks[0]?.type !== "VP8X" ||
    chunks[1]?.type !== "ANIM"
  ) {
    throw new Error(
      "Browser animated WebP has an invalid VP8X/ANIM chunk layout.",
    );
  }
  const extended = chunks[0];
  if (
    extended.size !== 10 ||
    (encoded[extended.payloadOffset] & 0x02) === 0 ||
    encoded[extended.payloadOffset + 1] !== 0 ||
    encoded[extended.payloadOffset + 2] !== 0 ||
    encoded[extended.payloadOffset + 3] !== 0
  ) {
    throw new Error("Browser animated WebP has invalid VP8X feature flags.");
  }
  const readUint24Le = (at) => encoded.readUIntLE(at, 3);
  const width = readUint24Le(extended.payloadOffset + 4) + 1;
  const height = readUint24Le(extended.payloadOffset + 7) + 1;
  const animationControl = chunks[1];
  if (animationControl.size !== 6) {
    throw new Error("Browser animated WebP has an invalid ANIM control size.");
  }
  const loopCount = encoded.readUInt16LE(animationControl.payloadOffset + 4);

  const { stdout: sourceMetadataJson } = await execFileAsync(
    "python",
    ["scripts/decode-pillow-animation-frame.py", sourcePath, "--metadata"],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 1024 * 1024 },
  );
  const sourceAnimation = JSON.parse(sourceMetadataJson);
  const expectedFrames = Number(sourceAnimation.frameCount);
  const manifestFrames = Number(source.probe?.streams?.[0]?.nb_frames ?? 1);
  const sourceLoop = Number(sourceAnimation.loop);
  const expectedLoop =
    sourceLoop === 0
      ? 0
      : path.extname(sourcePath).toLowerCase() === ".gif"
        ? sourceLoop + 1
        : sourceLoop;
  if (
    !Number.isSafeInteger(expectedFrames) ||
    expectedFrames < 2 ||
    expectedFrames !== manifestFrames ||
    sourceAnimation.width !== width ||
    sourceAnimation.height !== height ||
    !Array.isArray(sourceAnimation.durationsMs) ||
    sourceAnimation.durationsMs.length !== expectedFrames ||
    !Number.isSafeInteger(expectedLoop) ||
    expectedLoop < 0 ||
    expectedLoop > 65_535 ||
    loopCount !== expectedLoop
  ) {
    throw new Error(
      "Browser animated WebP canvas, frame, or loop control differs from the source.",
    );
  }

  const frames = chunks.filter((chunk) => chunk.type === "ANMF");
  if (frames.length !== expectedFrames) {
    throw new Error(
      "Browser animated WebP does not contain one ANMF chunk per source frame.",
    );
  }
  let maximumNestedChunk = 0;
  for (let index = 0; index < frames.length; index += 1) {
    const frame = frames[index];
    if (frame.size < 24) {
      throw new Error(`Browser animated WebP frame ${index + 1} is too short.`);
    }
    const frameX = readUint24Le(frame.payloadOffset) * 2;
    const frameY = readUint24Le(frame.payloadOffset + 3) * 2;
    const frameWidth = readUint24Le(frame.payloadOffset + 6) + 1;
    const frameHeight = readUint24Le(frame.payloadOffset + 9) + 1;
    const durationMs = readUint24Le(frame.payloadOffset + 12);
    const flags = encoded[frame.payloadOffset + 15];
    if (
      frameX !== 0 ||
      frameY !== 0 ||
      frameWidth !== width ||
      frameHeight !== height ||
      durationMs !==
        Math.max(1, Math.round(sourceAnimation.durationsMs[index])) ||
      flags !== 1
    ) {
      throw new Error(
        `Browser animated WebP frame ${index + 1} has invalid bounded controls.`,
      );
    }
    let nestedOffset = frame.payloadOffset + 16;
    let imageChunks = 0;
    let alphaChunks = 0;
    while (nestedOffset < frame.end) {
      if (nestedOffset + 8 > frame.end) {
        throw new Error(
          `Browser animated WebP frame ${index + 1} ends in a nested header.`,
        );
      }
      const nestedType = encoded.toString(
        "ascii",
        nestedOffset,
        nestedOffset + 4,
      );
      const nestedSize = encoded.readUInt32LE(nestedOffset + 4);
      const nestedBytes = 8 + nestedSize + (nestedSize & 1);
      if (nestedOffset + nestedBytes > frame.end) {
        throw new Error(
          `Browser animated WebP frame ${index + 1} has an oversized nested chunk.`,
        );
      }
      if (nestedType === "ALPH") alphaChunks += 1;
      else if (nestedType === "VP8 " || nestedType === "VP8L") imageChunks += 1;
      else {
        throw new Error(
          `Browser animated WebP frame ${index + 1} contains unsupported ${nestedType} data.`,
        );
      }
      maximumNestedChunk = Math.max(maximumNestedChunk, nestedBytes);
      nestedOffset += nestedBytes;
    }
    if (nestedOffset !== frame.end || imageChunks !== 1 || alphaChunks > 1) {
      throw new Error(
        `Browser animated WebP frame ${index + 1} has invalid image chunks.`,
      );
    }
  }

  const { stdout: outputMetadataJson } = await execFileAsync(
    "python",
    ["scripts/decode-pillow-animation-frame.py", localPath, "--metadata"],
    { cwd: projectRoot, windowsHide: true, maxBuffer: 1024 * 1024 },
  );
  const outputAnimation = JSON.parse(outputMetadataJson);
  if (
    outputAnimation.frameCount !== expectedFrames ||
    outputAnimation.width !== width ||
    outputAnimation.height !== height ||
    outputAnimation.loop !== expectedLoop ||
    outputAnimation.durationsMs.some(
      (duration, index) =>
        duration !==
        Math.max(1, Math.round(sourceAnimation.durationsMs[index])),
    )
  ) {
    throw new Error(
      "Pinned Pillow/libwebp did not decode the expected WebP animation metadata.",
    );
  }

  const decodeFrame = async (imagePath, frameIndex) =>
    (
      await execFileAsync(
        "python",
        [
          "scripts/decode-pillow-animation-frame.py",
          imagePath,
          String(frameIndex),
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 32 * 1024 * 1024,
          encoding: "buffer",
        },
      )
    ).stdout;
  const validationRoot = path.join(
    workRoot,
    `animated-webp-validation-${process.pid}-${Date.now()}`,
  );
  assertInside(workRoot, validationRoot);
  await mkdir(validationRoot, { recursive: true });
  const sourceRaw = path.join(validationRoot, "source.rgba");
  const outputRaw = path.join(validationRoot, "output.rgba");
  const allFrameSsim = [];
  const allFrameSha256 = [];
  try {
    for (let index = 0; index < expectedFrames; index += 1) {
      const [sourceFrame, outputFrame] = await Promise.all([
        decodeFrame(sourcePath, index),
        decodeFrame(localPath, index),
      ]);
      if (
        sourceFrame.byteLength !== width * height * 4 ||
        outputFrame.byteLength !== sourceFrame.byteLength
      ) {
        throw new Error(
          `Pinned Pillow returned an invalid frame size at index ${index}.`,
        );
      }
      for (let pixel = 3; pixel < sourceFrame.byteLength; pixel += 4) {
        if (sourceFrame[pixel] !== outputFrame[pixel]) {
          throw new Error(
            `Browser animated WebP frame ${index + 1} changed alpha.`,
          );
        }
      }
      await Promise.all([
        writeFile(sourceRaw, sourceFrame),
        writeFile(outputRaw, outputFrame),
      ]);
      const { stderr } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "info",
          "-f",
          "rawvideo",
          "-pixel_format",
          "rgba",
          "-video_size",
          `${width}x${height}`,
          "-i",
          sourceRaw,
          "-f",
          "rawvideo",
          "-pixel_format",
          "rgba",
          "-video_size",
          `${width}x${height}`,
          "-i",
          outputRaw,
          "-lavfi",
          "[0:v:0]format=rgb24[source];[1:v:0]format=rgb24[output];[source][output]ssim",
          "-frames:v",
          "1",
          "-f",
          "null",
          "NUL",
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
      );
      const ssim = Number.parseFloat(
        stderr.match(/SSIM[^\r\n]*All:([0-9.]+)/)?.[1] ?? "",
      );
      if (!Number.isFinite(ssim) || ssim < 0.9) {
        throw new Error(
          `Browser animated WebP frame ${index + 1} measured SSIM ${ssim}.`,
        );
      }
      allFrameSsim.push(ssim);
      allFrameSha256.push(
        createHash("sha256").update(outputFrame).digest("hex"),
      );
    }
  } finally {
    await removeWithRetries(validationRoot);
  }
  return {
    format: {
      format_name: "webp",
      size: String(finalState.metrics.outputBytes),
    },
    withinValidation: {
      method:
        "webp-riff-audit-plus-pinned-pillow-libwebp-metadata-and-all-frame-ssim",
      frameCount: expectedFrames,
      loopCount,
      timingRoundedToMilliseconds: true,
      maximumNestedChunk,
      minimumFrameSsim: Math.min(...allFrameSsim),
      allFrameSsim,
      allFrameSha256,
      alphaExact: true,
      decodedByPinnedPillowLibwebp: true,
    },
  };
}

async function validateTiffPageArchiveOutput(
  localPath,
  source,
  finalState,
  route,
) {
  if (
    finalState.metrics.outputBytes < 1 ||
    finalState.metrics.outputBytes > 4_294_967_295
  ) {
    throw new Error(
      `Browser TIFF ZIP is outside the ZIP32 range: ${finalState.metrics.outputBytes} bytes.`,
    );
  }
  const references = source.validationReferences;
  const expectedPages = Number(source.pageCount ?? references?.length);
  if (
    !Number.isSafeInteger(expectedPages) ||
    expectedPages < 1 ||
    expectedPages > 1_000 ||
    !Array.isArray(references) ||
    references.length !== expectedPages
  ) {
    throw new Error(
      "The TIFF ZIP stress manifest must declare one project-local reference per page.",
    );
  }
  const extractionRoot = path.join(
    workRoot,
    `tiff-page-validation-${process.pid}-${route}`,
  );
  assertInside(workRoot, extractionRoot);
  await removeWithRetries(extractionRoot);
  await mkdir(extractionRoot, { recursive: true });
  try {
    const expectedNames = [
      ...Array.from(
        { length: expectedPages },
        (_, index) => `page-${String(index + 1).padStart(4, "0")}.png`,
      ),
      "pages.json",
    ];
    const { stdout: listing } = await execFileAsync("tar", ["-tf", localPath], {
      cwd: projectRoot,
      windowsHide: true,
      maxBuffer: 8 * 1024 * 1024,
    });
    if (
      JSON.stringify(listing.trim().split(/\r?\n/)) !==
      JSON.stringify(expectedNames)
    ) {
      throw new Error("TIFF ZIP entries are incomplete or out of order.");
    }
    await execFileAsync("tar", ["-xf", localPath, "-C", extractionRoot], {
      cwd: projectRoot,
      windowsHide: true,
      maxBuffer: 8 * 1024 * 1024,
    });
    const manifest = JSON.parse(
      await readFile(path.join(extractionRoot, "pages.json"), "utf8"),
    );
    if (
      manifest.schema !== "within-tiff-pages-v1" ||
      manifest.sourceFormat !== "tiff" ||
      manifest.pageCount !== expectedPages ||
      !Array.isArray(manifest.pages) ||
      manifest.pages.length !== expectedPages
    ) {
      throw new Error("TIFF ZIP page manifest is invalid.");
    }
    let aggregateDecodedBytes = 0;
    const decodedHashes = [];
    const decodedHash = async (imagePath, pixelFormat) => {
      const { stdout } = await execFileAsync(
        "ffmpeg",
        [
          "-v",
          "error",
          "-i",
          imagePath,
          "-frames:v",
          "1",
          "-pix_fmt",
          pixelFormat,
          "-f",
          "hash",
          "-hash",
          "sha256",
          "-",
        ],
        {
          cwd: projectRoot,
          windowsHide: true,
          maxBuffer: 8 * 1024 * 1024,
        },
      );
      const hash = stdout.match(/SHA256=([0-9a-f]{64})/i)?.[1]?.toLowerCase();
      if (!hash)
        throw new Error("FFmpeg did not return a TIFF page pixel hash.");
      return hash;
    };
    for (let index = 0; index < expectedPages; index += 1) {
      const record = manifest.pages[index];
      const expectedName = expectedNames[index];
      if (
        record.file !== expectedName ||
        record.index !== index ||
        !Number.isSafeInteger(record.width) ||
        !Number.isSafeInteger(record.height) ||
        record.width < 1 ||
        record.height < 1 ||
        (record.bitsPerSample !== 8 && record.bitsPerSample !== 16) ||
        !Number.isSafeInteger(record.samplesPerPixel) ||
        record.samplesPerPixel < 1 ||
        record.samplesPerPixel > 4 ||
        !Number.isSafeInteger(record.decodedBytes) ||
        record.decodedBytes < 1
      ) {
        throw new Error(`TIFF ZIP page metadata is invalid at index ${index}.`);
      }
      aggregateDecodedBytes += record.decodedBytes;
      const pagePath = path.join(extractionRoot, expectedName);
      const { stdout } = await execFileAsync(
        "ffprobe",
        [
          "-v",
          "error",
          "-show_entries",
          "stream=codec_name,width,height",
          "-of",
          "json",
          pagePath,
        ],
        { cwd: projectRoot, windowsHide: true, maxBuffer: 8 * 1024 * 1024 },
      );
      const stream = JSON.parse(stdout).streams?.[0];
      if (
        stream?.codec_name !== "png" ||
        stream.width !== record.width ||
        stream.height !== record.height
      ) {
        throw new Error(`TIFF ZIP page ${index + 1} is not the expected PNG.`);
      }
      const referencePath = path.resolve(projectRoot, references[index]);
      const referenceRelative = path.relative(projectRoot, referencePath);
      if (
        !referenceRelative ||
        referenceRelative.startsWith("..") ||
        path.isAbsolute(referenceRelative)
      ) {
        throw new Error("TIFF page references must stay inside the project.");
      }
      const pixelFormat = record.bitsPerSample === 16 ? "rgb48le" : "rgb24";
      const pageHash = await decodedHash(pagePath, pixelFormat);
      const referenceHash = await decodedHash(referencePath, pixelFormat);
      if (pageHash !== referenceHash) {
        throw new Error(
          `TIFF ZIP page ${index + 1} differs from its reference.`,
        );
      }
      decodedHashes.push(pageHash);
    }
    if (manifest.aggregateDecodedBytes !== aggregateDecodedBytes) {
      throw new Error("TIFF ZIP aggregate decoded size is inconsistent.");
    }
    return {
      format: {
        format_name: "zip",
        size: String(finalState.metrics.outputBytes),
      },
      withinValidation: {
        method: "native-tar-list-extract-plus-ffprobe-and-decoded-sha256",
        pageCount: expectedPages,
        aggregateDecodedBytes,
        decodedPageSha256: decodedHashes,
        decodedByNativeFfmpeg: true,
      },
    };
  } finally {
    await removeWithRetries(extractionRoot);
  }
}

async function findProjectLocalPayload(root, expectedBytes) {
  assertInside(workRoot, root);
  const deadline = Date.now() + 10_000;
  while (Date.now() < deadline) {
    const stack = [root];
    while (stack.length) {
      const directory = stack.pop();
      const entries = await readdir(directory, { withFileTypes: true });
      for (const entry of entries) {
        const candidate = path.join(directory, entry.name);
        if (entry.isDirectory()) {
          stack.push(candidate);
        } else if (entry.isFile()) {
          const candidateStat = await stat(candidate);
          if (candidateStat.size === expectedBytes) {
            assertInside(workRoot, candidate);
            return candidate;
          }
        }
      }
    }
    await delay(250);
  }
  throw new Error(
    `The project-local OPFS payload was not found at ${expectedBytes} bytes.`,
  );
}

function assertInside(parent, child) {
  const relative = path.relative(parent, child);
  if (
    relative === "" ||
    relative.startsWith("..") ||
    path.isAbsolute(relative)
  ) {
    throw new Error(`Unsafe generated path: ${child}`);
  }
}

async function waitForServer(url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {
      // The local server is still starting.
    }
    await delay(250);
  }
  throw new Error(`Server did not become ready: ${url}`);
}

function reserveAvailablePort() {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.unref();
    server.once("error", reject);
    server.listen({ host: "127.0.0.1", port: 0, exclusive: true }, () => {
      const address = server.address();
      if (!address || typeof address === "string") {
        server.close(() =>
          reject(new Error("Could not reserve a local test port.")),
        );
        return;
      }
      server.close((error) => {
        if (error) reject(error);
        else resolve(address.port);
      });
    });
  });
}

async function waitForDebugPort(profile, timeoutMs) {
  const activePortPath = path.join(profile, "DevToolsActivePort");
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const contents = await readFile(activePortPath, "utf8");
      const port = Number.parseInt(contents.split(/\r?\n/)[0], 10);
      if (Number.isInteger(port)) return port;
    } catch {
      // Chrome is still starting.
    }
    await delay(100);
  }
  throw new Error("Chrome DevTools port did not become ready.");
}

async function setLocalFileInput(cdp, localPath) {
  const { root } = await cdp.send("DOM.getDocument", { depth: 1 });
  const { nodeId } = await cdp.send("DOM.querySelector", {
    nodeId: root.nodeId,
    selector: '[data-testid="file-input"]',
  });
  if (!nodeId) throw new Error("The production file input was not found.");
  await cdp.send("DOM.setFileInputFiles", {
    nodeId,
    files: [localPath],
  });
}

async function waitForStableMemory(
  rootPid,
  page,
  phase,
  targetSamples,
  maximumPrivateBytes = null,
  timeoutMs = 30_000,
) {
  const local = [];
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const sample = await takeSample(rootPid, page, phase);
    local.push(sample);
    targetSamples.push(sample);
    const stable = stableWindow(local);
    if (stable && (maximumPrivateBytes == null || stable.privateBytes <= maximumPrivateBytes)) {
      return { phase, ...stable };
    }
    await delay(sampleIntervalMs);
  }
  const last = [...local].reverse().find((item) => item.privateBytes != null);
  return {
    phase,
    privateBytes: last?.privateBytes ?? null,
    rssBytes: last?.rssBytes ?? null,
    stable: false,
    sampleCount: local.length,
  };
}

async function takeSample(rootPid, page, phase) {
  nativeObserver?.setPhase(phase);
  const acquisitionStartedAt = new Date().toISOString();
  let processes = null;
  let sampleError = null;
  try {
    processes = await sampleWindowsProcessTree(rootPid);
  } catch (error) {
    processes = null;
    sampleError = String(error.message ?? error).slice(0, 1024);
  }
  let pageHeap = null;
  let workerHeaps = null;
  let storageEstimate = null;
  try {
    pageHeap = await diagnosticRealmSample(
      page.evaluate(() => performance.memory?.usedJSHeapSize ?? null),
    );
    workerHeaps = await Promise.all(
      page.workers().map(async (worker) => {
        try {
          return {
            url: worker.url(),
            usedJSHeapSize: await diagnosticRealmSample(
              worker.evaluate(() => performance.memory?.usedJSHeapSize ?? null),
            ),
          };
        } catch {
          return { url: worker.url(), usedJSHeapSize: null };
        }
      }),
    );
    storageEstimate = await diagnosticRealmSample(
      page.evaluate(async () => {
        if (!navigator.storage?.estimate) return null;
        const estimate = await navigator.storage.estimate();
        return {
          usage: estimate.usage ?? null,
          quota: estimate.quota ?? null,
        };
      }),
    );
  } catch {
    // Realm-level samples are diagnostic and may be unavailable.
  }
  return {
    timestamp: new Date().toISOString(),
    elapsedMs: Date.now() - startedAt,
    phase,
    acquisitionStartedAt,
    sampleError,
    privateBytes:
      processes == null
        ? null
        : processes.reduce((sum, process) => sum + process.privateBytes, 0),
    rssBytes:
      processes == null
        ? null
        : processes.reduce((sum, process) => sum + process.rssBytes, 0),
    processes,
    realms: { pageUsedJSHeapBytes: pageHeap, workers: workerHeaps },
    storageEstimate,
  };
}

async function diagnosticRealmSample(promise, timeoutMs = 2_000) {
  let timeout;
  try {
    return await Promise.race([
      promise,
      new Promise((resolve) => {
        timeout = setTimeout(() => resolve(null), timeoutMs);
        timeout.unref?.();
      }),
    ]);
  } finally {
    clearTimeout(timeout);
  }
}

async function sampleWindowsProcessTree(rootPid) {
  // The shared sampler rejects a missing root or invalid per-process counters.
  // An empty CIM result is unavailable, never a zero-byte baseline.
  return (await sampleChromiumTree(rootPid)).processes;
}

async function writeFailureReports(report) {
  const stamp = report.generatedAt.replace(/[:.]/g, "-");
  const destinationSuffix =
    report.destinationMode === "direct-handle" ? "-direct-handle" : "";
  const base = path.join(
    reportRoot,
    `${stamp}-${report.profileId}${destinationSuffix}-stress-native-100ms-failure`,
  );
  await writeFile(
    `${base}.json`,
    `${JSON.stringify(report, null, 2)}\n`,
    { encoding: "utf8", flag: "wx" },
  );
  await writeNativePeakCsv(base, report.nativeMemory);
  const csvRows = [
    [
      "timestamp",
      "elapsedMs",
      "phase",
      "privateBytes",
      "rssBytes",
      "processCount",
      "pageUsedJSHeapBytes",
    ],
    ...report.samples.map((sample) => [
      sample.timestamp,
      sample.elapsedMs,
      sample.phase,
      sample.privateBytes ?? "",
      sample.rssBytes ?? "",
      sample.processes?.length ?? "",
      sample.realms?.pageUsedJSHeapBytes ?? "",
    ]),
  ];
  await writeFile(
    `${base}.csv`,
    `${csvRows.map((row) => row.map(csvCell).join(",")).join("\n")}\n`,
    "utf8",
  );
  const recentSamples = report.samples.slice(-100);
  const rows = recentSamples
    .map(
      (sample) =>
        `<tr><td>${htmlEscape(sample.timestamp)}</td><td>${htmlEscape(sample.phase)}</td><td>${sample.privateBytes ?? "unavailable"}</td><td>${sample.rssBytes ?? "unavailable"}</td><td>${sample.processes?.length ?? "unavailable"}</td></tr>`,
    )
    .join("");
  await writeFile(
    `${base}.html`,
    `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Within ${htmlEscape(report.profileId)} failed memory profile</title>
<style>body{font:15px system-ui;margin:0;background:#f5f0e7;color:#161815}main{max-width:1100px;margin:auto;padding:40px}h1{font:44px Georgia;margin:0 0 12px}.fail{color:#b3261e;font-weight:700}pre,table{background:#fff;padding:16px;border-radius:12px;overflow:auto}table{border-collapse:collapse;width:100%}th,td{padding:8px;border-bottom:1px solid #ddd;text-align:right}th:first-child,td:first-child{text-align:left}</style>
</head><body><main><h1>${htmlEscape(report.profileId)} failure diagnostics</h1>
<p class="fail">FAIL · run ${report.activeRun || "before conversion"}</p>
<pre>${htmlEscape(report.failure.stack ?? report.failure.message)}</pre>
<h2>Last 100 process-tree samples</h2><table><thead><tr><th>Timestamp</th><th>Phase</th><th>Private bytes</th><th>RSS bytes</th><th>Processes</th></tr></thead><tbody>${rows}</tbody></table>
<h2>Native acquisition peaks</h2><pre>${htmlEscape(JSON.stringify(report.nativeMemory?.phases ?? null, null, 2))}</pre>
<p>Profile/output and observer scratch cleanup runs in finally. Terminal cleanup confirmation is separate from this pre-cleanup report.</p>
</main></body></html>`,
    "utf8",
  );
}

async function writeReports(report) {
  const stamp = report.generatedAt.replace(/[:.]/g, "-");
  const destinationSuffix =
    report.destinationMode === "direct-handle" ? "-direct-handle" : "";
  const base = path.join(
    reportRoot,
    `${stamp}-${report.profileId}${destinationSuffix}-stress-native-100ms`,
  );
  await writeFile(
    `${base}.json`,
    `${JSON.stringify(report, null, 2)}\n`,
    { encoding: "utf8", flag: "wx" },
  );
  await writeNativePeakCsv(base, report.nativeMemory);
  const csvRows = [
    [
      "timestamp",
      "elapsedMs",
      "phase",
      "privateBytes",
      "rssBytes",
      "processCount",
      "pageUsedJSHeapBytes",
    ],
    ...report.samples.map((sample) => [
      sample.timestamp,
      sample.elapsedMs,
      sample.phase,
      sample.privateBytes ?? "",
      sample.rssBytes ?? "",
      sample.processes?.length ?? "",
      sample.realms.pageUsedJSHeapBytes ?? "",
    ]),
  ];
  await writeFile(
    `${base}.csv`,
    `${csvRows.map((row) => row.map(csvCell).join(",")).join("\n")}\n`,
    "utf8",
  );
  const reportJson = JSON.stringify(report).replace(/</g, "\\u003c");
  await writeFile(
    `${base}.html`,
    `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Within ${report.profileId} memory report</title>
<style>
body{font:15px system-ui;margin:0;background:#f5f0e7;color:#161815}main{max-width:1100px;margin:auto;padding:40px}
h1{font:48px Georgia;margin:0 0 12px}.pass{color:#087a3f}.fail{color:#b3261e}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:28px 0}.card{background:#fff;padding:18px;border-radius:12px}
.card b{display:block;font-size:24px;margin-top:8px}canvas{background:#fff;border-radius:12px;width:100%;height:360px}
table{border-collapse:collapse;width:100%;background:#fff;margin-top:24px}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:right}th:first-child,td:first-child{text-align:left}
</style></head><body><main><h1>${report.profileId} stress profile</h1>
<p class="${report.passed ? "pass" : "fail"}">${report.passed ? "PASS" : "FAIL"} · complete Chromium process tree</p>
<div class="cards"><div class="card">Incremental private<b>${report.incrementalPrivateMiB.toFixed(1)} MiB</b></div>
<div class="card">Limit<b>${report.limitMiB} MiB</b></div>
<div class="card">Source<b>${(report.source.bytes / 1073741824).toFixed(2)} GiB</b></div>
<div class="card">Runs<b>${report.runs.length}</b></div></div>
<canvas id="chart" width="1050" height="360"></canvas><div id="runs"></div>
<script>const report=${reportJson};const c=document.getElementById('chart'),x=c.getContext('2d'),s=report.samples.filter(v=>v.privateBytes!=null).map(v=>({at:Date.parse(v.timestamp),bytes:v.privateBytes})),n=report.nativeMemory.graphBuckets.filter(b=>b.peak).map(b=>({at:Date.parse(b.peak[1]),bytes:b.peak[3]}));
x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);const all=s.concat(n),min=Math.min(...all.map(v=>v.at)),max=Math.max(...all.map(v=>v.at)),top=Math.max(...all.map(v=>v.bytes));
function curve(points,color){x.strokeStyle=color;x.lineWidth=2;x.beginPath();points.forEach((v,i)=>{const px=30+(v.at-min)/Math.max(1,max-min)*(c.width-60),py=c.height-30-v.bytes/top*(c.height-60);i?x.lineTo(px,py):x.moveTo(px,py)});x.stroke()}curve(s,'#f65e43');curve(n,'#2868c8');
x.fillStyle='#666';x.fillText('Whole tree: CIM (orange), native 100ms bucket peaks (blue). Old graph buckets may be evicted; phase peaks remain exact.',30,20);
document.getElementById('runs').innerHTML='<table><thead><tr><th>Run</th><th>Output</th><th>Time</th><th>Incremental private</th><th>Cleanup delta</th></tr></thead><tbody>'+report.runs.map(r=>'<tr><td>'+r.run+'</td><td>'+(r.outputBytes/1048576).toFixed(1)+' MiB</td><td>'+(r.elapsedMs/1000).toFixed(1)+' s</td><td>'+r.incrementalPrivateMiB.toFixed(1)+' MiB</td><td>'+r.cleanupDeltaFromLoadedMiB.toFixed(1)+' MiB</td></tr>').join('')+'</tbody></table>';
</script></main></body></html>`,
    "utf8",
  );
}

async function writeNativePeakCsv(base, nativeMemory) {
  if (!nativeMemory) return;
  const rows = [["kind", "phase", "sequence", "timestamp", "privateBytes", "rssBytes", "validSamples", "unavailableSamples", "processCount"]];
  for (const [kind, aggregates] of [["phase", nativeMemory.phases], ["graph-bucket", nativeMemory.graphBuckets]]) {
    for (const aggregate of aggregates) {
      for (const key of ["peak", "rssPeak", "last"]) {
        const row = aggregate[key]; if (!row) continue;
        rows.push([`${kind}-${key}`, aggregate.phase, row[0], row[1], row[3] ?? "", row[4] ?? "",
          aggregate.validSamples, aggregate.unavailableSamples, row[7]?.length ?? ""]);
      }
      for (const row of aggregate.unavailableExamples) {
        rows.push([`${kind}-unavailable`, aggregate.phase, row[0], row[1], "", "", aggregate.validSamples, aggregate.unavailableSamples, ""]);
      }
    }
  }
  await writeFile(`${base}-native-peaks.csv`, `${rows.map((row) => row.map(csvCell).join(",")).join("\n")}\n`, { encoding: "utf8", flag: "wx" });
}

function csvCell(value) {
  const text = String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function htmlEscape(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

async function killProcessTree(pid) {
  const row = launches.get(pid); if (!row) throw new Error("Refusing unrecorded PID cleanup");
  const current = await queryProcessIdentity(pid); if (!current) return;
  if (current.parentPid !== row.identity.parentPid || Math.abs(Date.parse(current.createdAt) - Date.parse(row.identity.createdAt)) >= 1)
    throw new Error("Refusing reused or unrelated PID cleanup");
  try {
    await execFileAsync("taskkill.exe", ["/PID", String(pid), "/T", "/F"], {
      windowsHide: true,
    });
  } catch {
    // The process may already have exited.
  }
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function removeWithRetries(target) {
  const identity = directories.get(target), current = await lstat(target, { bigint: true });
  if (!identity || !current.isDirectory() || current.isSymbolicLink() || await realpath(target) !== target ||
      current.dev !== identity.dev || current.ino !== identity.ino) throw new Error("Refusing replaced/unowned directory cleanup");
  for (let attempt = 1; attempt <= 12; attempt += 1) {
    try {
      await rm(target, { recursive: true, force: true, maxRetries: 2 });
      return;
    } catch (error) {
      if (
        !["EBUSY", "EPERM", "ENOTEMPTY"].includes(error?.code) ||
        attempt === 12
      ) {
        throw error;
      }
      await delay(500);
    }
  }
}
