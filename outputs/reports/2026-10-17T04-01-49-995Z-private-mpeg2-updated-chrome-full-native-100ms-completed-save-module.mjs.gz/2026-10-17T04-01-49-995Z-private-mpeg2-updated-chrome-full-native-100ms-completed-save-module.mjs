import { expect } from "file:///H:/Github%20Repositories/fileconverter/node_modules/@playwright/test/index.mjs";
import { inspectSsimSummary, requireNumericSsim } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/bounded-ssim-summary.mjs";
import { validateMatroskaMp4StreamTitle } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/matroska-mp4-stream-title.mjs";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { open, readFile, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import { validateCopiedAudioTiming } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/copied-audio-timing.mjs";
import { validateSmallMatroskaMp4Timeline } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/small-matroska-mp4-timeline.mjs";
import { createOwnedRuntimeScratch } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/owned-runtime-scratch.mjs";
const root = "H:\\Github Repositories\\fileconverter", exec = promisify(execFile), expectedMemoryBytes = 50331648, experimentBitRate = 4e6;
const title = "MPEG-2 caf\xE9 \u2014 \u97F3\u697D";
const adapters = [{ container: "mp4", source: "mkv", fixture: "hevc", sourceCodec: "hevc", frames: 96, profile: "mkv-to-mp4", destination: "direct" }];
const rows = [], bitrateAuditSamples = [], splitFinalSamples = [], asyncifyStorageSamples = [], inputReadFailureSamples = [], stackReserveSamples = [];
let work;
async function native(args, executable = "ffmpeg") {
  return exec(executable === "ffmpeg" ? "C:/ffmpeg/bin/ffmpeg.exe" : executable === "ffprobe" ? "C:/ffmpeg/bin/ffprobe.exe" : executable, args, { cwd: root, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
}
async function probe(file) {
  const { stdout } = await native(["-v", "error", "-count_frames", "-show_streams", "-show_format", "-show_chapters", "-of", "json", file], "ffprobe");
  return JSON.parse(stdout);
}
async function audioHashes(file) {
  const { stdout } = await native(["-v", "error", "-i", file, "-map", "0:a", "-c", "copy", "-f", "streamhash", "-hash", "sha256", "pipe:1"]);
  return stdout.trim().split(/\r?\n/).map((line) => line.split(",").at(-1)?.trim());
}
async function decodedAudioHashes(file) {
  const { stdout } = await native([
    "-v",
    "error",
    "-xerror",
    "-i",
    file,
    "-map",
    "0:a",
    "-c:a",
    "pcm_s32le",
    "-f",
    "streamhash",
    "-hash",
    "sha256",
    "pipe:1"
  ]);
  return stdout.trim().split(/\r?\n/).map((line) => line.split(",").at(-1)?.trim());
}
async function frameTimes(file) {
  const { stdout } = await native([
    "-v",
    "error",
    "-select_streams",
    "v:0",
    "-show_frames",
    "-show_entries",
    "frame=best_effort_timestamp_time",
    "-of",
    "json",
    file
  ], "ffprobe");
  const data = JSON.parse(stdout);
  return data.frames.map((frame) => Number(frame.best_effort_timestamp_time));
}
async function copiedAudioTimeline(file) {
  const { stdout } = await native([
    "-v",
    "error",
    "-select_streams",
    "a",
    "-show_packets",
    "-show_entries",
    "packet=stream_index,pts_time,dts_time,duration_time",
    "-of",
    "json",
    file
  ], "ffprobe");
  return JSON.parse(stdout).packets;
}
async function compareFrames(source, output, ordinal) {
  const align = ordinal ? "settb=1/1,setpts=N" : "setpts=PTS-STARTPTS";
  const { stderr } = await native([
    "-v",
    "info",
    "-i",
    source,
    "-i",
    output,
    "-filter_complex",
    `[0:v:0]${align}[ref];[1:v:0]${align}[out];[ref][out]ssim`,
    "-an",
    "-f",
    "null",
    "-"
  ]);
  const diagnostic = inspectSsimSummary(stderr);
  rows.push({ kind: "bounded-ssim-summary-before-assertion", ordinal, diagnostic });
  return requireNumericSsim(diagnostic);
}
async function validateConversion(page, adapter, reload = true) {
  const source = path.join(work, `${adapter.fixture}.${adapter.source}`);
  const output = path.join(work, `result.${adapter.container}`);
  const sourceBytes = (await stat(source)).size;
  expect(sourceBytes).toBeLessThan(16 * 1024 * 1024);
  const sourceSha256 = createHash("sha256").update(await readFile(source)).digest("hex");
  rows.push({ kind: "bitrate-input-before", bitRate: experimentBitRate, sourceBytes, sourceSha256 });
  const before = await probe(source);
  try {
    if (reload) await page.goto(adapter.destination === "direct" ? "/?test=1&directory=1" : "/?test=1");
    await page.waitForFunction(() => window.__WITHIN_TEST__?.getState().workerStatus === "ready");
    const fixtureInput = await page.context().newCDPSession(page);
    try {
      const document = await fixtureInput.send("DOM.getDocument");
      const { nodeId } = await fixtureInput.send("DOM.querySelector", { nodeId: document.root.nodeId, selector: '[data-testid="file-input"]' });
      expect(nodeId).toBeGreaterThan(0);
      await fixtureInput.send("DOM.setFileInputFiles", { nodeId, files: [source] });
    } finally {
      await fixtureInput.detach();
    }
    await page.locator('[data-testid="format-select"]').selectOption(adapter.profile);
    await expect(page.locator('[data-testid="convert-button"]')).toBeEnabled();
    await page.locator('[data-testid="convert-button"]').click();
    await page.waitForFunction(() => {
      const state2 = window.__WITHIN_TEST__?.getState().jobState;
      return state2 && !["idle", "running"].includes(state2);
    });
    const state = await page.evaluate(() => window.__WITHIN_TEST__.getState());
    expect(state.jobState, state.error ?? state.phase).toBe("complete");
    if (adapter.destination === "direct") expect(state.opfsName).toBeNull();
    else expect(state.opfsName).toBeTruthy();
    const outputName = state.opfsName ?? state.batchOutputNames?.[0];
    expect(outputName).toBeTruthy();
    if (adapter.destination === "direct") {
      expect(state.metrics?.wasmMemoryBytes).toBe(0);
      expect(state.metrics?.sharedArrayBufferBytes).toBe(4);
    } else expect(state.metrics?.wasmMemoryBytes).toBe(expectedMemoryBytes);
    expect(state.metrics?.peakWasmMemoryBytes).toBe(expectedMemoryBytes);
    expect(state.metrics?.maxReadChunkBytes).toBeLessThanOrEqual(256 * 1024);
    expect(splitFinalSamples[0].maximumMediaAvioWriteBytes).toBeLessThanOrEqual(256 * 1024);
    expect(state.metrics?.maxWriteChunkBytes).toBeLessThanOrEqual(adapter.destination === "direct" ? 512 * 1024 : 256 * 1024);
    expect(state.metrics?.peakQueuedBytes).toBeLessThanOrEqual(adapter.destination === "direct" ? 512 * 1024 : 256 * 1024);
    expect(state.metrics?.peakPendingOperations).toBeLessThanOrEqual(1);
    expect(state.metrics?.pendingOperations).toBe(0);
    expect(state.metrics?.queuedBytes).toBe(0);
    const outputHandle = await open(output, "wx");
    try {
      const size = await page.evaluate(async (name) => {
        const directory = await navigator.storage.getDirectory();
        return (await (await directory.getFileHandle(name)).getFile()).size;
      }, outputName);
      if (size > 16 * 1024 * 1024) throw new Error("Small independent validator exceeded 16 MiB.");
      for (let position = 0; position < size; position += 65536) {
        const bytes = await page.evaluate(async ({ name, position: position2 }) => {
          const directory = await navigator.storage.getDirectory();
          const file = await (await directory.getFileHandle(name)).getFile();
          return Array.from(new Uint8Array(await file.slice(position2, position2 + 65536).arrayBuffer()));
        }, { name: outputName, position });
        const buffer = Buffer.from(bytes);
        let written = 0;
        while (written < buffer.length) {
          const result = await outputHandle.write(buffer, written, buffer.length - written, position + written);
          if (!result.bytesWritten) throw new Error("Independent validator short write.");
          written += result.bytesWritten;
        }
      }
    } finally {
      await outputHandle.close();
    }
    expect(bitrateAuditSamples).toHaveLength(1);
    expect(bitrateAuditSamples[0].expectedBitRate).toBe(experimentBitRate);
    expect(bitrateAuditSamples[0].nativeSettingsMatch).toBe(1);
    const after = await probe(output);
    const packetText = (await native(["-v", "error", "-show_packets", "-show_data_hash", "sha256", "-of", "json", output], "ffprobe")).stdout;
    expect(Buffer.byteLength(packetText)).toBeLessThanOrEqual(1048576);
    const packetProof = JSON.parse(packetText);
    expect(packetProof.packets.length).toBeGreaterThanOrEqual(96);
    expect(packetProof.packets.length).toBeLessThanOrEqual(1024);
    for (const packet of packetProof.packets) expect(packet.data_hash).toMatch(/^SHA256:[a-f0-9]{64}$/);
    const decodedVideoHash = (await native([
      "-v",
      "error",
      "-xerror",
      "-i",
      output,
      "-map",
      "0:v:0",
      "-c:v",
      "rawvideo",
      "-fps_mode",
      "passthrough",
      "-f",
      "streamhash",
      "-hash",
      "sha256",
      "pipe:1"
    ])).stdout.trim();
    expect(decodedVideoHash).toMatch(/^0,v,SHA256=[a-f0-9]{64}$/);
    const boxFile = await open(output, "r"), boxHeader = Buffer.alloc(16);
    const topLevelBoxes = [];
    const boxFileBytes = (await stat(output)).size;
    try {
      let position = 0;
      while (position < boxFileBytes) {
        expect(topLevelBoxes.length).toBeLessThan(1024);
        const wanted = Math.min(16, boxFileBytes - position);
        const { bytesRead } = await boxFile.read(boxHeader, 0, wanted, position);
        expect(bytesRead).toBe(wanted);
        expect(bytesRead).toBeGreaterThanOrEqual(8);
        const type = boxHeader.toString("latin1", 4, 8);
        let size = boxHeader.readUInt32BE(0), headerBytes = 8;
        if (size === 1) {
          expect(bytesRead).toBe(16);
          const large = boxHeader.readBigUInt64BE(8);
          expect(large <= BigInt(Number.MAX_SAFE_INTEGER)).toBe(true);
          size = Number(large);
          headerBytes = 16;
        } else if (size === 0) size = boxFileBytes - position;
        expect(size).toBeGreaterThanOrEqual(headerBytes);
        expect(position + size).toBeLessThanOrEqual(boxFileBytes);
        topLevelBoxes.push({ type, position, size, headerBytes });
        position += size;
      }
      expect(position).toBe(boxFileBytes);
    } finally {
      await boxFile.close();
    }
    rows.push({
      kind: "independent-packet-order-proof",
      scope: "bounded-small-fixture-independent-validation-not-conversion",
      packets: packetProof.packets,
      decodedVideoHash,
      topLevelBoxes,
      outputBytes: boxFileBytes,
      maximumPackets: 1024,
      maximumProbeJsonBytes: 1048576,
      maximumBoxHeaderBytes: 16
    });
    rows.push({
      kind: "independent-pre-assertion-probes",
      sourceProbe: before,
      outputProbe: after,
      outputBytes: (await stat(output)).size,
      outputSha256: createHash("sha256").update(await readFile(output)).digest("hex"),
      metrics: state.metrics
    });
    const beforeVideo = before.streams.find((stream) => stream.codec_type === "video");
    const afterVideo = after.streams.find((stream) => stream.codec_type === "video");
    expect(beforeVideo.codec_name).toBe(adapter.sourceCodec);
    expect(afterVideo.codec_name).toBe("mpeg2video");
    expect(afterVideo.width).toBe(beforeVideo.width);
    expect(afterVideo.height).toBe(beforeVideo.height);
    expect(afterVideo.nb_read_frames).toBe(beforeVideo.nb_read_frames);
    expect(Number(afterVideo.nb_read_frames)).toBe(adapter.frames);
    expect(splitFinalSamples).toHaveLength(1);
    expect(splitFinalSamples[0].frames).toBe(adapter.frames);
    expect(splitFinalSamples[0].packets).toBe(adapter.frames);
    expect(splitFinalSamples[0].completedPackets).toBe(adapter.frames);
    expect(splitFinalSamples[0].copiedPixelBytes).toBeGreaterThan(0);
    expect(splitFinalSamples[0].copiedPacketBytes).toBeGreaterThan(0);
    const inputArt = before.streams.find((s) => s.disposition?.attached_pic);
    const outputArt = after.streams.find((s) => s.disposition?.attached_pic);
    expect(after.streams.filter((s) => s.disposition?.attached_pic)).toHaveLength(1);
    expect(after.streams.filter((s) => s.codec_type === "video" && !s.disposition?.attached_pic)).toHaveLength(1);
    expect(after.streams.every((s) => Boolean(s.codec_name)), "No undeclared empty/unknown tracks").toBe(true);
    expect(inputArt?.codec_name).toBe("png");
    expect(outputArt?.codec_name).toBe("png");
    expect(outputArt?.width).toBe(250);
    expect(outputArt?.height).toBe(140);
    const compressedArtworkHash = async (file, index) => (await native([
      "-v",
      "error",
      "-i",
      file,
      "-map",
      `0:${index}`,
      "-c",
      "copy",
      "-f",
      "hash",
      "-hash",
      "sha256",
      "pipe:1"
    ])).stdout.trim();
    const originalArtworkHash = await compressedArtworkHash(source, inputArt.index);
    expect(await compressedArtworkHash(output, outputArt.index)).toBe(originalArtworkHash);
    expect(afterVideo.tags?.encoder).toBe("Within FFmpeg MPEG-2");
    expect(beforeVideo.tags?.title).toBe("Primary caf\xE9 \u2014 \u97F3\u697D");
    const inputAudioTitles = before.streams.filter((s) => s.codec_type === "audio");
    const outputAudioTitles = after.streams.filter((s) => s.codec_type === "audio");
    expect(outputAudioTitles).toHaveLength(inputAudioTitles.length);
    rows.push({
      kind: "exact-stream-title-mapping",
      video: validateMatroskaMp4StreamTitle(beforeVideo.tags, afterVideo.tags),
      audio: inputAudioTitles.map((stream, index) => validateMatroskaMp4StreamTitle(stream.tags, outputAudioTitles[index].tags))
    });
    rows.push({
      kind: "attached-picture-preservation",
      status: "passed",
      inputArt,
      outputArt,
      compressedArtworkHash: originalArtworkHash,
      actualVideoEncoderTag: afterVideo.tags?.encoder
    });
    const audio = after.streams.filter((stream) => stream.codec_type === "audio");
    expect(audio.map((stream) => stream.codec_name)).toEqual(["aac", "aac"]);
    expect(audio.map((stream) => stream.tags?.language)).toEqual(["eng", "hin"]);
    expect(await audioHashes(output)).toEqual(await audioHashes(source));
    expect(after.format.tags.title).toBe(before.format.tags.title);
    const normalizedTags = (tags) => Object.fromEntries(
      Object.entries(tags).map(([key, value]) => [key.toLowerCase(), value])
    );
    const beforeTags = normalizedTags(before.format.tags), afterTags = normalizedTags(after.format.tags);
    expect(afterTags.website).toBe(beforeTags.website);
    expect(afterTags["custom_\u97F3\u697D"]).toBe(beforeTags["custom_\u97F3\u697D"]);
    expect(after.chapters).toHaveLength(1);
    expect(after.chapters[0].tags.title).toBe(before.chapters[0].tags.title);
    expect(Number(after.chapters[0].start_time)).toBeCloseTo(Number(before.chapters[0].start_time), 3);
    expect(Number(after.chapters[0].end_time)).toBeCloseTo(Number(before.chapters[0].end_time), 3);
    await native(["-v", "error", "-xerror", "-i", output, "-map", "0:v:0", "-map", "0:a", "-f", "null", "-"]);
    const sourceFrameTimes = await frameTimes(source);
    const outputFrameTimes = await frameTimes(output);
    const ssim = await compareFrames(source, output, false);
    const ordinalSsim = await compareFrames(source, output, true);
    rows.push({
      container: adapter.container,
      kind: "independent-frame-diagnostic",
      status: "diagnostic-not-accepted",
      sourceProbe: before,
      outputProbe: after,
      sourceFrameTimes,
      outputFrameTimes,
      timestampAlignedSsim: ssim,
      ordinalSsim,
      nativeFullDecodePassed: true,
      audioPacketHashes: await audioHashes(output),
      sourceBytes: (await stat(source)).size,
      outputBytes: (await stat(output)).size,
      outputSha256: createHash("sha256").update(await readFile(output)).digest("hex"),
      metrics: state.metrics
    });
    const sourceAudioTimeline = await copiedAudioTimeline(source);
    const outputAudioTimeline = await copiedAudioTimeline(output);
    rows.push({
      kind: "independent-copied-audio-timeline",
      sourceCodec: adapter.sourceCodec,
      sourceFormatStart: before.format.start_time,
      sourceFormatDuration: before.format.duration,
      outputFormatStart: after.format.start_time,
      outputFormatDuration: after.format.duration,
      sourceAudioTimeline,
      outputAudioTimeline
    });
    const sourceDecodedAudioHashes = await decodedAudioHashes(source);
    const outputDecodedAudioHashes = await decodedAudioHashes(output);
    rows.push({
      kind: "independent-decoded-audio",
      sourceCodec: adapter.sourceCodec,
      sourceDecodedAudioHashes,
      outputDecodedAudioHashes
    });
    const copiedAudioTiming = validateCopiedAudioTiming(
      sourceAudioTimeline,
      outputAudioTimeline,
      before.streams.filter((s) => s.codec_type === "audio").map((s) => s.index),
      audio.map((s) => s.index)
    );
    rows.push({ kind: "copied-audio-timing-passed", sourceCodec: adapter.sourceCodec, tracks: copiedAudioTiming });
    expect(outputDecodedAudioHashes, "Preserve complete decoded audible sample content and exact trim").toEqual(sourceDecodedAudioHashes);
    const presentationTimeline = validateSmallMatroskaMp4Timeline({
      sourceProbe: before,
      outputProbe: after,
      sourceFrames: sourceFrameTimes,
      outputFrames: outputFrameTimes,
      sourcePackets: sourceAudioTimeline,
      outputPackets: outputAudioTimeline,
      sourceDecodedAudioHashes,
      outputDecodedAudioHashes
    });
    rows.push({
      kind: "independent-presentation-timeline-passed",
      sourceCodec: adapter.sourceCodec,
      presentationTimeline
    });
    expect(outputFrameTimes).toHaveLength(sourceFrameTimes.length);
    for (let index = 0; index < sourceFrameTimes.length; index++) {
      expect(Number.isFinite(outputFrameTimes[index])).toBe(true);
      expect(Math.abs(outputFrameTimes[index] - sourceFrameTimes[index]), `frame ${index} presentation time`).toBeLessThanOrEqual(1e-3);
    }
    expect(ordinalSsim).toBeGreaterThanOrEqual(0.98);
    for (const [key, value] of Object.entries(beforeTags)) {
      expect(afterTags[key], `Preserve compatible container metadata ${key}`).toBe(value);
    }
    rows.push({
      container: adapter.container,
      status: "passed",
      sourceBytes: (await stat(source)).size,
      outputBytes: (await stat(output)).size,
      sourceCodec: beforeVideo.codec_name,
      destination: adapter.destination,
      outputCodec: afterVideo.codec_name,
      frames: afterVideo.nb_read_frames,
      audioTracks: audio.length,
      audioPacketHashes: await audioHashes(output),
      ssim: ordinalSsim,
      timestampAlignedSsim: ssim,
      sourceFrameTimes,
      outputFrameTimes,
      metrics: state.metrics,
      outputSha256: createHash("sha256").update(await readFile(output)).digest("hex"),
      warnings: state.warnings
    });
  } catch (error) {
    rows.push({
      container: adapter.container,
      status: "failed",
      error: String(error),
      state: await page.evaluate(() => window.__WITHIN_TEST__?.getState()).catch(() => null)
    });
    throw error;
  } finally {
    try {
      await page.evaluate(async () => {
        const directory = await navigator.storage.getDirectory();
        for await (const [name] of directory.entries()) await directory.removeEntry(name, { recursive: true });
        const remaining = [];
        for await (const [name] of directory.entries()) remaining.push(name);
        if (remaining.length) throw new Error("Candidate OPFS cleanup failed.");
      });
    } finally {
      try {
        const postBytes = (await stat(source)).size;
        expect(postBytes).toBeLessThan(16 * 1024 * 1024);
        const postSha256 = createHash("sha256").update(await readFile(source)).digest("hex");
        rows.push({ kind: "bitrate-input-after", bitRate: experimentBitRate, sourceBytes: postBytes, sourceSha256: postSha256 });
        expect(postBytes).toBe(sourceBytes);
        expect(postSha256).toBe(sourceSha256);
      } finally {
        await rm(output, { force: true });
      }
    }
  }
}
async function prepareCompletedSaveControl() {
  const owned = await createOwnedRuntimeScratch("completed-save-fixture-");
  work = owned.directory;
  let validated = 0;
  try {
    const metadata = path.join(work, "chapters.ffmetadata");
    await writeFile(metadata, `;FFMETADATA1
title=${title}
creation_time=2000-01-01T00:00:00.000000Z
WEBSiTE=example.invalid/caf\xE9
custom_\u97F3\u697D=Unicode retained
[CHAPTER]
TIMEBASE=1/1000
START=0
END=2000
title=Chapitre caf\xE9
`);
    const artwork = path.join(work, "artwork.png");
    await native([
      "-v",
      "error",
      "-f",
      "lavfi",
      "-i",
      "color=c=red:size=250x140",
      "-frames:v",
      "1",
      "-threads",
      "1",
      "-c:v",
      "png",
      artwork
    ]);
    const fixtures = [
      { name: "source", seconds: 2, codec: ["-c:v", "mpeg4", "-q:v", "2", "-bf", "0"] },
      { name: "hevc", seconds: 4, codec: [
        "-c:v",
        "libx265",
        "-preset",
        "ultrafast",
        "-crf",
        "18",
        "-threads:v",
        "1",
        "-x265-params",
        "pools=none:frame-threads=1:wpp=0:bframes=2:keyint=48:scenecut=0:log-level=error"
      ] }
    ];
    fixtures.splice(0, 1);
    for (const fixture of fixtures) {
      await native([
        "-v",
        "error",
        "-y",
        "-f",
        "lavfi",
        "-i",
        `testsrc2=size=${fixture.name === "hevc" || fixture.name === "cancel" ? "1920x804" : "320x240"}:rate=24:duration=${fixture.seconds}${fixture.name === "hevc" || fixture.name === "cancel" ? ",noise=alls=4:allf=t+u:all_seed=20261011" : ""}`,
        "-f",
        "lavfi",
        "-i",
        `sine=frequency=997:sample_rate=48000:duration=${fixture.seconds}`,
        "-f",
        "lavfi",
        "-i",
        `sine=frequency=440:sample_rate=48000:duration=${fixture.seconds}`,
        "-f",
        "ffmetadata",
        "-i",
        metadata,
        "-map",
        "0:v",
        "-map",
        "1:a",
        "-map",
        "2:a",
        "-map_metadata",
        "3",
        "-map_chapters",
        "3",
        ...fixture.codec,
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        "-metadata:s:a:0",
        "language=eng",
        "-metadata:s:a:1",
        "language=hin",
        "-metadata:s:a:0",
        "title=First caf\xE9",
        "-metadata:s:a:1",
        "title=Second \u97F3\u697D",
        "-metadata:s:v:0",
        "title=Primary caf\xE9 \u2014 \u97F3\u697D",
        "-avoid_negative_ts",
        "make_zero",
        "-fflags",
        "+bitexact",
        "-flags:v",
        "+bitexact",
        "-flags:a",
        "+bitexact",
        "-attach",
        artwork,
        "-metadata:s:t:0",
        "mimetype=image/png",
        "-metadata:s:t:0",
        "filename=cover.png",
        path.join(work, `${fixture.name}.mkv`)
      ]);
      expect((await stat(path.join(work, `${fixture.name}.mkv`))).size).toBeLessThan(16 * 1024 * 1024);
    }
  } catch (error) {
    await owned.close();
    throw error;
  }
  const report = () => ({
    scope: "one-small-complete-production-conversion-and-successful-final-save-handoff-only",
    fixtureDirectory: work,
    successfulFixtureValidations: validated,
    rows: [...rows],
    fullOriginalAcceptance: false,
    publicAcceptance: false,
    physicalWorkerMemoryReleaseProven: false
  });
  return {
    report,
    async run(page) {
      const capture = (message) => {
        const text = message.text();
        for (const [prefix, records] of [
          ["WITHIN_MPEG2_BITRATE_AUDIT ", bitrateAuditSamples],
          ["WITHIN_MPEG2_SPLIT_FINAL ", splitFinalSamples],
          ["WITHIN_ASYNCIFY_STORAGE_FINAL ", asyncifyStorageSamples],
          ["WITHIN_INPUT_READ_FAILURE ", inputReadFailureSamples],
          ["WITHIN_MPEG2_STACK_RESERVE ", stackReserveSamples]
        ]) {
          if (text.startsWith(prefix)) {
            expect(text.length).toBeLessThanOrEqual(2048);
            expect(records.length).toBeLessThan(16);
            records.push(JSON.parse(text.slice(prefix.length)));
          }
        }
      };
      page.on("console", capture);
      try {
        await validateConversion(page, adapters[0], false);
        validated = 1;
        return report();
      } finally {
        page.off("console", capture);
      }
    },
    async close() {
      await owned.close();
      return { fixtureDirectory: work, removed: true };
    }
  };
}
export {
  prepareCompletedSaveControl
};
