import {makeLateSlotBuildWorkflow} from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/late-slot-build-workflow.mjs";
// Full protected source, ONE page navigation; normal production worker recycling between repeats.
// Historical redundant-navigation driver remains unchanged for its executed source pins.
import assert from "node:assert/strict";
import { chromium } from "file:///H:/Github%20Repositories/fileconverter/node_modules/@playwright/test/index.mjs";
import { execFile, spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { access, mkdir, readFile, readdir, stat, statfs, writeFile } from "node:fs/promises";
import { createServer } from "node:net";
import path from "node:path";
import { promisify } from "node:util";
import { sampleChromiumTree, stableWindow } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/chromium-private-memory.mjs";
import { startParallelMemoryObserver } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/parallel-memory-observer.mjs";
import { connectRealmSampler } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/cdp-realm-memory.mjs";
import { classifyPrivateRequest } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/private-browser-request.mjs";
import { readWasmMemoryLimits } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/wasm-memory-limits.mjs";
import { createOwnedRuntimeScratch, finishOwnedCleanup } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/owned-runtime-scratch.mjs";
import { cancelBrowserConversionBeforeCleanup } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/cancel-browser-conversion-before-cleanup.mjs";

const root = "H:\\Github Repositories\\fileconverter", MiB = 1024 ** 2;
const candidateName = process.env.WITHIN_MPEG2_SPLIT_CANDIDATE_DIR ?? "mpeg2-split-pipeline-output";
const diagnosticOnly = false; // Uninstrumented real split conversion, all three stress runs required.
if (!/^(mpeg2-split-pipeline-output|mpeg2-split-pipeline-[0-9]{8,})$/.test(candidateName))
  throw new Error("Private candidate must remain in its named repository-local tool slot");
const source = path.join(root, "test.mkv"), candidate = path.join(root, "work", candidateName);
const expectedSourceBytes = 2958573265;
const expectedSourceHash = "31f36695b5b44c62125a9e4264e84dc085accd21c02cc3487aae597f54b9db34";
const baseExec = promisify(execFile), startedAt = Date.now();
let runtime, chrome, server, browser, context, page, observer, realms, staged = false;
import { startNativeBudgetFailureObserver } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/native-budget-failure-observer.mjs";
import { createBoundedDomCounterSampler } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/bounded-dom-counters.mjs";
import { observeOwnedProcessExit } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/owned-process-exit-observation.mjs";
let domSession, domSampler, domSamplerReport = null, nativeFailureCapture = null;
import { startBoundedRendererAttribution } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/bounded-renderer-attribution.mjs";
import { createIndependentBlinkSessions } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/independent-blink-sessions.mjs";
import { createConversionJsAllocation } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/conversion-js-allocation-duration-bound.mjs";
let conversionJs=null,conversionJsReport=null;
import { captureLiveMemoryInfra } from "file:///H:/Github%20Repositories/fileconverter/scripts/lib/live-memory-infra.mjs";
const liveMemoryRecords=[]; let liveMemoryPending=null, liveMemoryMidpoint=false;
async function captureLive(phase,processes=null){
  if(liveMemoryPending)await liveMemoryPending;
  assert.ok(liveMemoryRecords.length<3,"Three live dump cap; no queued trace history");
  const row={phase,before:null,after:null,result:null,error:null};liveMemoryRecords.push(row);
  const operation=(async()=>{
    try{
      row.before=await page.evaluate(()=>window.__WITHIN_TEST__?.getState()??null);
      assert.equal(row.before?.jobState,phase==="before-conversion"?"idle":"running","Never label a cancelled or closed worker as a live conversion dump");
      processes??=(await sampleChromiumTree(chrome.pid)).processes;
      row.result=await captureLiveMemoryInfra({session:await browser.newBrowserCDPSession(),phase,processes,
        archivePath:path.join(reports,"2026-10-08T22-41-09-984Z"+"-live-memory-"+phase+".json.gz")});
      row.after=await page.evaluate(()=>window.__WITHIN_TEST__?.getState()??null);
    }catch(error){row.error=String(error).slice(0,1024);throw error;}
  })();liveMemoryPending=operation;
  try{await operation;return row.result;}finally{liveMemoryPending=null;}
}

const progressProbe = {"mode":"baseline","checkpointOutputBytes":67108864,"maximumConversionMs":120000,"expectedAsset":{"url":"/assets/ConverterApp-BuCmNpWV.js","bytes":315630,"sha256":"e018d973a604af5f4a678860c08cea5e3c6f587a952b933799566dbaa2203172"},"checkpointReached":false,"beforeCancellation":null,"afterCancellation":null,"cancellation":null,"profilerClosed":false,"performanceBefore":null,"performanceAfter":null,"chromeLauncherSha256":null,"chromeLibrarySha256":null,"viewport":{"width":1280,"height":900},"originalFullSourceAcceptance":false,"publicAcceptance":false,"conversionSpeedAcceptance":false};
let rendererAttribution=null,rendererAttributionResult=null;
const quiescedBudgetCapture={startedAt:null,workerClosedAt:null,oldWorkerCloseObserved:null,
  oldWorkerUrl:null,stateBefore:null,stateAfter:null,cancellation:null,noForcedGc:true,
  noTestWorkerTermination:true,allocationObjectOrCallsite:null,publicAcceptance:false};
let completedReport, completedReportPath; export { completedReport, completedReportPath };
const cssCandidate = { css: "\n.control-grid,.encoding-options-grid,.source-inspection dl,.live-metrics{display:flex;flex-wrap:wrap}\n.control-grid>*{flex:0 0 calc((100% - .8rem)/2);min-width:0}\n.encoding-options-grid>*{flex:0 0 calc((100% - 1.3rem)/3);min-width:0}\n.source-inspection dl>*{flex:0 0 calc((100% - 1rem)/2);min-width:0}\n.live-metrics>*{flex:0 0 calc((100% - 1.4rem)/3);min-width:0}\n.conversion-plan>ul{display:flex;flex-direction:column}\n.conversion-plan>ul>li{display:flex;align-items:flex-start}\n.conversion-plan>ul>li>span:first-child{flex:0 0 5.25rem}\n.conversion-plan>ul>li>span:last-child{display:flex;flex:1;flex-direction:column;min-width:0}\n@media(max-width:680px){.control-grid>*,.encoding-options-grid>*{flex-basis:100%}.live-metrics>*{flex-basis:calc((100% - .7rem)/2)}}\n\n.matrix{display:flex;flex-wrap:wrap}\n.matrix>article{flex:0 0 calc((100% - 1.5rem)/3);min-width:0;display:flex;flex-wrap:wrap}\n.matrix>article>span{flex:1 1 0;min-width:0}\n.matrix>article>b{flex:0 0 auto}\n.matrix>article>small{flex:0 0 100%;min-width:0}\n.matrix>.matrix-empty{flex:0 0 100%}\n@media(max-width:980px){.matrix>article{flex-basis:calc((100% - .75rem)/2)}}\n@media(max-width:680px){.matrix>article{flex-basis:100%}}\n\n.hero{display:flex}\n.hero-copy{flex:0 1 auto;width:calc((100% - clamp(3rem,8vw,8rem))*.4623655913978495);min-width:0}\n.hero>.converter-card{flex:0 0 auto;width:calc((100% - clamp(3rem,8vw,8rem))*.5376344086021505);min-width:30rem}\n@media(max-width:980px){.hero{flex-direction:column;align-items:stretch}.hero-copy{flex:none;width:100%}.hero>.converter-card{flex:none;min-width:0;width:100%}}\n", staticAssets: [], interceptionError: null,
  sourceChanged: false, enginesChanged: false, publicAcceptance: false };
const abortDiagnostic={records:[],maximumRecords:8,queuedRecords:0,stagedAdapters:[],captureError:null,
  noNormalNativeCalls:true,noForcedGc:true,noDebuggerPause:true,syntheticMallocInvoked:false,
  originalFailureCause:null,publicAcceptance:false,acceptanceWithheldForDiagnostic:true};
let startupSettlement = null;
let blankBaseline = null, loadedIdle = null, sourceProbe = null, browserVersion = null;
let lastState = null, failure = null, nativeMemory = null;
const samples = [], runs = [], logs = [], forbiddenRequests = [], browserLocalRequests = [];
let samplesEvicted = 0;
const cleanup = { mediaProfileRuntimeRemoved: false, generatedDistRestored: false,
  protectedFixtureUnchanged: false, observerStopped: false, sampledChromeRootStopped: false };
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const exec = (file, args, options = {}) => baseExec(file, args,
  { cwd: root, windowsHide: true, env: runtime?.env ?? process.env, ...options });
const shaFile = async (file) => {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(file, { highWaterMark: MiB })) hash.update(chunk);
  return hash.digest("hex");
};
const native = (args, executable = "ffmpeg") => exec(executable, args,
  { timeout: 30 * 60_000, maxBuffer: 32 * MiB });
async function probe(file, count = false) {
  const { stdout } = await native(["-v", "error", ...(count ? ["-count_frames"] : []),
    "-show_streams", "-show_format", "-show_chapters", "-of", "json", file], "ffprobe");
  return JSON.parse(stdout);
}
async function frameTimes(file) {
  // Independent validator outside Chromium, with a fixed 32MiB stdout cap.
  const { stdout } = await native(["-v", "error", "-select_streams", "v:0", "-show_frames",
    "-show_entries", "frame=best_effort_timestamp_time", "-of", "csv=p=0", file], "ffprobe");
  return stdout.split(/\r?\n/).filter((line) => /^-?\d+(?:\.\d+)?(?:,|$)/.test(line))
    .map((line) => Number(line.split(",")[0]));
}
async function audioHashes(file) {
  const { stdout } = await native(["-v", "error", "-i", file, "-map", "0:a", "-c", "copy",
    "-f", "streamhash", "-hash", "sha256", "pipe:1"]);
  return stdout.trim().split(/\r?\n/).map((line) => line.split(",").at(-1).trim());
}
async function verifySource() {
  assert.equal((await stat(source)).size, expectedSourceBytes);
  assert.equal(await shaFile(source), expectedSourceHash);
}
async function takeSample(phase) {
  observer.healthy(); observer.setPhase(phase);
  const begin = Date.now();
  let tree = { privateBytes: null, rssBytes: null, processes: null }, sampleError = null;
  try { tree = await sampleChromiumTree(chrome.pid); } catch (error) { sampleError = String(error); }
  const dom = await domSampler.sample(phase);
  const state = await page.evaluate(() => window.__WITHIN_TEST__?.getState() ?? null).catch(() => null);
  if (state) lastState = state;
  const storageEstimate = await page.evaluate(async () => {
    const value = await navigator.storage.estimate(); return { usage: value.usage ?? null, quota: value.quota ?? null };
  }).catch(() => null);
  const sample = { timestamp: new Date(begin).toISOString(), elapsedMs: begin - startedAt,
    phase, ...tree, sampleError, dom, metrics: state?.metrics ?? null, jobState: state?.jobState ?? null,
    storageEstimate, cdpIsolateHeaps: await realms.sample(), samplerElapsedMs: Date.now() - begin };
  if (samples.length === 1024) { samples.shift(); samplesEvicted++; }
  samples.push(sample); return sample;
}
async function stable(phase, maximumBytes = Infinity) {
  const local = [], deadline = Date.now() + 45_000;
  while (Date.now() < deadline) {
    local.push(await takeSample(phase));
    const result = stableWindow(local);
    if (result && result.privateBytes <= maximumBytes) return result;
    await delay(1000);
  }
  throw new Error(`${phase} did not stabilize; no baseline substitution`);
}
async function waitFor(operation, label) {
  const deadline = Date.now() + 30_000;
  while (Date.now() < deadline) {
    try { const value = await operation(); if (value) return value; } catch { /* startup retry only */ }
    await delay(250);
  }
  throw new Error(`${label} startup deadline exceeded`);
}
async function outputPayload(bytes) {
  const directories = [path.join(runtime.directory, "profile")], matches = [];
  let inspected = 0;
  while (directories.length) {
    for (const entry of await readdir(directories.pop(), { withFileTypes: true })) {
      assert.ok(++inspected <= 20000, "Profile inventory cap");
      assert.ok(!entry.isSymbolicLink(), "Profile must not escape owned scratch");
      // Dirent.parentPath is the actual directory enumerated, not a guessed root.
      const file = path.join(entry.parentPath, entry.name);
      if (entry.isDirectory()) directories.push(file);
      else if (entry.isFile() && (await stat(file)).size === bytes) matches.push(file);
    }
  }
  assert.equal(matches.length, 1, "Unique real disk-backed output required"); return matches[0];
}
async function emptyOpfs() {
  return page.evaluate(async () => {
    const directory = await navigator.storage.getDirectory();
    for await (const [name] of directory.entries()) await directory.removeEntry(name, { recursive: true });
    const names = []; for await (const [name] of directory.entries()) names.push(name);
    if (names.length) throw new Error("OPFS cleanup failed"); return names;
  });
}
async function stopOwned(child) {
  if (child?.pid && child.exitCode == null && child.signalCode == null) {
    await exec("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], { timeout: 15000 });
  }
}
const manifest = JSON.parse(await readFile(path.join(candidate, "build-manifest.json"), "utf8"));
const splitFinalSamples = [];
const nativeStackSamples = [];
const allocatorSamples = [];
let allocatorSamplesEvicted = 0;
assert.equal(manifest.decoderMemoryBytes, 32 * MiB);
assert.equal(manifest.encoderMemoryBytes, 16 * MiB);
assert.equal(manifest.aggregateWasmMemoryBytes, 48 * MiB); assert.equal(manifest.allowMemoryGrowth, false);
for (const [file, hash] of Object.entries(manifest.artifacts)) assert.equal(await shaFile(path.join(candidate, file)), hash);
for (const [file, hash] of Object.entries(manifest.sources)) {
  if(file===".github/workflows/reproduce-ffmpeg-nondocker.yml") {
    const canonical=await readFile(path.join(root,file),"utf8");
    assert.equal(createHash("sha256").update(canonical).digest("hex"),"cda0b434adc7dd36109b4a2cc63fe726a507889cf6d1c0f5862d5d78dbf5c965");
    assert.equal(hash,"d280472ff4421e744aa767d9d690a7b73d82a26951bb71446c3fb3d55cacd78d");
    assert.equal(createHash("sha256").update(makeLateSlotBuildWorkflow(canonical)).digest("hex"),hash);
  } else assert.equal(await shaFile(path.join(root,file)),hash,file);
}
if (manifest.allocatorInstrumentationSha256)
  assert.equal(await shaFile(path.join(root, "scripts/lib/mpeg2-allocator-instrumentation.mjs")), manifest.allocatorInstrumentationSha256);
if (manifest.stackReserveAdapterSha256)
  assert.equal(await shaFile(path.join(root, "scripts/lib/mpeg2-stack-reserve-adapter.mjs")), manifest.stackReserveAdapterSha256);
const actualWasmMemoryLimits = {
  decoderMux: readWasmMemoryLimits(await readFile(path.join(candidate, "within-mpeg2-split.wasm"))),
  encoder: readWasmMemoryLimits(await readFile(path.join(candidate, "split-encoder.wasm"))),
};
assert.deepEqual(actualWasmMemoryLimits.decoderMux, [{ imported: true, initialPages: 512, maximumPages: 512, shared: true }]);
assert.deepEqual(actualWasmMemoryLimits.encoder, [{ imported: true, initialPages: 256, maximumPages: 256, shared: true }]);
const sourceFiles = ["scripts/diagnose-live-memory.mjs","scripts/lib/live-memory-infra.mjs","scripts/lib/live-memory-probe-recipe.mjs","tests/live-memory-infra.test.mjs","tests/live-memory-probe.test.mjs","scripts/diagnose-stable-ui-real-progress.mjs","scripts/lib/stable-ui-progress-probe-recipe.mjs","tests/stable-ui-progress-probe.test.mjs","scripts/lib/conversion-js-allocation-duration-bound.mjs","scripts/mpeg2-js-progress-original.mjs","scripts/lib/mpeg2-js-progress-recipe.mjs","scripts/lib/conversion-js-allocation.mjs","scripts/lib/bounded-js-allocation.mjs","evidence/ui-js-allocation-tooling-2026-10-08.json","scripts/mpeg2-hero-width-original-memory.mjs","scripts/lib/mpeg2-hero-width-original-recipe.mjs","scripts/lib/ui-hero-width-flex-layout-recipe.mjs","scripts/lib/ui-hero-flex-layout-recipe.mjs","scripts/validate-mpeg2-hero-width-goldens.mjs","scripts/lib/mpeg2-hero-width-golden-recipe.mjs","scripts/freeze-mpeg2-hero-width-goldens.mjs","evidence/2026-10-08T11-43-06-973Z-mpeg2-hero-width-golden-validation.json","evidence/2026-10-08T11-39-44-157Z-ui-hero-width-flex-layout-analysis.json","scripts/mpeg2-matrix-original-memory.mjs","scripts/lib/mpeg2-matrix-original-recipe.mjs","scripts/lib/ui-matrix-flex-layout-recipe.mjs","scripts/validate-mpeg2-matrix-goldens.mjs","scripts/lib/mpeg2-matrix-golden-recipe.mjs","scripts/freeze-mpeg2-matrix-goldens.mjs","scripts/freeze-mpeg2-matrix-goldens-compact.mjs","evidence/2026-10-08T08-50-53-044Z-mpeg2-matrix-golden-validation.json","evidence/2026-10-08T08-38-48-399Z-ui-matrix-flex-layout-analysis.json","scripts/mpeg2-late-allocator-original-memory.mjs","scripts/lib/mpeg2-late-allocator-original-recipe.mjs",
"scripts/lib/mpeg2-late-allocator-abort-adapter.mjs","scripts/lib/late-pool-allocator-abort-capture.mjs","scripts/lib/dlmalloc-free-header-inspection.mjs",
"scripts/lib/mpeg2-late-abort-adapter.mjs","scripts/lib/late-pool-abort-capture.mjs","scripts/lib/late-refstruct-abort-snapshot.mjs","scripts/lib/late-slot-build-workflow.mjs",
"scripts/stage-mpeg2-late-allocator-abort.mjs","scripts/check-late-pool-allocator-abort-control.mjs",
"evidence/late-pool-allocator-abort-control-2026-10-08.json","evidence/mpeg2-late-dlmalloc-layout-2026-10-08.json",
"scripts/validate-mpeg2-late-allocator-abort-goldens.mjs","scripts/validate-mpeg2-late-allocator-abort-goldens-origin-bound.mjs","scripts/freeze-mpeg2-late-allocator-abort-goldens.mjs",
"evidence/mpeg2-late-allocator-abort-golden-validation-2026-10-08.json","scripts/mpeg2-quiesced-budget-memory.mjs", "scripts/lib/mpeg2-quiesced-budget-recipe.mjs", "scripts/lib/partial-blink-attribution-recipe.mjs", "scripts/lib/partial-memory-infra-attribution.mjs", "scripts/lib/partial-complete-blink-heap-summary.mjs", "scripts/lib/partial-largest-blink-type-summary.mjs", "scripts/lib/independent-blink-sessions.mjs", "scripts/lib/bounded-renderer-attribution.mjs", "scripts/lib/largest-blink-attribution-recipe.mjs", "scripts/lib/detailed-blink-attribution-recipe.mjs", "scripts/lib/complete-blink-heap-summary.mjs", "scripts/lib/memory-infra-attribution.mjs", "evidence/partial-blink-blocked-control-verification-2026-10-08.json", "evidence/partial-blink-quiesced-control-verification-2026-10-08.json", "evidence/mpeg2-staged-abort-terminal-analysis-2026-10-08.json", "scripts/mpeg2-staged-abort-original-memory.mjs", "scripts/lib/mpeg2-staged-abort-original-recipe.mjs", "scripts/stage-mpeg2-late-allocator-abort.mjs", "scripts/lib/mpeg2-abort-original-recipe.mjs", "scripts/lib/bounded-wasm-abort-capture.mjs", "scripts/validate-mpeg2-split-abort-goldens.mjs", "tests/browser/mpeg2-split-direct-candidate.spec.ts", "evidence/mpeg2-abort-golden-regression-2026-10-08.json", "evidence/mpeg2-abort-preconversion-analysis-2026-10-08.json", "evidence/wasm-abort-capture-control-origin-checked-2026-10-08.json", "scripts/mpeg2-flex-original-memory.mjs", "scripts/lib/mpeg2-flex-original-recipe.mjs", "scripts/lib/ui-flex-layout-recipe.mjs", "scripts/lib/bounded-dom-counters.mjs", "scripts/lib/host-memory-preflight.mjs", "scripts/lib/native-budget-failure-observer.mjs", "scripts/lib/owned-process-exit-observation.mjs", "evidence/ui-flex-layout-2026-10-07.json", "evidence/ui-grid-layout-2026-10-07.json", "evidence/ui-flex-layout-comparison-2026-10-07.json", "evidence/ui-flex-layout-analysis-2026-10-07.json", "app/globals.css", "scripts/mpeg2-static-ui-original-memory.mjs", "scripts/lib/mpeg2-static-ui-original-recipe.mjs", "app/converter/ConverterApp.tsx", "scripts/lib/static-format-matrix-recipe.mjs", "evidence/ui-matrix-benchmark-2026-10-07.json", "evidence/ui-matrix-golden-regression-2026-10-07.json", "evidence/ui-privacy-offline-2026-10-06T21-40-31-968Z.json", "scripts/mpeg2-settled-original-memory.mjs", "scripts/lib/mpeg2-settled-original-recipe.mjs", "scripts/lib/mpeg2-aligned-progress-recipe.mjs", "evidence/blank-chromium-lifecycle-2026-10-06.json", "evidence/mpeg2-aligned-full-failure-2026-10-06.json", "scripts/mpeg2-split-single-navigation-memory.mjs", "scripts/stage-mpeg2-split-direct.mjs",
  "scripts/lib/parallel-memory-observer.mjs", "scripts/lib/native-memory-peaks.mjs",
  "scripts/lib/chromium-private-memory.mjs", "scripts/lib/cdp-realm-memory.mjs",
  "scripts/lib/persistent-chromium-memory.mjs", "scripts/lib/windows-tree-monitor.cs",
  "scripts/lib/windows-tree-monitor.ps1", "scripts/lib/owned-runtime-scratch.mjs",
  "scripts/lib/mpeg2-stack-reserve-adapter.mjs", "scripts/lib/mpeg2-split-session.mjs",
  "scripts/lib/cancel-browser-conversion-before-cleanup.mjs"];
const sourceHashes = Object.fromEntries(await Promise.all(sourceFiles.map(async (file) => [file, await shaFile(path.join(root, file))])));
const reports = path.join(root, "outputs/reports"); await mkdir(reports, { recursive: true });
const reportBase = path.join(reports, `${new Date().toISOString().replaceAll(/[:.]/g, "-")}-private-mpeg2-live-memory-native-100ms`);
try {
  await verifySource();
  const disk = await statfs(root);
  assert.ok(disk.bavail * disk.bsize >= 32 * 1024 ** 3, "32GiB repository-local disk preflight required");
  runtime = await createOwnedRuntimeScratch("mpeg2-live-memory-runtime-");
  const profile = path.join(runtime.directory, "profile"); await mkdir(profile);
  sourceProbe = await probe(source);
  assert.equal(sourceProbe.streams[0].width, 1920); assert.equal(sourceProbe.streams[0].height, 804);
  await exec(process.execPath, ["scripts/stage-mpeg2-late-allocator-abort.mjs", "stage"]); staged = true;
  for(const name of ["within-remux.mjs","within-mpeg4.mjs","within-direct.mjs"]){
    const file=path.join(root,"dist/client/engines/remux",name);
    assert.equal((await stat(file)).size,18330);
    assert.equal(await shaFile(file),"020b3bdc7d3902367358094a8db2d1fa990691443bdc4ec465c5b0ae34792837","Exact controlled staged abort adapter");
    abortDiagnostic.stagedAdapters.push({name,bytes:18330,sha256:"020b3bdc7d3902367358094a8db2d1fa990691443bdc4ec465c5b0ae34792837"});
  }
  const port = await new Promise((resolve, reject) => {
    const listener = createServer(); listener.once("error", reject);
    listener.listen(0, "127.0.0.1", () => { const port = listener.address().port;
      listener.close((error) => error ? reject(error) : resolve(port)); });
  });
  const origin = `http://127.0.0.1:${port}`, query = `${origin}/?test=1&directory=1`;
  server = spawn(process.execPath, ["node_modules/wrangler/bin/wrangler.js", "dev", "--config",
    "dist/server/wrangler.json", "--port", String(port)], { cwd: root, env: runtime.env, windowsHide: true, stdio: "ignore" });
  await waitFor(async () => (await fetch(origin)).ok, "production server");
  const launchHost = await (await import("file:///H:/Github%20Repositories/fileconverter/scripts/lib/host-memory-preflight.mjs")).inspectStressHostMemory();
  progressProbe.launchHost = launchHost; assert.equal(launchHost.safeToStart, true);
  chrome = spawn("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe", ["--headless=new", "--remote-debugging-port=0",
    `--user-data-dir=${profile}`, "--no-first-run", "--no-default-browser-check", "--disable-background-networking",
    "--disable-component-update", "--disable-default-apps", "--disable-domain-reliability", "--disable-extensions",
    "--disable-features=MediaRouter,OptimizationGuideModelDownloading,OptimizationHints,OptimizationTargetPrediction",
    "--disable-sync", "--metrics-recording-only", "about:blank"], { cwd: root, env: runtime.env, windowsHide: true, stdio: "ignore" });
  observer = await startNativeBudgetFailureObserver(chrome.pid, runtime.directory, {
    getBlankBaseline: () => blankBaseline,
    onFailure: async event => {
      let result;
      try{result=await captureLive("native-budget-"+event.after.sequence,event.after.processes);}
      finally{quiescedBudgetCapture.cancellation=await cancelBrowserConversionBeforeCleanup(page);}
      return result;
    },
  });
  const debugPort = await waitFor(async () => Number((await readFile(path.join(profile, "DevToolsActivePort"), "utf8")).split(/\r?\n/)[0]), "Chrome");
  browser = await chromium.connectOverCDP(`http://127.0.0.1:${debugPort}`);
  browserVersion = browser.version(); context = browser.contexts()[0]; page = context.pages()[0];
  await page.setViewportSize(progressProbe.viewport);
  progressProbe.chromeLauncherSha256 = await shaFile("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
  progressProbe.chromeLibrarySha256 = await shaFile(path.join("C:\\Program Files\\Google\\Chrome\\Application",browserVersion,"chrome.dll"));
  domSession = await context.newCDPSession(page);
  await domSession.send("Performance.enable", { timeDomain: "threadTicks" });
  const domTarget = await domSession.send("Target.getTargetInfo");
  domSampler = createBoundedDomCounterSampler(domSession, { targetId: domTarget.targetInfo.targetId });
  const version = await (await fetch(`http://127.0.0.1:${debugPort}/json/version`)).json();
  realms = await connectRealmSampler(version.webSocketDebuggerUrl, origin);
  await context.tracing.start({ screenshots: false, snapshots: false, sources: false });
  context.on("request", (request) => {
    let frameUrl = null; try { frameUrl = request.frame().url(); } catch { /* worker request */ }
    const detail = { url: request.url(), method: request.method(), postData: request.postData(), frameUrl,
      serviceWorkerUrl: request.serviceWorker()?.url() ?? null };
    const kind = classifyPrivateRequest(detail, origin);
    if (kind === "forbidden" && forbiddenRequests.length < 32) forbiddenRequests.push(detail);
    if (kind === "browser-local" && browserLocalRequests.length < 32) browserLocalRequests.push(detail);
  });
  page.on("console", (message) => {
    const text = message.text().slice(0, 2048);
    for (const [prefix, records] of [["WITHIN_MPEG2_SPLIT_FINAL ", splitFinalSamples], ["WITHIN_MPEG2_STACK_RESERVE ", nativeStackSamples]]) {
      if (text.startsWith(prefix) && records.length < 16) {
        try { records.push(JSON.parse(text.slice(prefix.length))); } catch { /* missing telemetry never means zero */ }
      }
    }
    if (diagnosticOnly && text.startsWith("WITHIN_MPEG2_ALLOCATOR ")) {
      try {
        const sample = JSON.parse(text.slice("WITHIN_MPEG2_ALLOCATOR ".length));
        // Independent budgets:96 heap +128 pool +16 five-pool release events.
        if (allocatorSamples.length === 240) { allocatorSamples.shift(); allocatorSamplesEvicted++; }
        allocatorSamples.push(sample);
      } catch { /* retain the bounded malformed line in logs, never fabricate telemetry */ }
    }
    if (logs.length === 32) logs.shift(); logs.push(text);
  });
    page.on("console", message => {
    const text=message.text(),prefix="WITHIN_BOUNDED_WASM_ABORT ";
    if(!text.startsWith(prefix))return;
    try{
      assert.ok(text.length<=65536);assert.ok(abortDiagnostic.records.length<8);
      const row=JSON.parse(text.slice(prefix.length));
      assert.ok(["decoder","encoder"].includes(row.role));
      assert.ok(typeof row.reason==="string"&&row.reason.length<=512);
      assert.ok(typeof row.stack==="string"&&row.stack.length<=8192);
      assert.equal(row.failedIndividualAllocationBytes,null);assert.equal(row.heapLiveBytes,null);
      abortDiagnostic.records.push(row);
    }catch(error){abortDiagnostic.captureError=String(error).slice(0,1024);}
  });
  await page.goto("about:blank");
  startupSettlement = { minimumMs: 300000, startedAt: Date.now(), earlyWindow: null,
    pageStayedBlank: true, flagsChanged: false, processesExcluded: 0, baselineInflated: false };
  const startupSamples = [];
  while (Date.now() - startupSettlement.startedAt < startupSettlement.minimumMs) {
    assert.equal(page.url(), "about:blank");
    assert.ok(startupSamples.length < 256, "Startup observation sample cap");
    startupSamples.push(await takeSample("blank-startup-settle"));
    startupSettlement.earlyWindow ??= stableWindow(startupSamples);
    await delay(2000);
  }
  blankBaseline = await stable("blank-baseline");
  assert.ok(startupSettlement.earlyWindow, "Actual early startup window required for no-inflation guard");
  assert.ok(blankBaseline.privateBytes <= startupSettlement.earlyWindow.privateBytes,
    "Settled blank exceeds early blank; cannot substitute a larger baseline");
  startupSettlement.finishedAt = Date.now();
  startupSettlement.actualMs = startupSettlement.finishedAt - startupSettlement.startedAt;
  process.stdout.write(`EARLY stable blank: ${(blankBaseline.privateBytes / MiB).toFixed(3)}MiB. Full original source, no resizing.\n`);
  await context.route(origin + "/assets/*.css", async route => {
    try {
      assert.equal(cssCandidate.staticAssets.length, 0, "One small static stylesheet only");
      const response = await route.fetch(), css = await response.text();
      assert.ok(Buffer.byteLength(css) < MiB && css.includes(".control-grid"));
      const body = css + cssCandidate.css;
      const hash = data => createHash("sha256").update(data).digest("hex");
      cssCandidate.staticAssets.push({ url: route.request().url(), beforeBytes: Buffer.byteLength(css), beforeSha256: hash(css),
        afterBytes: Buffer.byteLength(body), afterSha256: hash(body) });
      await route.fulfill({ response, body });
    } catch (error) { cssCandidate.interceptionError = String(error).slice(0, 512); await route.abort("failed"); }
  });
  conversionJs=await createConversionJsAllocation(domSession,{directory:reports,prefix:path.basename(reportBase),context,origin});
  observer.setPhase("loaded-navigation"); await page.goto(query);
  assert.equal(cssCandidate.interceptionError, null); assert.equal(cssCandidate.staticAssets.length, 1);
  await page.waitForFunction(() => window.__WITHIN_TEST__?.getState().workerStatus === "ready");
  assert.equal(await page.evaluate(() => crossOriginIsolated), true);
  loadedIdle = await stable("loaded-idle");
  for (let number = 1; number <= 3; number++) {
    // One changed-instrumentation diagnostic attempt only, no repeated known
    // failure and no certification from instrumented timing/memory.
    if (diagnosticOnly && number > 1) break;
    observer.setPhase(`pre-conversion-${number}`);
    // No reload/forced GC/larger baseline: exercise the existing production worker lifecycle.
    await page.waitForFunction(() => window.__WITHIN_TEST__?.getState().workerStatus === "ready");
    const cdp = await context.newCDPSession(page);
    try {
      const doc = await cdp.send("DOM.getDocument");
      const { nodeId } = await cdp.send("DOM.querySelector", { nodeId: doc.root.nodeId, selector: '[data-testid="file-input"]' });
      assert.ok(nodeId); await cdp.send("DOM.setFileInputFiles", { nodeId, files: [source] });
    } finally { await cdp.detach(); }
    await page.locator('[data-testid="format-select"]').selectOption("mkv-to-mp4");
    assert.equal(await page.locator('[data-testid="file-input"]').evaluate((input) => input.files[0].size), expectedSourceBytes);
    const run = { number, cimPeakPrivateBytes: null, cimPeakRssBytes: null, nativePeaks: null,
      incrementalPrivateMiB: null, state: null, independentValidation: null, recovery: null };
    runs.push(run);
    const first = await takeSample(`pre-conversion-${number}`);
    if(number===1)await conversionJs.beforeConversion({jobState:lastState?.jobState??null,metrics:lastState?.metrics??null});
    progressProbe.performanceBefore = await domSession.send("Performance.getMetrics");
    await captureLive("before-conversion",first.processes);
    run.cimPeakPrivateBytes = first.privateBytes; run.cimPeakRssBytes = first.rssBytes;
    observer.setPhase(`conversion-${number}`);
    assert.equal(abortDiagnostic.stagedAdapters.length,3);
    await observer.through(Date.now());
    const conversionAt = observer.setPhase("conversion-" + number); await observer.through(conversionAt);
    await page.locator('[data-testid="convert-button"]').click();
    const deadline = Date.now() + progressProbe.maximumConversionMs; let nextLog = Date.now();
    for (;;) {
      const sample = await takeSample(`conversion-${number}`);
      if (sample.privateBytes != null) run.cimPeakPrivateBytes = Math.max(run.cimPeakPrivateBytes ?? 0, sample.privateBytes);
      if (sample.rssBytes != null) run.cimPeakRssBytes = Math.max(run.cimPeakRssBytes ?? 0, sample.rssBytes);
      await observer.through(Date.now()); run.nativePeaks = observer.peaks([`pre-conversion-${number}`, `conversion-${number}`]);
      assert.ok(run.nativePeaks.peak, "Actual native conversion peak required");
      run.peakPrivateBytes = Math.max(run.cimPeakPrivateBytes ?? -Infinity, run.nativePeaks.peak.privateBytes);
      run.incrementalPrivateMiB = (run.peakPrivateBytes - blankBaseline.privateBytes) / MiB;
      run.state = lastState;
      if(number===1)await conversionJs.progress({jobState:lastState?.jobState??null,metrics:lastState?.metrics??null});
      if ((lastState?.metrics?.wasmMemoryBytes ?? 0) > 0)
        assert.equal(lastState.metrics.wasmMemoryBytes, 48 * MiB, "Reject any unstaged engine before a full remux can complete");
      if(!liveMemoryMidpoint&&lastState?.jobState==="running"&&(lastState.metrics?.outputBytes??0)>=8388608){
        liveMemoryMidpoint=true;await captureLive("running-output-8388608",sample.processes);
      }
      // Stop a proven failed profile promptly; never run hours past the same
      // memory failure or change the baseline/quality to conceal it.
      assert.ok(run.incrementalPrivateMiB <= 250, `Complete Chromium increase ${run.incrementalPrivateMiB}MiB exceeds 250MiB`);
      if (Date.now() >= nextLog) {
        process.stdout.write(`Run${number} ${lastState?.jobState}: input=${lastState?.metrics?.inputBytes ?? "unavailable"}, output=${lastState?.metrics?.outputBytes ?? "unavailable"}, peak=${run.incrementalPrivateMiB.toFixed(3)}MiB.\n`);
        nextLog = Date.now() + 30_000;
      }

      if (lastState?.jobState === "running" && (lastState.metrics?.outputBytes ?? 0) >= progressProbe.checkpointOutputBytes) {
        progressProbe.checkpointReached = true;
        progressProbe.beforeCancellation = lastState;
        await captureLive("running-checkpoint",sample.processes);
        await conversionJs.close(); progressProbe.profilerClosed = true;
        progressProbe.performanceAfter = await domSession.send("Performance.getMetrics");
        progressProbe.cancellation = await cancelBrowserConversionBeforeCleanup(page);
        await takeSample("real-progress-checkpoint-after-cancel");
        progressProbe.afterCancellation = lastState; run.state = lastState;
        break;
      }
      if (lastState?.jobState === "error" || lastState?.jobState === "complete" || lastState?.jobState === "cancelled") break;
      assert.ok(Date.now() < deadline, "Conversion deadline reached; no automatic restart"); await delay(1000);
    }
    observer.setPhase(`validation-${number}`);
    assert.equal(run.state.jobState, "complete", run.state.error ?? run.state.phase);
    assert.equal(run.state.opfsName, null, "Selected handle must not use conversion staging");
    const metrics = run.state.metrics;
    assert.equal(metrics.wasmMemoryBytes, 48 * MiB);
    assert.equal(metrics.peakWasmMemoryBytes, 48 * MiB);
    assert.equal(splitFinalSamples.length, number);
    const ownership = splitFinalSamples[number - 1];
    assert.equal(ownership.closed, true); assert.equal(ownership.activePackets, 0);
    assert.equal(ownership.aggregateWasmMemoryBytes, 48 * MiB);
    assert.equal(ownership.queuedFrames, 0); assert.equal(ownership.queuedPackets, 0);
    assert.equal(ownership.additionalPixelBufferBytes, 0); assert.equal(ownership.additionalJsPacketBufferBytes, 0);
    assert.equal(nativeStackSamples.length, number);
    assert.equal(nativeStackSamples[number - 1].decoderMemoryBytes, 32 * MiB);
    assert.equal(nativeStackSamples[number - 1].encoderMemoryBytes, 16 * MiB);
    assert.equal(nativeStackSamples[number - 1].nativeStackBytes, 262144);
    assert.equal(nativeStackSamples[number - 1].encoderNativeStackBytes, 262144);
    assert.ok(ownership.maximumMediaAvioWriteBytes <= 262144, "Native AVIO cap unchanged");
    assert.ok(metrics.maxReadChunkBytes <= 262144);
    assert.ok(metrics.maxWriteChunkBytes <= 524288, "Existing bounded512KiB selected-destination fallback copy");
    assert.ok((metrics.maxScratchReadChunkBytes ?? 0) <= 524288 && (metrics.maxScratchWriteChunkBytes ?? 0) <= 524288);
    assert.ok(metrics.peakQueuedBytes <= 1048576 && metrics.peakPendingOperations <= 1);
    assert.equal(metrics.pendingOperations, 0); assert.equal(metrics.queuedBytes, 0);
    const output = await outputPayload(metrics.outputBytes), after = await probe(output, true);
    const video = after.streams.find((s) => s.codec_type === "video");
    assert.ok(after.streams.every((s) => Boolean(s.codec_name)), "No unknown/empty output tracks");
    assert.equal(after.streams.filter((s) => s.codec_type === "video" && !s.disposition?.attached_pic).length,
      sourceProbe.streams.filter((s) => s.codec_type === "video" && !s.disposition?.attached_pic).length);
    assert.equal(video.codec_name, "mpeg2video"); assert.equal(video.width, 1920); assert.equal(video.height, 804);
    const originalVideo = sourceProbe.streams.find((s) => s.codec_type === "video" && !s.disposition?.attached_pic);
    for (const field of ["sample_aspect_ratio", "display_aspect_ratio", "color_range",
      "color_space", "color_transfer", "color_primaries", "chroma_location", "r_frame_rate"])
      assert.equal(video[field], originalVideo[field], `Preserve video ${field}`);
    assert.equal(video.tags?.encoder, "Within FFmpeg MPEG-2", "Fresh video encoder provenance");
    const normalizedTags = (tags) => Object.fromEntries(Object.entries(tags ?? {}).map(([key, value]) => [key.toLowerCase(), value]));
    const inputTags = normalizedTags(sourceProbe.format.tags), outputTags = normalizedTags(after.format.tags);
    for (const [key, value] of Object.entries(inputTags))
      assert.equal(outputTags[key], value, `Preserve container metadata ${key}`);
    assert.equal(video.tags?.title, originalVideo.tags?.title, "Preserve primary video title");
    for (const [flag, enabled] of Object.entries(originalVideo.disposition ?? {}))
      if (enabled) assert.equal(video.disposition?.[flag], enabled, `Preserve primary video disposition ${flag}`);
    const inputAudio = sourceProbe.streams.filter((s) => s.codec_type === "audio");
    const outputAudio = after.streams.filter((s) => s.codec_type === "audio");
    assert.equal(outputAudio.length, inputAudio.length);
    for (let i = 0; i < inputAudio.length; i++)
      for (const field of ["codec_name", "sample_rate", "channels", "channel_layout"])
        assert.equal(outputAudio[i][field], inputAudio[i][field], `Preserve audio ${i} ${field}`);
    for (let i = 0; i < inputAudio.length; i++)
      for (const field of ["language", "title"])
        assert.equal(outputAudio[i].tags?.[field], inputAudio[i].tags?.[field], `Preserve audio ${i} ${field}`);
    assert.deepEqual(after.chapters, sourceProbe.chapters);
    const inputArt = sourceProbe.streams.filter((s) => s.disposition?.attached_pic);
    const outputArt = after.streams.filter((s) => s.disposition?.attached_pic);
    assert.equal(outputArt.length, inputArt.length, "Preserve compatible attached pictures");
    const artworkPacketHashes = [];
    for (let i = 0; i < inputArt.length; i++) {
      for (const field of ["codec_name", "width", "height"])
        assert.equal(outputArt[i][field], inputArt[i][field], `Preserve artwork ${i} ${field}`);
      const compressedHash = async (file, index) => (await native(["-v", "error", "-i", file,
        "-map", `0:${index}`, "-c", "copy", "-f", "hash", "-hash", "sha256", "pipe:1"])).stdout.trim();
      const originalHash = await compressedHash(source, inputArt[i].index);
      assert.equal(await compressedHash(output, outputArt[i].index), originalHash);
      artworkPacketHashes.push(originalHash);
    }
    assert.ok(run.state.warnings.some((warning) => /subrip.*explicitly excluded/i.test(warning)),
      "Incompatible subtitle exclusion must be disclosed");
    const inputTimes = await frameTimes(source), outputTimes = await frameTimes(output);
    assert.equal(inputTimes.length, outputTimes.length);
    assert.equal(ownership.frames, outputTimes.length); assert.equal(ownership.packets, outputTimes.length);
    assert.equal(ownership.completedPackets, outputTimes.length);
    let maximumTimestampErrorSeconds = 0;
    for (let i = 0; i < inputTimes.length; i++) maximumTimestampErrorSeconds = Math.max(maximumTimestampErrorSeconds, Math.abs(inputTimes[i] - outputTimes[i]));
    assert.ok(maximumTimestampErrorSeconds <= 0.001);
    assert.deepEqual(await audioHashes(output), await audioHashes(source));
    await native(["-v", "error", "-xerror", "-i", output, "-map", "0:v", "-map", "0:a", "-f", "null", "-"]);
    const { stderr } = await native(["-v", "info", "-i", source, "-i", output, "-filter_complex",
      "[0:v:0]settb=1/1,setpts=N[ref];[1:v:0]settb=1/1,setpts=N[out];[ref][out]ssim", "-an", "-f", "null", "-"]);
    const ssim = Number(/All:([0-9.]+)/.exec(stderr)?.[1]); assert.ok(ssim >= 0.98);
    run.independentValidation = { outputBytes: (await stat(output)).size, sha256: await shaFile(output),
      probe: after, artworkPacketHashes, frameCount: outputTimes.length, maximumTimestampErrorSeconds, ssim, fullDecode: true };
    await emptyOpfs(); await page.waitForFunction(() => window.__WITHIN_TEST__?.getState().workerStatus === "ready");
    run.recovery = await stable(`cleanup-${number}`, loadedIdle.privateBytes + 96 * MiB);
  }
  assert.deepEqual(forbiddenRequests, []);
  assert.equal(abortDiagnostic.captureError,null);
  assert.equal(diagnosticOnly, false, "Private allocation/stack diagnostic cannot certify protected acceptance");
} catch (error) {
  failure = { name: error.name, message: error.message, stack: error.stack }; process.exitCode = 1;
} finally {
  const cleanupErrors = [];
  const attempt = async (action) => { try { await action(); } catch (error) { cleanupErrors.push(String(error)); } };
  await attempt(async () => {
    if (observer) nativeFailureCapture = await observer.finishCapture();
    if(conversionJs){await conversionJs.close();conversionJsReport=conversionJs.report();}
    if(rendererAttribution)rendererAttributionResult=await rendererAttribution.stop();
    cleanup.conversionQuiescence = await cancelBrowserConversionBeforeCleanup(page);
  });
  await attempt(async () => {
    if (observer) {
      try { observer.setPhase("finally-cleanup"); await observer.stop(); cleanup.observerStopped = true; }
      finally { nativeMemory = observer.report(); nativeFailureCapture = observer.failureCaptureReport(); }
    }
  });
  await attempt(async () => { if (page && !page.isClosed()) await emptyOpfs(); });
  await attempt(async () => { if (context) await context.tracing.stop({ path: `${reportBase}-trace.zip` }); });
  await attempt(() => realms?.close());
  await attempt(async () => { domSampler?.close(); if (domSession) await domSession.detach();
    domSamplerReport = domSampler?.report() ?? null; });
  await attempt(() => browser?.close());
  await attempt(() => finishOwnedCleanup([() => stopOwned(chrome), () => stopOwned(server)]));
  await attempt(async () => {
    if (chrome) {
      const identity = samples.flatMap(row => row.processes ?? []).find(row => row.pid === chrome.pid);
      assert.ok(identity); cleanup.chromeRootExitObservation = await observeOwnedProcessExit(identity);
      assert.equal(cleanup.chromeRootExitObservation.status, "owned-identity-absent");
      cleanup.sampledChromeRootStopped = true;
    }
  });
  await attempt(async () => {
    // Restoration child uses this scratch, so it must finish before close.
    if (staged) { await exec(process.execPath, ["scripts/stage-mpeg2-late-allocator-abort.mjs", "restore"]); cleanup.generatedDistRestored = true; }
  });
  await attempt(async () => {
    if (runtime) { await runtime.close(); await assert.rejects(access(runtime.directory), { code: "ENOENT" }); cleanup.mediaProfileRuntimeRemoved = true; }
  });
  await attempt(async () => { await verifySource(); cleanup.protectedFixtureUnchanged = true; });
  if (cleanupErrors.length) {
    failure ??= { name: "CleanupFailure", message: cleanupErrors.join(" | ") };
    cleanup.errors = cleanupErrors; process.exitCode = 1;
  }
  const report = { recordedAt: new Date().toISOString(), status: failure ? "failed" : "passed-private-protected-session",
    publicAcceptance: false, diagnosticOnly,
    scope: "Full protected original with equivalent border-box hero width flex PLUS fully rendered405card matrix/dynamic flex CSS/compiled3e744 pending-pool and bounded allocator-header fatal observer; ONE post-budget-failure normal production cancellation/worker-close/detailed partial-capable dump with bounded raw archive, delayed NOT peak-time allocator proof; same encoder/settings/fixed32+16MiB/allprocesses250MiB/lower five-minute blank/three full runs/independent fidelity/cleanup gates. Bounded actual page DOM counters and one first native-failure counter callback, no detailed heap dump or forcedGC. Private candidate, no public/OS-picker/speed-A-B certification.",
    source: { path: "test.mkv", bytes: expectedSourceBytes, sha256: expectedSourceHash, probe: sourceProbe },
    browserVersion, manifest, actualWasmMemoryLimits, sourceHashes,
    formula: "peak complete Chromium process-tree private memory during conversion - stable clean blank-Chromium process-tree private memory",
    limitMiB: 250, requestedRuns: diagnosticOnly ? 1 : 3, startupSettlement, blankBaseline, loadedIdle, runs, samples, samplesEvicted,
    allocatorSamples, allocatorSamplesEvicted, splitFinalSamples, nativeStackSamples,
    nativeMemory, nativeFailureCapture, domSamplerReport, cssCandidate, abortDiagnostic, quiescedBudgetCapture, rendererAttributionResult, conversionJsReport, progressProbe, liveMemoryRecords, failure, logs, forbiddenRequests, browserLocalRequests, cleanup,
    ownedPids: { chrome: chrome?.pid ?? null, server: server?.pid ?? null, observer: observer?.pid ?? null }, runtimeDirectory: runtime?.directory ?? null };
  const json = JSON.stringify(report, null, 2); assert.ok(Buffer.byteLength(json) <= 32 * MiB, "Report cap; never unlimited histories");
  await writeFile(`${reportBase}.json`, `${json}\n`, { flag: "wx" });
  await writeFile(`${reportBase}.csv`, "timestamp,phase,privateBytes,rssBytes,outputBytes\n" + samples.map((s) =>
    [s.timestamp, s.phase, s.privateBytes ?? "", s.rssBytes ?? "", s.metrics?.outputBytes ?? ""].join(",")).join("\n"), { flag: "wx" });
  const points = (nativeMemory?.graphBuckets ?? []).filter((b) => b.peak).map((b) => [Date.parse(b.peak[1]), b.peak[3]]);
  const max = points.reduce((m, p) => Math.max(m, p[1]), MiB), first = points[0]?.[0] ?? 0, span = Math.max(1, (points.at(-1)?.[0] ?? first) - first);
  const graph = points.map(([t, value]) => `${((t - first) / span * 900).toFixed(1)},${(280 - value / max * 260).toFixed(1)}`).join(" ");
  const escape = (s) => String(s).replaceAll("&", "&amp;").replaceAll("<", "&lt;");
  await writeFile(`${reportBase}.html`, `<!doctype html><meta charset="utf-8"><title>Protected MPEG2 private gate</title><h1>${escape(report.status)}</h1><p>${escape(report.formula)}</p><svg viewBox="0 0 920 300"><polyline fill="none" stroke="red" points="${graph}"/></svg><pre>${escape(JSON.stringify({ blankBaseline, loadedIdle, failure, cleanup }, null, 2))}</pre>`, { flag: "wx" });
  completedReport = report; completedReportPath = `${reportBase}.json`;
  process.stdout.write(`${report.status}: ${reportBase}.json\n`);
}
